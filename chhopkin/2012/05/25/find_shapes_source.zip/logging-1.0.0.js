﻿/*!
* Logging JavaScript Library v1.0.0
*
* Copyright 2011, Microsoft
*/

// init the VGSHelpers object
var Logging = {};

Logging.logToConsole = function (message)
{
    if (typeof console != "undefined")
    {
        var sPath = window.location.pathname;
        var sPage = sPath.substring(sPath.lastIndexOf('/') + 1);
        sPage = sPage.replace(/%20/g, " ");

        console.log(sPage + ": " + message);
    }
}