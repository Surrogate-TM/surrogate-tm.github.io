﻿/*!
* HTML5Helpers JavaScript Library v1.0.0
*
* Copyright 2011, Microsoft
*/

// init the VGSHelpers object
var HTML5Helpers = {};

HTML5Helpers.doesBrowserSupportCanvas = function ()
{
    var tmpElement = document.createElement("canvas") //try and create sample canvas element
    var retVal = (tmpElement.getContext) ? true : false //check if object supports getContext() method, a method of the canvas element

    return retVal;
}