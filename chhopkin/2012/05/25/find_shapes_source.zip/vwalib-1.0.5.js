/*!
* Visio Web Access JavaScript Library v1.0.4
*
* Copyright 2011, Microsoft
*/

// init the VGSHelpers object
var VGSHelpers = {};

VGSHelpers.getVwaControl = function ()
{
    var retVal = null;

    try
    {
        var webPartID = VGSHelpers.findVwaControlId();

        if (webPartID == null)
        {
            throw new Error("An error connecting to Visio Web Part.  Please contact the site administrator.");
        }
        else
        {
            retVal = new Vwa.VwaControl(webPartID); // ex. "WebPartWPQ3"

            if (retVal == null)
            {
                throw new Error("An error connecting to Visio Web Part.  Please contact the site administrator.");
            }
        }
    }
    catch (ex)
    {
        alert(ex);
    }

    return retVal;
}

//----------------------------------------------------------
// Find the ID of the VisioWebAccess web part on this page.
// 
// If you have more than one VWA web part on the page this
// function will return the first one that is found
//----------------------------------------------------------
VGSHelpers.findVwaControlId = function ()
{
    var retVal = null;

    if (typeof jQuery == 'undefined')
    {
        // no jQuery loaded, find it the old way

        var divCollection = document.getElementsByTagName("div");

        for (var i = 0; i < divCollection.length; i++)
        {
            if (divCollection[i].getAttribute("class") == "VisioWebAccess")
            {
                // the actual id of the VWA web part is two levels higher than this class node
                retVal = divCollection[i].parentNode.parentNode.getAttribute('id');
                break;
            }
        }
    }
    else
    {
        // jQuery is loaded

        // use jQuery to dynamically retrieve the web part ID for the VisioWebAccess web part
        // this always returnes the first Visio Web Access web part that is defined on the page
        retVal = $(".VisioWebAccess").parent().parent().attr('id');
    }

    return retVal;
}

//----------------------------------------------------------
// Returns the URL for the diagram that is currently loaded
// in the passed instance of the VWA.Control object.
//
// This function removes the %20 characters that are embedded
// by sharepoint.
//----------------------------------------------------------
VGSHelpers.getCurrentDiagramUrl = function (vwaCtrl)
{
    return vwaCtrl.getDiagramUrl().replace(/%20/g, " "); // notice the replace call to remove unwanted %20 characters from the URL which represent spaces
}

//----------------------------------------------------------
// Returns the name of the active page in the instance of
// the passed VWA.Control object.
//----------------------------------------------------------
VGSHelpers.getCurrentPageName = function (vwaCtrl)
{
    return vwaCtrl.getActivePage().getId();  // this just returns the page name like Page-1
}

//----------------------------------------------------------
// Returns an array of all the indexes for the passed
// Vwa.ShapesCollection
//----------------------------------------------------------
VGSHelpers.getShapeIndexes = function (shapes)
{
    if (shapes == null)
    {
        return null;
    }

    var shapeCount = shapes.getCount();

    // create our array of shape indexes to process
    var retVal = [];

    for (nextShapeIndex = 0; nextShapeIndex < vwaShapeCount; nextShapeIndex++)
    {
        retVal[nextShapeIndex] = nextShapeIndex;
    }

    return retVal;
}

//----------------------------------------------------------
// find the index of the page from the list of page names in the active diagram
//
// Ex.
// var pageIndex = getPageIndex(page);
// vwaControl.openDiagram(diagram, pageIndex); // this handles -1 for the pageIndex value
//----------------------------------------------------------
VGSHelpers.getPageIndex = function (pageName)
{
    var pageNames = vwaControl.getAllPageIds();

    if (pageNames != null)
    {
        for (var i = 0; i < pageNames.length; i++)
        {
            if (pageNames[i] == pageName)
            {
                return i;
            }
        }
    }

    // page not found
    return -1;
}

//----------------------------------------------------------
// Allows you to enable refresh for a diagram to keep the
// Refresh Disabled notification bar from popping up
//
// Clicking the RefreshAlways options creates a permanent cookie that expires after 7 days.
// Clicking the RefreshOnce option creates a temporary cookie that will be deleted when the browser is closed
//----------------------------------------------------------
VGSHelpers.enableRefresh = function (vwaCtrl, always)
{
    var entry = vwaCtrl._control._notificationBar.findEntry("Refresh");

    if (entry && entry.get_visible())
    {
        if (always)
        {
            entry.onAction("RefreshAlways"); // this is the Enable Always button
        }
        else
        {
            entry.onAction("RefreshOnce"); // this is the Enable Session button
        }
    }
}

//----------------------------------------------------------
// Determines if the VWA control supports silverlight rendering
// true - yes it is rendering using Silverlight
// false - no, it is rendering using HTML/PNG.
//      the browser does not have Silverlight installed
//      the browser is on a device that does not support plug-ins
//      the VWA web part has the force raster setting enabled
//----------------------------------------------------------
VGSHelpers.drawOverlayWithXAML = function (vwaCtrl)
{
    if (!vwaCtrl._control.get_alwaysRaster() &&
                 vwaCtrl.getDisplayMode() == Vwa.DisplayMode.silverlight)
    {
        return true;
    }
    else
    {
        return false;
    }
}

//----------------------------------------------------------
// Returns a canvas element (HTML5) that is the same size as the provided shape
// The overlayId is set as the id of the canvas element
//----------------------------------------------------------
VGSHelpers.getCanvasForShape = function (shape, overlayId)
{
    // use canvas in HTML 5 to define the overlay
    var htmlBuilder = "<div style='font-family:Segoe;color:#000000'>";

    htmlBuilder += "<canvas id='" + overlayId + "' width='" + shape.getBounds().width + "' height='" + shape.getBounds().height + "'>Your browser does not have support for HTML5 Canvas.</canvas>"

    // close it up
    htmlBuilder += "</div>";

    return htmlBuilder;
}