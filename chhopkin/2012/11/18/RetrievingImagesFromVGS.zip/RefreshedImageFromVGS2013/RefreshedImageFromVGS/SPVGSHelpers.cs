﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net;
using System.Net.Http;

using Microsoft.SharePoint.Client;
using System.Windows.Media.Imaging;

namespace RefreshedImageFromVGS
{
    public class SPVGSHelpers
    {
        public const string VGS_SERVICE_URI = "_layouts/15/VisioWebAccess/VisioWebAccess.ashx";

        // SEQUENCE ID URI
        // ex. http://visio15demo/conference/_layouts/15/VisioWebAccess/VisioWebAccess.ashx?V=15&T=0&D=&P=-1&F=http%3A%2F%2Fvisio15demo%2Fconference%2FShared%20Documents%2FFashion%20-%20Data%20Connect%2FFashionStation_Finished.vsdx
        public const string VGS_SEQID_URI = VGS_SERVICE_URI + @"?V={0}&T={1}&D={2}&P={3}&F={4}";

        // IMAGE URI - put sequence id in at {0}
        // ex. http://visio15demo/conference/_layouts/15/VisioWebAccess/VisioWebAccess.ashx?V=15&T=1&I=Image3&S={0}&F=http%3A%2F%2Fvisio15demo%2Fconference%2FShared%20Documents%2FFashion%20-%20Data%20Connect%2FFashionStation_Finished.vsdx
        public const string VGS_IMAGE_URI = VGS_SERVICE_URI + @"?V={0}&T={1}&I={2}&S={3}&F={4}";

        /// <summary>
        /// Image Quality Constants for Visio Services
        /// </summary>
        public enum VGSImageQuality
        {
            High,
            Medium,
            Low
        }

        /// <summary>
        /// A Sequence ID gets us a particular image for the request from VGS.
        /// </summary>
        /// <param name="uriToVGS"></param>
        /// <param name="cookieContainer"></param>
        /// <returns></returns>
        public static async Task<string> GetSequenceId(
            Uri uriToVGS,
            CookieContainer cookieContainer)
        {
            string retVal = null;

            try
            {
                HttpClientHandler handler = new HttpClientHandler();
                handler.UseDefaultCredentials = true;

                if (cookieContainer != null)
                {
                    handler.CookieContainer = cookieContainer;
                }

                HttpClient httpClient = new HttpClient(handler);
                HttpResponseMessage response = httpClient.GetAsync(uriToVGS).Result;

                //retVal = await response.Content.ReadAsStringAsync();

                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new System.Exception(
                        string.Format(
                            "POST failed.  Received HTTP {0}",
                            response.StatusCode));
                }

                // parse for sequence id
                //var test = response.Headers.ToArray()[12].Value.ToArray()[0];
                Dictionary<string, string> headerItems = response.Headers.ToDictionary(x => x.Key, x => x.Value.First());

                // "[DataModeFromServer]_[FileETag]_[OutputETag]_[SequenceId]"
                retVal = headerItems["ETag"].Replace("\"", "").Split('_').Last();
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }

            return retVal;
        }

        /// <summary>
        /// Return an image from a particular page in the VSDX file.
        /// </summary>
        /// <param name="urlSite"></param>
        /// <param name="urlVSDX"></param>
        /// <returns></returns>
        public static BitmapImage GetVGSImageStatic(
            string urlSite,
            string urlVSDX)
        {
            // urlImage is the full URL to the diagram we need to access
            // ex. @"http%3A%2F%2Fvisio15demo%2Fconference%2FShared%20Documents%2FFashion%20-%20Data%20Connect%2FFashionStation_Finished.vsdx";

            // pass this to the web control for full VGS view
            // but this does not work because VGS has confirm and alert in its JS API and these are not supported in Win8 Store Apps
            // Uri uri = new Uri("http://visio15demo/conference/Shared%20Documents/Fashion%20-%20Mashup/FashionStation_Finished.vsdx");

            // consume this URI to get the sequence id for a specific diagram
            // http://visio15demo/conference/_layouts/15/VisioWebAccess/VisioWebAccess.ashx?V=15&T=0&D=&P=-1&F=http%3A%2F%2Fvisio15demo%2Fconference%2FShared%20Documents%2FFashion%20-%20Data%20Connect%2FFashionStation_Finished.vsdx

            if (!urlSite.EndsWith("/"))
            {
                urlSite += "/";
            }

            Uri uriForSeqId = new Uri(
                    string.Format(
                        urlSite + SPVGSHelpers.VGS_SEQID_URI,
                        "15",
                        "0",
                        "",
                        "-1",
                        urlVSDX));

            var task = SPVGSHelpers.GetSequenceId(
                uriForSeqId,
                null);

            // get the sequence id from the response
            string seqId = task.Result;

            // consturct URI for getting the image we need using the sequence id returned for this diagram
            // http://visio15demo/conference/_layouts/15/VisioWebAccess/VisioWebAccess.ashx?V=15&T=1&I=Image3&S={0}&F=http%3A%2F%2Fvisio15demo%2Fconference%2FShared%20Documents%2FFashion%20-%20Data%20Connect%2FFashionStation_Finished.vsdx
            string imageUri =
                string.Format(
                    urlSite + SPVGSHelpers.VGS_IMAGE_URI,
                    "15",
                    "1",
                    "Image3", // image quality
                    seqId,
                    urlVSDX);

            // use BitmapImage to load the image from the provided URI
            // this is a static version of the image as posted to VGS
            return new BitmapImage(new Uri(imageUri, UriKind.RelativeOrAbsolute));
        }


        public static BitmapImage GetImageFromVGS(
            string urlSite,
            string urlVSDX,
            bool refreshed,
            VGSImageQuality imgQuality,
            int pageId = -1) // TODO - what about the page identifier to load a particular page
        {
            // urlImage is the full URL to the diagram we need to access
            // ex. @"http%3A%2F%2Fvisio15demo%2Fconference%2FShared%20Documents%2FFashion%20-%20Data%20Connect%2FFashionStation_Finished.vsdx";

            // pass this to the web control for full VGS view
            // but this does not work because VGS has confirm and alert in its JS API and these are not supported in Win8 Store Apps
            // Uri uri = new Uri("http://spdev15escrow/Shared%20Documents/PageSamples.vsdx");

            // consume this URI to get the sequence id for a specific diagram
            // http://spdev15escrow/_layouts/15/VisioWebAccess/VisioWebAccess.ashx?V=15&T=0&D=&P=-1&F=http%3A%2F%2Fspdev15escrow%2FShared%20Documents%2FPageSamples.vsdx

            if (!urlSite.EndsWith("/"))
            {
                urlSite += "/";
            }

            Uri uriForSeqId = new Uri(
                    string.Format(
                        urlSite + SPVGSHelpers.VGS_SEQID_URI,
                        "15",
                        "0",
                        "",
                        pageId.ToString(), // -1 = Page 1; -2 = Page 2; -3 = Page 3; etc...
                        urlVSDX));

            CookieContainer cookieContainer = null;

            if (refreshed)
            {
                // Get the SPFile.UniqueId using the SharePoint client object model.
                //string urlSite = "http://spdev15escrow/";
                ClientContext ctx = new ClientContext(urlSite);
                //ctx.Credentials = System.Net.CredentialCache.DefaultCredentials;

                // get the web object
                Web web = ctx.Web;
                ctx.Load(web);

                // get the current user
                ctx.Load(ctx.Web.CurrentUser);
                ctx.ExecuteQuery();

                // get the file id for the VSDX that we need a data refreshed version of
                // http://spdev15escrow/Shared%20Documents/PageSamples.vsdx
                //File file = web.GetFileByServerRelativeUrl(@"/Conference/Shared Documents/Fashion - Data Connect/FashionStation_Finished.vsdx");
                File file = web.GetFileByServerRelativeUrl(web.ServerRelativeUrl + urlVSDX.Replace(urlSite, ""));
                
                ctx.Load(file);
                ctx.Load(file.ListItemAllFields);

                ctx.ExecuteQuery();

                // get the User ID for our cookie modification
                int userId = ctx.Web.CurrentUser.Id;

                // get the file id for the VSDX
                //ListItemAllFields["UniqueId"] returns a guid
                string fileId = file.ListItemAllFields["UniqueId"].ToString();

                // Create the VwaRefresh cookie
                string cookieName = string.Format("VwaRefresh{0}{1}", fileId, userId);
                Cookie cookie = new Cookie(cookieName, "*", "/", "spdev15escrow");
                cookieContainer = new CookieContainer();
                cookieContainer.Add(
                    uriForSeqId,
                    cookie);
            }

            var task = SPVGSHelpers.GetSequenceId(
                uriForSeqId,
                cookieContainer);

            // get the sequence id from the response
            string seqId = task.Result;

            string imageQuality = "Image1"; // default to high

            switch (imgQuality)
            {
                case VGSImageQuality.High:
                    {
                        imageQuality = "Image1";
                        break;
                    }

                case VGSImageQuality.Medium:
                    {
                        imageQuality = "Image2";
                        break;
                    }

                case VGSImageQuality.Low:
                    {
                        imageQuality = "Image3";
                        break;
                    }
            }

            // consturct URI for getting the image we need
            // http://visio15demo/conference/_layouts/15/VisioWebAccess/VisioWebAccess.ashx?V=15&T=1&I=Image3&S={0}&F=http%3A%2F%2Fvisio15demo%2Fconference%2FShared%20Documents%2FFashion%20-%20Data%20Connect%2FFashionStation_Finished.vsdx
            string imageUri =
                string.Format(
                    urlSite + SPVGSHelpers.VGS_IMAGE_URI,
                    "15",
                    "1",
                    imageQuality,
                    seqId,
                    urlVSDX);

            // data refreshed image
            return new BitmapImage(new Uri(imageUri, UriKind.RelativeOrAbsolute));
        }
    }
}