﻿//-----------------------------------------------------------------------
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

namespace CommandBarStateDemo
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Windows.Forms;

    // visio sdk
    using Visio = Microsoft.Office.Interop.Visio;

    public partial class AnchorBaseForm : Form
    {
        #region fields

        private Visio.Window anchorWindow;

        #endregion

        #region construction

        public AnchorBaseForm()
        {
            InitializeComponent();
        }

        #endregion

        #region properties

        public Microsoft.Office.Interop.Visio.Window AnchorWindow
        {
            get
            {
                return this.anchorWindow;
            }
        }

        #endregion

        #region visio events

        private void AnchorWindow_BeforeWindowClosed(Microsoft.Office.Interop.Visio.Window Window)
        {
            // FYI - we might want to persist the location for when the window is created again
            // so persist the location information now before the window closes

            // the window is closing, we need to close our form
            this.anchorWindow = null;

            // if this is displayed as an anchor window the form will still be alive, just not visible
            // here we can decide if we want to kill the form too of just leave it for the next time
            // the anchor window is created
            //this.Close();
        }

        #endregion

        #region methods

        public Visio.Window Show(
            Visio.Window parentWindow,
            string windowCaption)
        {
            return this.Show(parentWindow, windowCaption, null, null);
        }

        public Visio.Window Show(
            Visio.Window parentWindow,
            string windowCaption,
            string mergeId,
            string mergeClass)
        {
            Visio.Window retVal = null;

            try
            {
                object windowStates =
                    Visio.VisWindowStates.visWSAnchorBottom |
                    //Visio.VisWindowStates.visWSAnchorLeft |
                    //Visio.VisWindowStates.visWSDockedBottom | // this instead of anchor will doc to the bottom
                    //Visio.VisWindowStates.visWSAnchorAutoHide |
                    Visio.VisWindowStates.visWSAnchorMerged | // add this to merge on create
                    Visio.VisWindowStates.visWSVisible;

                // The anchor bar is a window created by an add-on
                object windowTypes = Visio.VisWinTypes.visAnchorBarAddon;

                // Add a custom anchor bar window.

                // this works to merge when they are created with the merged flag in states
                // give the form a reference to the anchor bar window it is contained in
                this.anchorWindow = AnchorBaseForm.CreateAnchorWindow(
                    parentWindow,
                    windowCaption,
                    windowStates,
                    windowTypes,
                    mergeId, // set the merge id
                    mergeClass); // set the class so this window will only merge with other windows that contain this class

                // Set the form as contents of the anchor bar.
                AddFormToAnchorWindow(this.AnchorWindow, this);

                // sink to the closing event so we can do work on our form if needed
                this.anchorWindow.BeforeWindowClosed += new Microsoft.Office.Interop.Visio.EWindow_BeforeWindowClosedEventHandler(AnchorWindow_BeforeWindowClosed);
                // QueryCancelWindowClose does not fire on this window type, all we can do is handle Close
                // It would be nice if we could query cancel, then we could just set Visible = false
                // so that window position and state does not have to be manually persisted by our code

                // Set the MergeCaption property with string that is shorter 
                // than the window caption. The MergeCaption property value 
                // appears on the tab of the merged window.
                retVal.MergeCaption = windowCaption;
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                throw;
            }

            return retVal;
        }

        private static Visio.Window CreateAnchorWindow(
            Visio.Window visioWindow,
            string caption,
            object windowStates,
            object windowTypes,
            string mergeId,
            string mergeClass)
        {
            Visio.Window retVal = null;

            try
            {
                // Add a new anchor bar with the required information.
                retVal = visioWindow.Windows.Add(
                    caption,
                    windowStates,
                    windowTypes,
                    8, 10, 300, 300,
                    mergeId,
                    mergeClass,
                    0);
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                throw;
            }

            return retVal;
        }

        /// <summary>This method adds a form as the contents of the anchor bar.
        /// </summary>
        /// <param name="anchorBar">Reference to the anchor bar window</param>
        /// <param name="displayForm">Content of the anchor bar</param>
        private static void AddFormToAnchorWindow(
            Visio.Window anchorWindow,
            System.Windows.Forms.Form form)
        {
            int left;
            int top;
            int width;
            int height;
            int windowHandle;

            try
            {
                // Show the form as a modeless dialog.
                form.Show();

                // Get the window handle of the form.
                windowHandle = form.Handle.ToInt32();

                // Set the form as a visible child window.
                if (NativeMethods.SetWindowLongW(windowHandle,
                    NativeMethods.GWL_STYLE,
                    NativeMethods.WS_CHILD | NativeMethods.WS_VISIBLE) == 0 &&
                    System.Runtime.InteropServices.Marshal.GetLastWin32Error() != 0)
                {
                    throw new System.Exception("An exception occurred calling SetWindowLongW.");
                }

                // Set the anchor bar window as the parent of the form.
                if (NativeMethods.SetParent(windowHandle, anchorWindow.WindowHandle32) == 0)
                {
                    throw new System.Exception("An exception occurred calling SetParent.");
                }

                // Set the dock property of the form to fill, so that the form
                // automatically resizes to the size of the anchor bar.
                form.Dock = System.Windows.Forms.DockStyle.Fill;

                // Resize the anchor bar so it will refresh and paint properly.
                // adding a small amount to the size will trigger this
                anchorWindow.GetWindowRect(out left,
                    out top,
                    out width,
                    out height);

                anchorWindow.SetWindowRect(left,
                    top,
                    width,
                    height + 1);
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                throw;
            }
        }

        /// <summary>Explicitly declare calls to unmanaged code inside a
        /// 'NativeMethods' class.  This class does not suppress stack walks for
        /// unmanaged code permission.</summary>
        private class NativeMethods
        {
            /// <summary>Windows constant - Sets a new window style.</summary>
            internal const short GWL_STYLE = (-16);

            /// <summary>Windows constant - Creates a child window..</summary>
            internal const int WS_CHILD = 0x40000000;

            /// <summary>Windows constant - Creates a window that is initially
            /// visible.</summary>
            internal const int WS_VISIBLE = 0x10000000;

            /// <summary>Declare a private constructor to prevent new instances
            /// of the NativeMethods class from being created. This constructor
            /// is intentionally left blank.</summary>
            private NativeMethods()
            {
                // No initialization is required.
            }

            /// <summary>Prototype of SetParent() for PInvoke</summary>
            [System.Runtime.InteropServices.DllImport("user32.dll")]
            internal static extern int SetParent(int hWndChild, int hWndNewParent);

            /// <summary>Prototype of SetWindowLong() for PInvoke</summary>
            [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
            internal static extern int SetWindowLongW(int hwnd, int nIndex, int dwNewLong);
        }

        #endregion
    }
}
