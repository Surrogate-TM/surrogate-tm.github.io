﻿//-----------------------------------------------------------------------
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

namespace CommandBarStateDemo
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Data;
    using System.Data.OleDb;
    using System.Linq;
    using System.Text;
    using System.Windows.Forms;

    // visio sdk
    using Visio = Microsoft.Office.Interop.Visio;

    internal class Document
    {
        #region fields

        private Visio.Document visioDocument;

        #endregion

        #region construction

        private Document(
            Visio.Document visioDocument)
        {
            this.visioDocument = visioDocument;

            this.VisioEvents_Connect();
        }

        internal static bool TryCreate(
            Visio.Document visioDocument,
            out Document createdDocument)
        {
            if (visioDocument == null)
            {
                throw new ArgumentNullException("visioDocument");
            }

            // FYI - we do not need to check for OUR document, any document will do in this sample add-in

            // check if our document
            //if (visioDocument.SolutionID(ThisAddIn.SolutionIDCellName) == ThisAddIn.DocId)
            //{
            // this is our document
            createdDocument = new Document(visioDocument);
            return true;
            //}

            //// set out param
            //createdDocument = null;

            //// return failure
            //return false;
        }

        #endregion

        #region visio events

        private void VisioEvents_Connect()
        {
            this.visioDocument.BeforeDocumentClose += new Microsoft.Office.Interop.Visio.EDocument_BeforeDocumentCloseEventHandler(this.VisioDocument_BeforeDocumentClose);
        }

        private void VisioDocument_BeforeDocumentClose(Microsoft.Office.Interop.Visio.Document doc)
        {

        }

        #endregion

        #region properties

        /// <summary>
        ///	Gets the Visio.Document object for this document wrapper.
        /// </summary>
        internal Visio.Document VisioDocument
        {
            get { return this.visioDocument; }
        }

        internal AnchorForm1 AnchorForm1
        {
            get;
            set;
        }

        internal AnchorForm2 AnchorForm2
        {
            get;
            set;
        }

        #endregion

        #region methods


        #endregion
    }
}