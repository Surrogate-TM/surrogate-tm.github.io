﻿//-----------------------------------------------------------------------
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Visio = Microsoft.Office.Interop.Visio;
using Microsoft.Office.Core;

namespace CommandBarStateDemo
{
    internal class UIMgr
    {
        #region constants

        private const string TAG_MAINMENU = "DEMO";

        private const string TAG_ITEM1 = TAG_MAINMENU + "|ITEM1";
        private const string TAG_ITEM2 = TAG_MAINMENU + "|ITEM2";
        private const string TAG_ITEM3 = TAG_MAINMENU + "|ITEM3";

        private const string TAG_ANCHOR1 = TAG_MAINMENU + "|ANCHOR1";
        private const string TAG_ANCHOR2 = TAG_MAINMENU + "|ANCHOR2";

        private const string TAG_ABOUT = TAG_MAINMENU + "|ABOUT";

        #endregion

        #region fields

        List<IVisioCommandBarItem> _CommandBarButtons = new List<IVisioCommandBarItem>();

        #endregion

        #region properties

        /// <summary>
        /// Returns the Menu Bar for this Visio Application instance.
        /// </summary>
        internal static CommandBar MainMenu_Visio
        {
            get
            {
                // get the main menu
                CommandBars commandBars = null;

                try
                {
                    commandBars = Globals.ThisAddIn.Application.CommandBars as CommandBars;
                }
                catch
                {
                    // during debugging CommandBars will throw an exception when Visio is shutting down
                    // but does not happen at runtime
                }

                CommandBar menuBar = null;

                if (commandBars != null)
                {
                    menuBar = commandBars["Menu Bar"]; // get by name
                }

                return menuBar;
            }
        }

        /// <summary>
        /// Returns the top level menu for this add-in.
        /// </summary>
        internal CommandBarPopup MainMenu_Addin
        {
            get
            {
                // get the main menu
                CommandBar menuBar = UIMgr.MainMenu_Visio;

                // check for the main menu for this add-in
                if (menuBar == null)
                {
                    return null;
                }

                return menuBar.FindControl(
                    MsoControlType.msoControlPopup,
                    System.Type.Missing,
                    TAG_MAINMENU,
                    true,
                    true) as CommandBarPopup;
            }
        }

        #endregion

        #region methods

        internal void RemoveUI()
        {
            /* find and delete the add-in menu */
            CommandBarPopup addinMenu = this.MainMenu_Addin;

            if (addinMenu != null)
            {
                addinMenu.Delete(true);
            }
        }

        internal void AddUI()
        {
            // make sure our UI does not already exist
            // i.e the temporary flag may not be honored or Visio may have crashed leaving our UI in a bad state
            RemoveUI();

            // get the main menu
            CommandBar menuBar = UIMgr.MainMenu_Visio;

            // create the add-in menu and items
            CommandBarPopup addinMenu = menuBar.Controls.Add(
                MsoControlType.msoControlPopup,
                System.Type.Missing,
                System.Type.Missing,
                System.Type.Missing,
                true) as CommandBarPopup;

            addinMenu.Caption = "CommandBarStateDemo";
            addinMenu.Tag = TAG_MAINMENU; // tag name so we can find it with FindControls above

            /* add the menu items */

            #region Item 1

            CommandBarButton buttonItem1 = addinMenu.Controls.Add(
                MsoControlType.msoControlButton,
                System.Type.Missing,
                System.Type.Missing,
                System.Type.Missing,
                true) as CommandBarButton;

            buttonItem1.Caption = "DocumentActive";
            buttonItem1.Tag = TAG_ITEM1;

            buttonItem1.Click += new _CommandBarButtonEvents_ClickEventHandler(Globals.ThisAddIn.buttonItem1_Click);

            buttonItem1.FaceId = 191;

            this._CommandBarButtons.Add(
                new VisioCommandBarButton(
                    Globals.ThisAddIn.Application,
                    buttonItem1, // button to wrap
                    ButtonEnabled.DocumentActive));

            #endregion

            #region Item 2

            CommandBarButton buttonItem2 = addinMenu.Controls.Add(
                MsoControlType.msoControlButton,
                System.Type.Missing,
                System.Type.Missing,
                System.Type.Missing,
                true) as CommandBarButton;

            buttonItem2.Caption = "DocumentActive - Check Scope";
            buttonItem2.Tag = TAG_ITEM2;

            buttonItem2.Click += new _CommandBarButtonEvents_ClickEventHandler(Globals.ThisAddIn.buttonItem2_Click);

            _CommandBarButtons.Add(
                new VisioCommandBarButton(
                    Globals.ThisAddIn.Application,
                    buttonItem2, // button to wrap
                    ButtonEnabled.DocumentActive,
                    new CheckScopeCallback(Globals.ThisAddIn.CheckScope_OurDocument)));

            #endregion

            #region Item 3

            CommandBarButton buttonItem3 = addinMenu.Controls.Add(
                MsoControlType.msoControlButton,
                System.Type.Missing,
                System.Type.Missing,
                System.Type.Missing,
                true) as CommandBarButton;

            buttonItem3.Caption = "SelectionActive";
            buttonItem3.Tag = TAG_ITEM3;

            buttonItem3.Click += new _CommandBarButtonEvents_ClickEventHandler(Globals.ThisAddIn.buttonItem3_Click);

            _CommandBarButtons.Add(
                new VisioCommandBarButton(
                    Globals.ThisAddIn.Application,
                    buttonItem3, // button to wrap
                    ButtonEnabled.SelectionActive));

            #endregion

            #region anchor 1 window

            CommandBarButton buttonAnchor1Window = addinMenu.Controls.Add(
                MsoControlType.msoControlButton,
                System.Type.Missing,
                System.Type.Missing,
                System.Type.Missing,
                true) as CommandBarButton;

            buttonAnchor1Window.Caption = "Toggle Anchor 1 Window"; // this will get overwritten
            buttonAnchor1Window.Tag = TAG_ANCHOR1;
            buttonAnchor1Window.BeginGroup = true;

            buttonAnchor1Window.Click += new _CommandBarButtonEvents_ClickEventHandler(Globals.ThisAddIn.buttonAnchor1_Click);

            buttonAnchor1Window.FaceId = 191;

            this._CommandBarButtons.Add(
                new VisioCommandBarButtonForAnchorWindow(
                    Globals.ThisAddIn.Application,
                    buttonAnchor1Window,
                    ButtonEnabled.DocumentActive,
                    "Anchor 1 Window",
                    "Show Anchor 1 Window",
                    "Hide Anchor 1 Window"));

            #endregion

            #region anchor 2 window

            CommandBarButton buttonAnchor2Window = addinMenu.Controls.Add(
                MsoControlType.msoControlButton,
                System.Type.Missing,
                System.Type.Missing,
                System.Type.Missing,
                true) as CommandBarButton;

            buttonAnchor2Window.Caption = "Toggle Anchor 2 Window";
            buttonAnchor2Window.Tag = TAG_ANCHOR2;

            buttonAnchor2Window.Click += new _CommandBarButtonEvents_ClickEventHandler(Globals.ThisAddIn.buttonAnchor2_Click);

            buttonAnchor2Window.FaceId = 191;

            this._CommandBarButtons.Add(
                new VisioCommandBarButtonForAnchorWindow(
                    Globals.ThisAddIn.Application,
                    buttonAnchor2Window,
                    ButtonEnabled.DocumentActive,
                    "Anchor 2 Window"));

            #endregion

            #region About

            // About
            CommandBarButton buttonAbout = addinMenu.Controls.Add(
                MsoControlType.msoControlButton,
                System.Type.Missing,
                System.Type.Missing,
                System.Type.Missing,
                true) as CommandBarButton;

            buttonAbout.Caption = "About...AlwaysActive";
            buttonAbout.Tag = TAG_ABOUT;
            buttonAbout.BeginGroup = true;

            buttonAbout.Click += new _CommandBarButtonEvents_ClickEventHandler(Globals.ThisAddIn.buttonAbout_Click);

            _CommandBarButtons.Add(
                new VisioCommandBarButton(
                    Globals.ThisAddIn.Application,
                    buttonAbout,
                    ButtonEnabled.AlwaysActive));

            #endregion
        }

        #endregion
    }
}