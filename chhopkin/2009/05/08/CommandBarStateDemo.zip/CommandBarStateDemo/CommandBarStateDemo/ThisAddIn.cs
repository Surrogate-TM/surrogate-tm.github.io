﻿//-----------------------------------------------------------------------
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

using Visio = Microsoft.Office.Interop.Visio;

using Microsoft.Office.Core;
using Office = Microsoft.Office.Core;

namespace CommandBarStateDemo
{
    public partial class ThisAddIn
    {
        #region fields

        private UIMgr _UIMgr;

        private Dictionary<int, Document> documents;

        #endregion

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            /* init locals */
            this.documents = new Dictionary<int, Document>();

            /* setup UI */
            _UIMgr = new UIMgr();
            _UIMgr.AddUI();
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            // remove our customizations from the UI during shutdown
            // this handles the user unchecking the add-in from the list of managed add-in from
            // the Trust Center
            _UIMgr.RemoveUI();
        }

        #region properties

        internal Document ActiveDocument
        {
            get
            {
                if (this.Application == null || this.Application.ActiveDocument == null)
                {
                    return null;
                }

                // return the instance of the document that we are wrapping
                if (this.Documents.ContainsKey(this.Application.ActiveDocument.ID))
                {
                    return this.documents[this.Application.ActiveDocument.ID];
                }
                else
                {
                    return null;
                }
            }
        }

        internal Dictionary<int, Document> Documents
        {
            get
            {
                return this.documents;
            }
        }

        #endregion

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion

        internal bool CheckScope_OurDocument()
        {
            // code to determine is the active document is our document
            // in this case if the document is from the Basic Template then it is our document
            return Application.ActiveDocument.Template.EndsWith("BASICD_U.VST");
        }

        internal void buttonItem1_Click(CommandBarButton Ctrl, ref bool CancelDefault)
        {
            System.Windows.Forms.MessageBox.Show("Item 1");
        }

        internal void buttonItem2_Click(CommandBarButton Ctrl, ref bool CancelDefault)
        {
            System.Windows.Forms.MessageBox.Show("Item 2");
        }

        internal void buttonItem3_Click(CommandBarButton Ctrl, ref bool CancelDefault)
        {
            System.Windows.Forms.MessageBox.Show("Item 3");
        }

        internal void buttonAnchor1_Click(CommandBarButton Ctrl, ref bool CancelDefault)
        {
            // get/create the document wrapper
            if (Globals.ThisAddIn.ActiveDocument == null)
            {
                // create our document wrapper
                Document newDoc = null;
                Document.TryCreate(Globals.ThisAddIn.Application.ActiveDocument, out newDoc);

                Globals.ThisAddIn.Documents.Add(newDoc.VisioDocument.ID, newDoc);
            }

            Document activeDocument = Globals.ThisAddIn.ActiveDocument;

            // what to do based on the button parameter
            if (Ctrl.Parameter == "hide")
            {
                // calling Close on the Visio.Window that our form is shown in triggers the Visio.Window.BeforeWindowClose() event
                //toggleForm.AnchorWindow.Close();

                activeDocument.AnchorForm1.AnchorWindow.Visible = false;

                // in this case we will just hide the Visio.Window so that position and state will be persisted for us
            }
            else
            {
                // create our form if we have not already
                if (activeDocument.AnchorForm1 == null)
                {
                    activeDocument.AnchorForm1 = new AnchorForm1();
                }

                if (activeDocument.AnchorForm1.AnchorWindow == null)
                {
                    // create the anchor window if we have not already
                    activeDocument.AnchorForm1.Show(
                        Globals.ThisAddIn.Application.ActiveWindow,
                        "Anchor 1 Window", // this must match the windowCaption arg that was used to create the button
                        null,
                        null);
                }
                else
                {
                    // show it if it is just hidden
                    activeDocument.AnchorForm1.AnchorWindow.Visible = true;
                }
            }

            // fire a blank markever event to make sure that NonePending fires
            // which is the main trigger for our CommandBarButtons to refresh
            Globals.ThisAddIn.Application.QueueMarkerEvent("");
        }

        internal void buttonAnchor2_Click(CommandBarButton Ctrl, ref bool CancelDefault)
        {
            // get/create the document wrapper
            if (Globals.ThisAddIn.ActiveDocument == null)
            {
                // create our document wrapper
                Document newDoc = null;
                Document.TryCreate(Globals.ThisAddIn.Application.ActiveDocument, out newDoc);

                Globals.ThisAddIn.Documents.Add(newDoc.VisioDocument.ID, newDoc);
            }

            Document activeDocument = Globals.ThisAddIn.ActiveDocument;

            // what to do based on the button parameter
            if (Ctrl.Parameter == "hide")
            {
                // calling Close on the Visio.Window that our form is shown in triggers the Visio.Window.BeforeWindowClose() event
                //toggleForm.AnchorWindow.Close();

                activeDocument.AnchorForm2.AnchorWindow.Visible = false;

                // in this case we will just hide the Visio.Window so that position and state will be persisted for us
            }
            else
            {
                // create our form if we have not already
                if (activeDocument.AnchorForm2 == null)
                {
                    activeDocument.AnchorForm2 = new AnchorForm2();
                }

                if (activeDocument.AnchorForm2.AnchorWindow == null)
                {
                    // create the anchor window if we have not already
                    activeDocument.AnchorForm2.Show(
                        Globals.ThisAddIn.Application.ActiveWindow,
                        "Anchor 2 Window", // this must match the windowCaption arg that was used to create the button
                        null,
                        null);
                }
                else
                {
                    // show it if it is just hidden
                    activeDocument.AnchorForm2.AnchorWindow.Visible = true;
                }
            }

            // fire a blank markever event to make sure that NonePending fires
            // which is the main trigger for our CommandBarButtons to refresh
            Globals.ThisAddIn.Application.QueueMarkerEvent("");
        }

        internal void buttonAbout_Click(CommandBarButton Ctrl, ref bool CancelDefault)
        {
            System.Windows.Forms.MessageBox.Show("About");
        }
    }
}
