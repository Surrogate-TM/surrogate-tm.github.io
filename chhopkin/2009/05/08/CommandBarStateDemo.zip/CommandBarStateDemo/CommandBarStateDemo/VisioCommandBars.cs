﻿//-----------------------------------------------------------------------
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

namespace CommandBarStateDemo
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Office.Core;

    using Visio = Microsoft.Office.Interop.Visio;

    [Flags]
    internal enum ButtonEnabled : int
    {
        Custom = 0,
        AlwaysActive = 1,
        DocumentActive = 2,
        SelectionActive = 4,
    }

    public delegate bool CheckScopeCallback();

    public interface IVisioCommandBarItem
    {
        string Tag
        {
            get;
        }
    }

    /// <summary>
    /// Wrapper class for Office.CommandBarButton objects
    /// </summary>
    internal sealed class VisioCommandBarButton : IVisioCommandBarItem
    {
        #region fields

        private Visio.Application visioApplication;

        private string tag;
        private Microsoft.Office.Core.CommandBarButton commandBarButton;

        private Microsoft.Office.Core.MsoButtonState state = Microsoft.Office.Core.MsoButtonState.msoButtonUp;

        private ButtonEnabled enabledState = ButtonEnabled.AlwaysActive;

        private CheckScopeCallback checkScopeCallback = null;

        private bool update = true;

        #endregion

        #region construction / destruction

        /// <summary>
        /// Initializes a new instance of the VisioCommandBarButton class.
        /// </summary>
        /// <param name="button">
        /// The Office.CommandBarButton to wrap.
        /// </param>
        public VisioCommandBarButton(
            Visio.Application visioApplication,
            Microsoft.Office.Core.CommandBarButton commandBarButton,
            ButtonEnabled enabledState)
        {
            System.Diagnostics.Debug.WriteLine("VisioCommandBarButton::Constructor");

            this.visioApplication = visioApplication;

            this.tag = commandBarButton.Tag; // store the tag so we can search for it later
            this.enabledState = enabledState;

            this.commandBarButton = commandBarButton; // keep a ref to this button to keep it alive and to access Visio.Application instance

            // setup the event sink for this application object
            this.VisioEvents_Connect();
        }

        /// <summary>
        /// Initializes a new instance of the VisioCommandBarButton class.
        /// </summary>
        /// <param name="button">
        /// The Office.CommandBarButton to wrap.
        /// </param>
        public VisioCommandBarButton(
            Visio.Application visioApplication,
            Microsoft.Office.Core.CommandBarButton commandBarButton,
            ButtonEnabled enabledState,
            CheckScopeCallback checkScopeCallback)
        {
            System.Diagnostics.Debug.WriteLine("VisioCommandBarButton::Constructor");

            this.visioApplication = visioApplication;

            this.tag = commandBarButton.Tag; // store the tag so we can search for it later
            this.enabledState = enabledState;

            this.checkScopeCallback = checkScopeCallback;

            this.commandBarButton = commandBarButton; // keep a ref to this button to keep it alive

            // setup the event sink for this application object
            this.VisioEvents_Connect();
        }

        /// <summary>
        /// Prevents a default instance of the VisioCommandBarButton class from being created.
        /// </summary>
        private VisioCommandBarButton()
        {
        }

        #endregion

        #region visio events

        /// <summary>
        ///	Setup the event sinks at the Visio Application object level.
        /// </summary>
        private void VisioEvents_Connect()
        {
            if (this.visioApplication != null)
            {
                this.visioApplication.AppObjActivated += new Microsoft.Office.Interop.Visio.EApplication_AppObjActivatedEventHandler(this.VisioApplication_AppObjActivated);
                this.visioApplication.AfterModal += new Microsoft.Office.Interop.Visio.EApplication_AfterModalEventHandler(this.VisioApplication_AfterModal);

                this.visioApplication.WindowOpened += new Microsoft.Office.Interop.Visio.EApplication_WindowOpenedEventHandler(this.VisioApplication_WindowOpened);
                this.visioApplication.WindowActivated += new Microsoft.Office.Interop.Visio.EApplication_WindowActivatedEventHandler(this.VisioApplication_WindowActivated);
                this.visioApplication.WindowChanged += new Microsoft.Office.Interop.Visio.EApplication_WindowChangedEventHandler(this.VisioApplication_WindowChanged);

                this.visioApplication.BeforeWindowClosed += new Microsoft.Office.Interop.Visio.EApplication_BeforeWindowClosedEventHandler(this.VisioApplication_BeforeWindowClosed);

                if ((this.enabledState & ButtonEnabled.SelectionActive) == ButtonEnabled.SelectionActive)
                {
                    this.visioApplication.SelectionChanged += new Microsoft.Office.Interop.Visio.EApplication_SelectionChangedEventHandler(this.VisioApplication_SelectionChanged);
                }

                this.visioApplication.MarkerEvent += new Microsoft.Office.Interop.Visio.EApplication_MarkerEventEventHandler(this.VisioApplication_MarkerEvent);

                if (this.enabledState > ButtonEnabled.AlwaysActive)
                {
                    this.visioApplication.VisioIsIdle += new Microsoft.Office.Interop.Visio.EApplication_VisioIsIdleEventHandler(this.VisioApplication_VisioIsIdle);
                }
            }
        }

        /// <summary>
        /// Handler for MarkerEvent from Visio.Application
        /// 
        /// I added this as some built in Visio solutions fire empty marker events while they are performing actions in the drawing and the UI
        /// this seems to help keep our ui updated with visio solution UI changes
        /// </summary>
        /// <param name="visioApplication"></param>
        /// <param name="SequenceNum"></param>
        /// <param name="ContextString"></param>
        private void VisioApplication_MarkerEvent(
            Visio.Application visioApplication,
            int sequenceNum,
            string contextString)
        {
            if (contextString == null || contextString.Trim() == string.Empty)
            {
                this.update = true;
            }
        }

        private void VisioApplication_VisioIsIdle(
            Visio.Application visioApplication)
        {
            // update the state of this button
            if (this.update)
            {
                this.UpdateState(visioApplication.ActiveWindow);

                this.update = false;
            }
        }

        private void VisioApplication_AfterModal(
            Visio.Application visioApplication)
        {
            this.update = true;
        }

        private void VisioApplication_AppObjActivated(
            Visio.Application visioApplication)
        {
            this.update = true;
        }

        private void VisioApplication_WindowActivated(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        private void VisioApplication_WindowChanged(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        private void VisioApplication_SelectionChanged(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        private void VisioApplication_WindowOpened(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        private void VisioApplication_BeforeWindowClosed(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        #endregion

        #region methods

        /// <summary>
        /// Sets the state of the CommandBarButton that this instance is wrapping.
        /// </summary>
        /// <param name="state">
        /// The new state value to set.
        /// </param>
        internal void SetState(
            Microsoft.Office.Core.MsoButtonState state)
        {
            // set the property for this wrapper
            this.state = state;

            // get the application level command bars
            Microsoft.Office.Core.CommandBars visioCommandBars = this.visioApplication.CommandBars as Microsoft.Office.Core.CommandBars;

            // find the menu CommandBarButton with this tag
            Microsoft.Office.Core.CommandBarButton foundMenuButton = visioCommandBars["Menu Bar"].FindControl(Microsoft.Office.Core.MsoControlType.msoControlButton, 0, this.tag, true, true) as Microsoft.Office.Core.CommandBarButton;

            if (foundMenuButton != null)
            {
                if (foundMenuButton.State != state)
                {
                    foundMenuButton.State = state;
                }
            }

            // find the toolbar CommandBarButton with this tag
            Microsoft.Office.Core.CommandBarButton foundToolbarButton = visioCommandBars.FindControl(Microsoft.Office.Core.MsoControlType.msoControlButton, 0, this.tag, true) as Microsoft.Office.Core.CommandBarButton;

            if (foundToolbarButton != null)
            {
                if (foundToolbarButton.State != state)
                {
                    // this is a drawing window so enable it
                    foundToolbarButton.State = state;
                }
            }
        }

        /// <summary>
        /// UpdateEnabledState method to update the state of the UI Item.
        /// </summary>
        public void UpdateState(
            Visio.Window visioWindow)
        {
            if (this.enabledState == ButtonEnabled.AlwaysActive)
            {
                return;
            }

            bool enabled = false; // default to false and prove that it is true below

            switch (this.enabledState)
            {
                case ButtonEnabled.Custom:
                    {
                        // just call the custom call back
                        // the callback must exist and must return true to enable the item
                        if (this.checkScopeCallback != null)
                        {
                            enabled = this.checkScopeCallback();
                        }

                        break;
                    }

                case ButtonEnabled.DocumentActive:
                    {
                        if (visioWindow != null &&
                            visioWindow.Document != null)
                        {
                            if (this.checkScopeCallback != null)
                            {
                                enabled = this.checkScopeCallback();
                            }
                            else
                            {
                                // no callback exists but there is an active document so return true
                                enabled = true;
                            }
                        }

                        break;
                    }

                case ButtonEnabled.SelectionActive:
                    {
                        if (visioWindow != null)
                        {
                            Visio.Selection visioSelection = visioWindow.Selection;

                            if (visioSelection != null)
                            {
                                Visio.Shape selectedShape = null;

                                if (visioSelection.Count > 0)
                                {
                                    selectedShape = visioSelection.PrimaryItem;
                                }
                                else
                                {
                                    visioSelection.IterationMode = (int)Visio.VisSelectMode.visSelModeOnlySub;
                                }

                                selectedShape = visioSelection.PrimaryItem;

                                if (selectedShape != null)
                                {
                                    if (this.checkScopeCallback != null)
                                    {
                                        enabled = this.checkScopeCallback();
                                    }
                                    else
                                    {
                                        // no callback exists but there is a selection so return true
                                        enabled = true;
                                    }
                                }
                            }
                        }

                        break;
                    }

                default:
                    {
                        enabled = false;
                        break;
                    }
            }

            // get the application level command bars object
            Microsoft.Office.Core.CommandBars visioCommandBars = this.visioApplication.CommandBars as Microsoft.Office.Core.CommandBars;

            Microsoft.Office.Core.CommandBarControls foundControls = visioCommandBars.FindControls(
                System.Reflection.Missing.Value,
                System.Reflection.Missing.Value,
                this.tag,
                System.Reflection.Missing.Value) as Microsoft.Office.Core.CommandBarControls;

            // in full screen mode no controls will be found so return
            if (foundControls == null)
            {
                return;
            }

            // look at each found control and set appropriate state
            foreach (Microsoft.Office.Core.CommandBarControl nextControl in foundControls)
            {
                if (nextControl.Enabled != enabled)
                {
                    nextControl.Enabled = enabled;
                }

                if (nextControl.Type == Microsoft.Office.Core.MsoControlType.msoControlButton)
                {
                    Microsoft.Office.Core.CommandBarButton nextButton = nextControl as Microsoft.Office.Core.CommandBarButton;
                    
                    if (nextButton != null)
                    {
                        if (nextButton.State != this.state)
                        {
                            nextButton.State = this.state;
                        }
                    }
                }
            }
        }

        #endregion

        #region IVisioCommandBarItem Members

        public string Tag
        {
            get { return this.tag; }
        }

        #endregion
    }

    /// <summary>
    /// Wrapper class for Office.CommandBarButton objects
    /// </summary>
    internal sealed class VisioCommandBarPopup : IVisioCommandBarItem
    {
        #region fields

        private Visio.Application visioApplication;

        private string tag;
        private Microsoft.Office.Core.CommandBarPopup commandBarPopup;

        private ButtonEnabled enabledState = ButtonEnabled.AlwaysActive;

        private CheckScopeCallback checkScopeCallback = null;
        private string checkScopeCellName = string.Empty;
        private string checkScopeCellValue = string.Empty;

        private bool update = true;

        #endregion

        #region construction / destruction

        /// <summary>
        /// Initializes a new instance of the VisioCommandBarPopup class.
        /// </summary>
        /// <param name="button">
        /// The Office.CommandBarPopup to wrap.
        /// </param>
        public VisioCommandBarPopup(
            Visio.Application visioApplication,
            Microsoft.Office.Core.CommandBarPopup commandBarPopup,
            ButtonEnabled enabledState)
        {
            System.Diagnostics.Debug.WriteLine("VisioCommandBarPopup::Constructor");

            this.visioApplication = visioApplication;

            this.tag = commandBarPopup.Tag; // store the tag so we can search for it later
            this.enabledState = enabledState;

            this.commandBarPopup = commandBarPopup; // keep a ref to this button to keep it alive

            // setup the event sink for this application object
            this.VisioEvents_Connect();
        }

        /// <summary>
        /// Initializes a new instance of the VisioCommandBarPopup class.
        /// </summary>
        /// <param name="button">
        /// The Office.CommandBarPopup to wrap.
        /// </param>
        public VisioCommandBarPopup(
            Visio.Application visioApplication,
            Microsoft.Office.Core.CommandBarPopup commandBarPopup,
            ButtonEnabled enabledState,
            CheckScopeCallback checkScopeCallback,
            string checkScopeCellName,
            string checkScopeCellValue)
        {
            System.Diagnostics.Debug.WriteLine("VisioCommandBarPopup::Constructor");

            this.visioApplication = visioApplication;

            this.tag = commandBarPopup.Tag; // store the tag so we can search for it later
            this.enabledState = enabledState;

            this.checkScopeCallback = checkScopeCallback;
            this.checkScopeCellName = checkScopeCellName;
            this.checkScopeCellValue = checkScopeCellValue;

            this.commandBarPopup = commandBarPopup; // keep a ref to this button to keep it alive

            // setup the event sink for this application object
            this.VisioEvents_Connect();
        }

        /// <summary>
        /// Prevents a default instance of the VisioCommandBarPopup class from being created.
        /// </summary>
        private VisioCommandBarPopup()
        {
        }

        #endregion

        #region visio events

        /// <summary>
        ///	Setup the event sinks at the Visio Application object level.
        /// </summary>
        private void VisioEvents_Connect()
        {
            if (this.visioApplication != null)
            {
                this.visioApplication.AppObjActivated += new Microsoft.Office.Interop.Visio.EApplication_AppObjActivatedEventHandler(this.VisioApplication_AppObjActivated);
                this.visioApplication.AfterModal += new Microsoft.Office.Interop.Visio.EApplication_AfterModalEventHandler(this.VisioApplication_AfterModal);

                this.visioApplication.WindowOpened += new Microsoft.Office.Interop.Visio.EApplication_WindowOpenedEventHandler(this.VisioApplication_WindowOpened);
                this.visioApplication.WindowActivated += new Microsoft.Office.Interop.Visio.EApplication_WindowActivatedEventHandler(this.VisioApplication_WindowActivated);
                this.visioApplication.WindowChanged += new Microsoft.Office.Interop.Visio.EApplication_WindowChangedEventHandler(this.VisioApplication_WindowChanged);

                this.visioApplication.BeforeWindowClosed += new Microsoft.Office.Interop.Visio.EApplication_BeforeWindowClosedEventHandler(this.VisioApplication_BeforeWindowClosed);

                if ((this.enabledState & ButtonEnabled.SelectionActive) == ButtonEnabled.SelectionActive)
                {
                    this.visioApplication.SelectionChanged += new Microsoft.Office.Interop.Visio.EApplication_SelectionChangedEventHandler(this.VisioApplication_SelectionChanged);
                }

                this.visioApplication.MarkerEvent += new Microsoft.Office.Interop.Visio.EApplication_MarkerEventEventHandler(this.VisioApplication_MarkerEvent);

                if (this.enabledState > ButtonEnabled.AlwaysActive)
                {
                    this.visioApplication.VisioIsIdle += new Microsoft.Office.Interop.Visio.EApplication_VisioIsIdleEventHandler(this.VisioApplication_VisioIsIdle);
                }
            }
        }

        /// <summary>
        /// Handler for MarkerEvent from Visio.Application
        /// 
        /// I added this as some built in Visio solutions fire empty marker events while they are performing actions in the drawing and the UI
        /// this seems to help keep our ui updated with visio solution UI changes
        /// </summary>
        /// <param name="visioApplication"></param>
        /// <param name="SequenceNum"></param>
        /// <param name="ContextString"></param>
        private void VisioApplication_MarkerEvent(
            Visio.Application visioApplication,
            int sequenceNum,
            string contextString)
        {
            if (contextString == null || contextString.Trim() == string.Empty)
            {
                this.update = true;
            }
        }

        private void VisioApplication_VisioIsIdle(
            Visio.Application visioApplication)
        {
            // update the state of this button
            if (this.update)
            {
                this.UpdateState(visioApplication.ActiveWindow);

                this.update = false;
            }
        }

        private void VisioApplication_AfterModal(
            Visio.Application visioApplication)
        {
            this.update = true;
        }

        private void VisioApplication_AppObjActivated(
            Visio.Application visioApplication)
        {
            this.update = true;
        }

        private void VisioApplication_WindowActivated(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        void VisioApplication_WindowChanged(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        private void VisioApplication_SelectionChanged(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        private void VisioApplication_WindowOpened(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        private void VisioApplication_BeforeWindowClosed(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        #endregion

        #region methods

        /// <summary>
        /// UpdateState method to update the state of the UI Item.
        /// Popup only supports Enabled / Disabled states
        /// </summary>
        public void UpdateState(
            Visio.Window visioWindow)
        {
            if (this.enabledState == ButtonEnabled.AlwaysActive)
            {
                return;
            }

            bool enabled = false; // default to false and prove that it is true below

            switch (this.enabledState)
            {
                case ButtonEnabled.Custom:
                    {
                        // just call the custom call back
                        // the callback must exist and must return true to enable the item
                        if (this.checkScopeCallback != null)
                        {
                            enabled = this.checkScopeCallback();
                        }

                        break;
                    }

                case ButtonEnabled.DocumentActive:
                    {
                        if (visioWindow != null &&
                            visioWindow.Document != null)
                        {
                            if (this.checkScopeCallback != null)
                            {
                                enabled = this.checkScopeCallback();
                            }
                            else
                            {
                                // no callback exists but there is an active document so return true
                                enabled = true;
                            }
                        }

                        break;
                    }

                case ButtonEnabled.SelectionActive:
                    {
                        if (visioWindow != null)
                        {
                            Visio.Selection visioSelection = visioWindow.Selection;

                            if (visioSelection != null)
                            {
                                Visio.Shape selectedShape = null;

                                if (visioSelection.Count > 0)
                                {
                                    selectedShape = visioSelection.PrimaryItem;
                                }
                                else
                                {
                                    visioSelection.IterationMode = (int)Visio.VisSelectMode.visSelModeOnlySub;
                                }

                                selectedShape = visioSelection.PrimaryItem;

                                if (selectedShape != null)
                                {
                                    if (this.checkScopeCallback != null)
                                    {
                                        enabled = this.checkScopeCallback();
                                    }
                                    else
                                    {
                                        // no callback exists but there is a selection so return true
                                        enabled = true;
                                    }
                                }
                            }
                        }

                        break;
                    }

                default:
                    {
                        enabled = false;
                        break;
                    }
            }

            // get the application level command bars object
            Microsoft.Office.Core.CommandBars visioCommandBars = this.visioApplication.CommandBars as Microsoft.Office.Core.CommandBars;

            Microsoft.Office.Core.CommandBarControls foundControls = visioCommandBars.FindControls(
                System.Reflection.Missing.Value,
                System.Reflection.Missing.Value,
                this.tag,
                System.Reflection.Missing.Value) as Microsoft.Office.Core.CommandBarControls;

            // in full screen mode no controls will be found so return
            if (foundControls == null)
            {
                return;
            }

            // look at each found control and set appropriate state
            foreach (Microsoft.Office.Core.CommandBarControl nextControl in foundControls)
            {
                if (nextControl.Enabled != enabled)
                {
                    nextControl.Enabled = enabled;
                }
            }
        }

        #endregion

        #region IVisioCommandBarItem Members

        public string Tag
        {
            get { return this.tag; }
        }

        #endregion
    }

    /// <summary>
    /// Wrapper class for Office.CommandBarButton objects
    /// </summary>
    internal sealed class VisioCommandBarButtonForAnchorWindow : IVisioCommandBarItem
    {
        #region fields

        private Visio.Application visioApplication;

        private string tag;
        private Microsoft.Office.Core.CommandBarButton commandBarButton;

        private Microsoft.Office.Core.MsoButtonState state = Microsoft.Office.Core.MsoButtonState.msoButtonUp;

        private ButtonEnabled enabledState = ButtonEnabled.AlwaysActive;

        private CheckScopeCallback checkScopeCallback = null;

        private bool update = true;

        #endregion

        #region construction / destruction

        /// <summary>
        /// Initializes a new instance of the VisioCommandBarButton class.
        /// </summary>
        /// <param name="button">
        /// The Office.CommandBarButton to wrap.
        /// </param>
        public VisioCommandBarButtonForAnchorWindow(
            Visio.Application visioApplication,
            Microsoft.Office.Core.CommandBarButton commandBarButton,
            ButtonEnabled enabledState,
            string windowCaption,
            string captionToShow,
            string captionToHide)
        {
            System.Diagnostics.Debug.WriteLine("VisioCommandBarButtonForAnchorWindow::Constructor");

            this.visioApplication = visioApplication;

            // store the tag so we can search for it later to find all the commandbar controls for this wrapper
            this.tag = commandBarButton.Tag;

            // init the enabled state
            this.enabledState = enabledState;

            // keep a ref to this button to keep it alive and to access Visio.Application instance
            this.commandBarButton = commandBarButton;

            // set the strings to use to toggle the caption of the button
            this.CaptionForShow = captionToShow;
            this.CaptionForHide = captionToHide;

            this.WindowCaption = windowCaption;

            // setup the event sink for this application object
            this.VisioEvents_Connect();
        }

        /// <summary>
        /// Initializes a new instance of the VisioCommandBarButton class.
        /// </summary>
        /// <param name="button">
        /// The Office.CommandBarButton to wrap.
        /// </param>
        public VisioCommandBarButtonForAnchorWindow(
            Visio.Application visioApplication,
            Microsoft.Office.Core.CommandBarButton commandBarButton,
            ButtonEnabled enabledState,
            string windowCaption)
        {
            System.Diagnostics.Debug.WriteLine("VisioCommandBarButtonForAnchorWindow::Constructor");

            this.visioApplication = visioApplication;

            // store the tag so we can search for it later to find all the commandbar controls for this wrapper
            this.tag = commandBarButton.Tag;

            // init the enabled state
            this.enabledState = enabledState;

            // keep a ref to this button to keep it alive and to access Visio.Application instance
            this.commandBarButton = commandBarButton;

            // FYI - this version does not set any captions so it toggles the State of the button
            this.ToggleState = true;

            this.WindowCaption = windowCaption;

            // setup the event sink for this application object
            this.VisioEvents_Connect();
        }

        /// <summary>
        /// Initializes a new instance of the VisioCommandBarButton class.
        /// </summary>
        /// <param name="button">
        /// The Office.CommandBarButton to wrap.
        /// </param>
        public VisioCommandBarButtonForAnchorWindow(
            Visio.Application visioApplication,
            Microsoft.Office.Core.CommandBarButton commandBarButton,
            ButtonEnabled enabledState,
            CheckScopeCallback checkScopeCallback,
            string windowCaption,
            string captionToShow,
            string captionToHide)
        {
            System.Diagnostics.Debug.WriteLine("VisioCommandBarButtonForAnchorWindow::Constructor");

            this.visioApplication = visioApplication;

            // store the tag so we can search for it later to find all the commandbar controls for this wrapper
            this.tag = commandBarButton.Tag;

            // init the enabled state
            this.enabledState = enabledState;

            // store the callback that we will call to determine scope
            this.checkScopeCallback = checkScopeCallback;

            // keep a ref to this button to keep it alive
            this.commandBarButton = commandBarButton;

            // set the strings to use to toggle the caption of the button
            this.CaptionForShow = captionToShow;
            this.CaptionForHide = captionToHide;

            this.WindowCaption = windowCaption;

            // setup the event sink for this application object
            this.VisioEvents_Connect();
        }

        /// <summary>
        /// Initializes a new instance of the VisioCommandBarButton class.
        /// </summary>
        /// <param name="button">
        /// The Office.CommandBarButton to wrap.
        /// </param>
        public VisioCommandBarButtonForAnchorWindow(
            Visio.Application visioApplication,
            Microsoft.Office.Core.CommandBarButton commandBarButton,
            ButtonEnabled enabledState,
            CheckScopeCallback checkScopeCallback,
            string windowCaption)
        {
            System.Diagnostics.Debug.WriteLine("VisioCommandBarButtonForAnchorWindow::Constructor");

            this.visioApplication = visioApplication;

            // store the tag so we can search for it later to find all the commandbar controls for this wrapper
            this.tag = commandBarButton.Tag;

            // init the enabled state
            this.enabledState = enabledState;

            // store the callback that we will call to determine scope
            this.checkScopeCallback = checkScopeCallback;

            // keep a ref to this button to keep it alive
            this.commandBarButton = commandBarButton;

            // FYI - this version does not set any captions so it toggles the State of the button
            this.ToggleState = true;

            this.WindowCaption = windowCaption;

            // setup the event sink for this application object
            this.VisioEvents_Connect();
        }

        /// <summary>
        /// Prevents a default instance of the VisioCommandBarButtonForAnchorWindow class from being created.
        /// </summary>
        private VisioCommandBarButtonForAnchorWindow()
        {
        }

        #endregion

        #region properties

        public string WindowCaption
        {
            get;
            set;
        }

        public string CaptionForHide
        {
            get;
            set;
        }

        public string CaptionForShow
        {
            get;
            set;
        }

        public bool ToggleState
        {
            get;
            set;
        }

        #endregion

        #region visio events

        /// <summary>
        ///	Setup the event sinks at the Visio Application object level.
        /// </summary>
        private void VisioEvents_Connect()
        {
            if (this.visioApplication != null)
            {
                this.visioApplication.AppObjActivated += new Microsoft.Office.Interop.Visio.EApplication_AppObjActivatedEventHandler(this.VisioApplication_AppObjActivated);
                this.visioApplication.AfterModal += new Microsoft.Office.Interop.Visio.EApplication_AfterModalEventHandler(this.VisioApplication_AfterModal);

                this.visioApplication.WindowOpened += new Microsoft.Office.Interop.Visio.EApplication_WindowOpenedEventHandler(this.VisioApplication_WindowOpened);
                this.visioApplication.WindowActivated += new Microsoft.Office.Interop.Visio.EApplication_WindowActivatedEventHandler(this.VisioApplication_WindowActivated);
                this.visioApplication.WindowChanged += new Microsoft.Office.Interop.Visio.EApplication_WindowChangedEventHandler(this.VisioApplication_WindowChanged);

                this.visioApplication.BeforeWindowClosed += new Microsoft.Office.Interop.Visio.EApplication_BeforeWindowClosedEventHandler(this.VisioApplication_BeforeWindowClosed);

                if ((this.enabledState & ButtonEnabled.SelectionActive) == ButtonEnabled.SelectionActive)
                {
                    this.visioApplication.SelectionChanged += new Microsoft.Office.Interop.Visio.EApplication_SelectionChangedEventHandler(this.VisioApplication_SelectionChanged);
                }

                this.visioApplication.MarkerEvent += new Microsoft.Office.Interop.Visio.EApplication_MarkerEventEventHandler(this.VisioApplication_MarkerEvent);

                if (this.enabledState > ButtonEnabled.AlwaysActive)
                {
                    this.visioApplication.VisioIsIdle += new Microsoft.Office.Interop.Visio.EApplication_VisioIsIdleEventHandler(this.VisioApplication_VisioIsIdle);
                }
            }
        }

        /// <summary>
        /// Handler for MarkerEvent from Visio.Application
        /// 
        /// I added this as some built in Visio solutions fire empty marker events while they are performing actions in the drawing and the UI
        /// this seems to help keep our ui updated with visio solution UI changes
        /// </summary>
        /// <param name="visioApplication"></param>
        /// <param name="SequenceNum"></param>
        /// <param name="ContextString"></param>
        private void VisioApplication_MarkerEvent(
            Visio.Application visioApplication,
            int sequenceNum,
            string contextString)
        {
            if (contextString == null || contextString.Trim() == string.Empty)
            {
                this.update = true;
            }
        }

        private void VisioApplication_VisioIsIdle(
            Visio.Application visioApplication)
        {
            // update the state of this button
            if (this.update)
            {
                this.UpdateState(visioApplication.ActiveWindow);

                this.update = false;
            }
        }

        private void VisioApplication_AfterModal(
            Visio.Application visioApplication)
        {
            this.update = true;
        }

        private void VisioApplication_AppObjActivated(
            Visio.Application visioApplication)
        {
            this.update = true;
        }

        private void VisioApplication_WindowActivated(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        private void VisioApplication_WindowChanged(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        private void VisioApplication_SelectionChanged(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        private void VisioApplication_WindowOpened(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        private void VisioApplication_BeforeWindowClosed(
            Visio.Window visioWindow)
        {
            this.update = true;
        }

        #endregion

        #region methods

        /// <summary>
        /// Sets the state of the CommandBarButton that this instance is wrapping.
        /// </summary>
        /// <param name="state">
        /// The new state value to set.
        /// </param>
        internal void SetState(
            Microsoft.Office.Core.MsoButtonState state)
        {
            // set the property for this wrapper
            this.state = state;

            // get the application level command bars
            Microsoft.Office.Core.CommandBars visioCommandBars = this.visioApplication.CommandBars as Microsoft.Office.Core.CommandBars;

            // find the menu CommandBarButton with this tag
            Microsoft.Office.Core.CommandBarButton foundMenuButton = visioCommandBars["Menu Bar"].FindControl(Microsoft.Office.Core.MsoControlType.msoControlButton, 0, this.tag, true, true) as Microsoft.Office.Core.CommandBarButton;

            if (foundMenuButton != null)
            {
                if (foundMenuButton.State != state)
                {
                    foundMenuButton.State = state;
                }
            }

            // find the toolbar CommandBarButton with this tag
            Microsoft.Office.Core.CommandBarButton foundToolbarButton = visioCommandBars.FindControl(Microsoft.Office.Core.MsoControlType.msoControlButton, 0, this.tag, true) as Microsoft.Office.Core.CommandBarButton;

            if (foundToolbarButton != null)
            {
                if (foundToolbarButton.State != state)
                {
                    // this is a drawing window so enable it
                    foundToolbarButton.State = state;
                }
            }
        }

        /// <summary>
        /// UpdateEnabledState method to update the state of the UI Item.
        /// </summary>
        public void UpdateState(
            Visio.Window visioWindow)
        {
            bool ourWindowIsVisible = false;

            // find our window in this windows collection (ie. child window)
            if (visioWindow != null)
            {
                foreach (Visio.Window nextWindow in visioWindow.Windows)
                {
                    if (nextWindow.Caption == this.WindowCaption)
                    {
                        // this is our window, get if it is visible or not
                        ourWindowIsVisible = nextWindow.Visible;
                        break;
                    }
                }
            }

            bool enabled = false; // default to false and prove that it is true below

            switch (this.enabledState)
            {
                case ButtonEnabled.Custom:
                    {
                        // just call the custom call back
                        // the callback must exist and must return true to enable the item
                        if (this.checkScopeCallback != null)
                        {
                            enabled = this.checkScopeCallback();
                        }

                        break;
                    }

                case ButtonEnabled.DocumentActive:
                    {
                        if (visioWindow != null &&
                            visioWindow.Document != null)
                        {
                            if (this.checkScopeCallback != null)
                            {
                                enabled = this.checkScopeCallback();
                            }
                            else
                            {
                                // no callback exists but there is an active document so return true
                                enabled = true;
                            }
                        }

                        break;
                    }

                case ButtonEnabled.SelectionActive:
                    {
                        if (visioWindow != null)
                        {
                            Visio.Selection visioSelection = visioWindow.Selection;

                            if (visioSelection != null)
                            {
                                Visio.Shape selectedShape = null;

                                if (visioSelection.Count > 0)
                                {
                                    selectedShape = visioSelection.PrimaryItem;
                                }
                                else
                                {
                                    visioSelection.IterationMode = (int)Visio.VisSelectMode.visSelModeOnlySub;
                                }

                                selectedShape = visioSelection.PrimaryItem;

                                if (selectedShape != null)
                                {
                                    if (this.checkScopeCallback != null)
                                    {
                                        enabled = this.checkScopeCallback();
                                    }
                                    else
                                    {
                                        // no callback exists but there is a selection so return true
                                        enabled = true;
                                    }
                                }
                            }
                        }

                        break;
                    }

                default:
                    {
                        enabled = false;
                        break;
                    }
            }

            // get the application level command bars object
            Microsoft.Office.Core.CommandBars visioCommandBars = this.visioApplication.CommandBars as Microsoft.Office.Core.CommandBars;

            Microsoft.Office.Core.CommandBarControls foundControls = visioCommandBars.FindControls(
                System.Reflection.Missing.Value,
                System.Reflection.Missing.Value,
                this.tag,
                System.Reflection.Missing.Value) as Microsoft.Office.Core.CommandBarControls;

            // in full screen mode no controls will be found so return
            if (foundControls == null)
            {
                return;
            }

            // look at each found control and set appropriate state
            foreach (Microsoft.Office.Core.CommandBarControl nextControl in foundControls)
            {
                if (nextControl.Enabled != enabled)
                {
                    nextControl.Enabled = enabled;
                }

                if (this.ToggleState)
                {
                    if (nextControl.Type == Microsoft.Office.Core.MsoControlType.msoControlButton)
                    {
                        Microsoft.Office.Core.CommandBarButton nextButton = nextControl as Microsoft.Office.Core.CommandBarButton;

                        if (nextButton != null)
                        {
                            if (ourWindowIsVisible)
                            {
                                nextButton.State = MsoButtonState.msoButtonDown;
                                nextControl.Parameter = "hide";
                            }
                            else
                            {
                                nextButton.State = MsoButtonState.msoButtonUp;
                                nextControl.Parameter = "show";
                            }
                        }
                    }
                }
                else
                {
                    if (ourWindowIsVisible)
                    {
                        nextControl.Caption = this.CaptionForHide;
                        nextControl.Parameter = "hide";
                    }
                    else
                    {
                        nextControl.Caption = this.CaptionForShow;
                        nextControl.Parameter = "show";
                    }
                }
            }
        }

        #endregion

        #region IVisioCommandBarItem Members

        public string Tag
        {
            get { return this.tag; }
        }

        #endregion
    }
}
