<script language="javascript">

// hook up Application event handlers
var app = Sys.Application;

app.add_load(onApplicationLoad);
app.add_unload(onApplicationUnload);

// hold an instance of the Visio VWA control
var vwaControl; 

var shapeSelectionChangedHandler = null;

//----------------------------------------------------------
// Wait till the Visio Web Access HTML & Script has been sent 
// down from the server, and create a VwaControl Object
// (the root Visio Web Access object) for use throughout the
// script.
//
// Also add handlers for the onDiagramComplete & 
// shapeSelectionChanged we'll for the solution.
//----------------------------------------------------------
function onApplicationLoad()
{
    vwaControl= new Vwa.VwaControl("WebPartWPQ3"); // this is the name of the visio web part instance on the web part page
    vwaControl.addHandler("diagramcomplete", onDiagramComplete);
    vwaControl.addHandler("shapeselectionchanged", shapeSelectionChangedHandler);
}

//----------------------------------------------------------
// Handler for unloading of this page.
//----------------------------------------------------------
function onApplicationUnload()
{
    //alert("unloading");
}

//----------------------------------------------------------
// Wait till the default page is loaded by VwaControl; get
// references to all of these objects for later use during 
// the script.
//----------------------------------------------------------
function onDiagramComplete()
{
    var vwaPage = vwaControl.getActivePage(); 
    vwaPage.setZoom(75); // force the initial zoom level
}

//----------------------------------------------------------
// On shape selection changed, this function extracts the
// Shape Data from a shape and passes it along as a URL
// parameter to the HRDataSystem ASPX application that is 
// being displayed in the EmployeeData IFRAME on the page.
//----------------------------------------------------------
shapeSelectionChangedHandler = function(source, args)
{
    // get the selected shape from the shapes on the page
    var vwaPage = vwaControl.getActivePage(); 
    var vwaShapes = vwaPage.getShapes(); 
    var shape = vwaShapes.getItemById(args);

    // get the data to display for the selected shape
    var data = shape.getShapeData();
    
    var strNetworkName = ""; 
    var strIPAddress = "";
    var strAdministrator = ""; 
    var strStatus = ""; 
    
    for (var j = 0; j < data.length; j++)
    {
        if (data[j].label == "Network Name")
        {
            strNetworkName = data[j].value;
            continue;
        } 
        
        if (data[j].label == "IP Address")
        {
            strIPAddress = data[j].value;
            continue;
        }
        
        if (data[j].label == "Administrator")
        {
            strAdministrator = data[j].value;
            continue;
        }        
        
        if (data[j].label == "Status")
        {
            strStatus = data[j].value;
            continue;
        }                
    }
    
    // get the selected state input and set its value
    var inputNetworkName = document.getElementById('strNetworkName');
    inputNetworkName.value = strNetworkName;
    
    var inputIPAddress = document.getElementById('strIPAddress');
    inputIPAddress.value = strIPAddress;
    
    var inputAdministrator = document.getElementById('strAdministrator');
    inputAdministrator.value = strAdministrator;    
    
    var inputStatus = document.getElementById('strStatus');
    inputStatus.value = strStatus;        
}

//----------------------------------------------------------
// Highlight method
//----------------------------------------------------------
function Highlight() 
{
    var vwaPage = vwaControl.getActivePage(); 
    var vwaShapes = vwaPage.getShapes(); 
    var vwaShapeCount = vwaShapes.getCount();
    
    // clean up any existing highlights before we highlight other choices
    for (var nextShapeIndex = 0; nextShapeIndex < vwaShapeCount; nextShapeIndex++)
    {
        var nextShape = vwaShapes.getItemAtIndex(nextShapeIndex);
        
        if (nextShape == null)
        {
            continue;
        }
        else
        {    
            nextShape.removeHighlight();
        }
    }

    //---------------------------------------------------
    // Go through all controls on the page (could be more 
    // efficient) and find the solution's checkboxes. Then
    // Highlight the appropriate shapes by assigning 
    // to rackSetToInterate the the appropriate array of 
    // of shapeIds and iterating though them.
    //---------------------------------------------------
    var inputs = document.getElementsByTagName('input'); 

    var strSelectedStatusValue = "";
    
    for(var i=0; i < inputs.length; i++) 
    {
        // check if the input is a checkbox 
        if (inputs[i].getAttribute('type') == 'radio' && 
            inputs[i].id == "StatusSelector" &&
            inputs[i].checked)
        {
            strSelectedStatusValue = inputs[i].value;
            break;
        }
    }
    
    // chose the color based on the status selected
    var highlightColor = "red";
    if (strSelectedStatusValue == "ok")
    {
        highlightColor = "green";
    }
    
    if (strSelectedStatusValue.length > 0)
    {
        // what we actually want to do here is find the shape based on the ShapeData HealthState property that has a matching
        // value to the selected input control
    
        for (var nextShapeIndex = 0; nextShapeIndex < vwaShapeCount; nextShapeIndex++)
        {
            var nextShape = vwaShapes.getItemAtIndex(nextShapeIndex);
            
            if (nextShape == null)
            {
                continue;
            }
            else
            {
                // inputs[i].value - this is the selected value in the radio control that needs to match the HealthState property in the shape                    
                
                // get the shape data
                var data = nextShape.getShapeData();
                
                for (var j = 0; j < data.length; j++)
                {
                    if (data[j].label == "Status")
                    {
                        if (strSelectedStatusValue.toLowerCase() == data[j].value.toLowerCase())
                        {
                            nextShape.addHighlight(4, highlightColor);
                        }
                        
                        continue;
                    }
                }                    
            }
        }
    }
}

</SCRIPT>

Network Name:<br>
<input id="strNetworkName" name="NetworkName" style="width: 284px" type="text" />

IP Address:<br>
<input id="strIPAddress" name="IPAddress" style="width: 284px" type="text" />

Administrator:<br>
<input id="strAdministrator" name="Administrator" style="width: 284px" type="text" />

Status:<br>
<input id="strStatus" name="Status" style="width: 284px" type="text" />

<br>
<hr>
<br>
Filter Options
<br>

<input type="radio" id="StatusSelector" name="StatusSelector" value="ok" onclick="Highlight()">Online</input><br>
<input type="radio" id="StatusSelector" name="StatusSelector" value="unavailable" onclick="Highlight()">Offline</input><br>
<input type="radio" id="StatusSelector" name="StatusSelector" value="unknown" onclick="Highlight()">Unknown</input><br>
<br>
<input type="radio" id="StatusSelector" name="StatusSelector" value="none" onclick="Highlight()">None</input><br>