﻿namespace VisioSDK
{
    using System;
    using System.Data;
    using System.Data.OleDb;

    // add a reference to
    // C:\Program Files\Microsoft.NET\Primary Interop Assemblies\adodb.dll
    using ADODB;

    /// <summary>
    /// This class provides functions to convert an ADO.NET data table 
    /// to ADO 2.8 classic XML from which Visio can create a DataRecordset using the 
    /// AddFromXML method on the Datarecordsets object.
    /// <para />
    /// Instantiate ADONET2ADO and call ConvertDataTableAndImportIntoVisio
    /// to drive a demontration of the functionality described above. 
    /// <para />
    /// NOTE: a reference to the adodb .NET component is required
    /// to run this sample.
    /// </summary>
    internal sealed class ADONET2ADO
    {
        #region construction

        /// <summary>
        /// Prevents a default instance of the ADONET2ADO class from being created.
        /// </summary>
        private ADONET2ADO()
        {
        }

        #endregion

        #region static methods

        /// <summary>
        /// This function returns the ADO 2.8 classic XML recordset representation
        /// of sourceDataTable. To acheive this, the function calls the
        /// ConvertToAdoRecordset function to convert the ADO.NET DataTable 
        /// into an ADO recordset. It then uses the ADO recordset's save
        /// method for XML persistance.
        /// </summary>
        /// <param name="sourceDataTable">
        /// Reference to the ADO.NET data table to convert.
        /// </param>
        /// <returns>
        /// ADO classic  XML representation of the data contained in sourceDataTable.
        /// </returns>
        public static string ConvertToAdoRecordsetXml(
            System.Data.DataTable sourceDataTable)
        {
            string targetADOXMLString = string.Empty;
            ADODB.Recordset targetRecordset;
            ADODB.StreamClass targetADOXMLStream;

            try
            {
                targetRecordset = new ADODB.RecordsetClass();
                targetADOXMLStream = new ADODB.StreamClass();

                targetRecordset = ConvertToADORecordset(sourceDataTable);

                targetRecordset.Save(
                    targetADOXMLStream,
                    ADODB.PersistFormatEnum.adPersistXML);

                targetADOXMLString = targetADOXMLStream.ReadText(targetADOXMLStream.Size);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.ToString());
            }

            return targetADOXMLString;
        }

        /// <summary>
        /// This function converts the incoming ADO.NET sourceDataTable to an ADO targetRecordset by:
        /// <para />
        /// 1. Iterating first through the DataTable's DataColumns, converting 
        /// them to Fields and mapping their types by using the mapping in the translateType function.
        /// <para />
        /// 2. Then populating the targetDataRecordset's rows by iterating through and copying
        /// the value of the sourceDataTable's rows.
        /// </summary>
        /// <param name="sourceDataTable">
        /// Reference to the ADO.NET data table to convert.
        /// </param>
        /// <returns>
        /// An ADO classic DataRecordset representation of the data contained in sourceDataTable.
        /// </returns>
        public static ADODB.Recordset ConvertToADORecordset(
            System.Data.DataTable sourceDataTable)
        {
            ADODB.Recordset targetRecordset = new ADODB.RecordsetClass();

            try
            {
                targetRecordset.CursorLocation =
                    ADODB.CursorLocationEnum.adUseClient;

                // Iterate through each DataColumn from the source data table
                // and create a new ADO field for each. 
                foreach (System.Data.DataColumn sourceColumn
                             in sourceDataTable.Columns)
                {
                    // The targetRecordset.Fields.Append method requires
                    // a values for this attribute. 
                    ADODB.FieldAttributeEnum targetFieldAttribute;

                    if (sourceColumn.AllowDBNull)
                    {
                        targetFieldAttribute =
                            ADODB.FieldAttributeEnum.adFldIsNullable;
                    }
                    else
                    {
                        targetFieldAttribute =
                            ADODB.FieldAttributeEnum.adFldUnspecified;
                    }

                    targetRecordset.Fields.Append(
                        sourceColumn.ColumnName,
                        TranslateType(sourceColumn.DataType),
                        sourceColumn.MaxLength,
                        targetFieldAttribute,
                        null);
                }

                // Open the recordset for input.
                targetRecordset.Open(
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value,
                    ADODB.CursorTypeEnum.adOpenStatic,
                    ADODB.LockTypeEnum.adLockOptimistic,
                    0);

                // For each row in the source DataTable, create a new recordset
                // row and copy entries to the newly created row.
                foreach (System.Data.DataRow sourceRow in sourceDataTable.Rows)
                {
                    targetRecordset.AddNew(
                        System.Reflection.Missing.Value,
                        System.Reflection.Missing.Value);

                    for (int i = 0; i < sourceDataTable.Columns.Count; i++)
                    {
                        targetRecordset.Fields[i].Value = sourceRow[i];
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.ToString());
            }

            return targetRecordset;
        }

        /// <summary>
        /// This function converts ADO.NET data types to the nearest ADO 
        /// equivalents by using the UnderlyingSystemType method as
        /// a bridge.
        /// </summary>
        /// <param name="sourceColumnType">
        /// Type of the incoming ADO.NET DataColumn.
        /// </param>
        /// <returns>
        /// Equivalent ADO data type.
        /// </returns>
        private static ADODB.DataTypeEnum TranslateType(
            System.Type sourceColumnType)
        {
            ADODB.DataTypeEnum onErrorReturn = ADODB.DataTypeEnum.adIUnknown;
            try
            {
                switch (sourceColumnType.UnderlyingSystemType.ToString())
                {
                    case "System.Boolean":
                        return ADODB.DataTypeEnum.adBoolean;

                    case "System.Byte":
                        return ADODB.DataTypeEnum.adUnsignedTinyInt;

                    case "System.Char":
                        return ADODB.DataTypeEnum.adChar;

                    case "System.DateTime":
                        return ADODB.DataTypeEnum.adDate;

                    case "System.Decimal":
                        return ADODB.DataTypeEnum.adCurrency;

                    case "System.Double":
                        return ADODB.DataTypeEnum.adDouble;

                    case "System.Int16":
                        return ADODB.DataTypeEnum.adSmallInt;

                    case "System.Int32":
                        return ADODB.DataTypeEnum.adInteger;

                    case "System.Int64":
                        return ADODB.DataTypeEnum.adBigInt;

                    case "System.SByte":
                        return ADODB.DataTypeEnum.adTinyInt;

                    case "System.Single":
                        return ADODB.DataTypeEnum.adSingle;

                    case "System.UInt16":
                        return ADODB.DataTypeEnum.adUnsignedSmallInt;

                    case "System.UInt32":
                        return ADODB.DataTypeEnum.adUnsignedInt;

                    case "System.UInt64":
                        return ADODB.DataTypeEnum.adUnsignedBigInt;

                    case "System.String":
                        return ADODB.DataTypeEnum.adLongVarWChar; // adVarChar; I updated this as I noticed adVarChar would cause issues with special characters / other languages

                    default:
                        return ADODB.DataTypeEnum.adLongVarWChar; // adVarChar;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.ToString());
            }

            return onErrorReturn;
        }

        #endregion
    }
}
