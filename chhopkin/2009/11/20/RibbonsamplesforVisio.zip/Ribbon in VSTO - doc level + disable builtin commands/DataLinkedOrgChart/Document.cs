﻿//-----------------------------------------------------------------------
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

namespace DataLinkedOrgChart
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using Office = Microsoft.Office.Core;

    using Visio = Microsoft.Office.Interop.Visio;

    internal class Document
    {
        private Visio.Document visioDocument;

        private Ribbon ribbon;

        private Document(
            Visio.Document visioDocument)
        {
            this.visioDocument = visioDocument;

            this.ribbon = new Ribbon();
        }

        internal static bool TryCreate(
            Visio.Document visioDocument,
            out Document createdDocument)
        {
            if (visioDocument == null)
            {
                throw new ArgumentNullException("visioDocument");
            }

            // check if based on our template
            if (System.IO.Path.GetFileName(visioDocument.Template).EndsWith(Globals.VisioTemplateFileName))
            {
                // this is our document
                createdDocument = new Document(visioDocument);
                
                // add our UI for this document
                Globals.ThisAddIn.Application.RegisterRibbonX(
                    createdDocument.Ribbon,
                    visioDocument,
                    Visio.VisRibbonXModes.visRXModeDrawing,
                    "Data Org Chart Ribbon");

                // return success
                return true;
            }

            // set out param
            createdDocument = null;

            // return failure
            return false;
        }

        #region properties

        internal Ribbon Ribbon
        {
            get
            {
                return this.ribbon;
            }
        }

        #endregion

        internal void Generate()
        {
            try
            {
                string dataPath = System.Threading.Thread.GetDomain().BaseDirectory;

                TeamDataSet.TeamMembersDataTable data = new TeamDataSet.TeamMembersDataTable();

                // read the sample data from a file
                data.ReadXml(dataPath + "sample data.xml");

                #region generate sample data

                //data.AddTeamMembersRow(
                //    "Manu",
                //    "MCS",
                //    "Manager",
                //    0,
                //    40,
                //    "manu@ms.com");

                //data.AddTeamMembersRow(
                //    "Chris",
                //    "MCS",
                //    "ADC",
                //    0,
                //    90,
                //    "chris@ms.com");

                //data.AddTeamMembersRow(
                //    "Tedd",
                //    "MCS",
                //    "ADC",
                //    0,
                //    95,
                //    "tedd@ms.com");

                //data.AddTeamMembersRow(
                //    "Mark",
                //    "MCS",
                //    "TAM",
                //    0,
                //    85,
                //    "mark@ms.com");

                //data.WriteXml(
                //    dataPath + "sample data.xml");//,System.Data.XmlWriteMode.WriteSchema);

                #endregion

                string newXmlData = ADONET2ADO.ConvertToAdoRecordsetXml(data);

                // build dataset directly from XML file
                Visio.DataRecordset newRecordSet = this.visioDocument.DataRecordsets.AddFromXML(newXmlData, 0, "Team Members");

                if (newRecordSet != null)
                {
                    /* drop a linked shape for each row in the new dataset */

                    // get the row ids for the rows to drop linked shapes for
                    System.Array rowIDsToDrop = newRecordSet.GetDataRowIDs(""); // no filter provided

                    // create an array for each master name to drop
                    System.Array masterToDrop = Array.CreateInstance(
                        typeof(object), rowIDsToDrop.Length);

                    // create an array for each location of each row
                    System.Array pins = Array.CreateInstance(
                        typeof(double), rowIDsToDrop.Length * 2); // x and y pairs

                    /* init all the data for the drop */
                    System.Random randGen = new Random();

                    for (int nextRowIDIndex = 0; nextRowIDIndex < rowIDsToDrop.Length; nextRowIDIndex++)
                    {
                        masterToDrop.SetValue("Position", nextRowIDIndex);

                        // get the random pin x value based on the width of the target page
                        pins.SetValue(
                            randGen.Next(0, 11), //(int)_VisioDocument.Pages[1].PageSheet.get_CellsU("PageWidth").ResultIU),
                            nextRowIDIndex*2); // each x location in the array

                        // get the random pin y value based on the height of the targer page
                        pins.SetValue(
                            randGen.Next(0, 8), //(int)_VisioDocument.Pages[1].PageSheet.get_CellsU("PageHeight").ResultIU),
                            nextRowIDIndex*2+1); // each y location in the array
                    }

                    /* perform the drop operation */

                    System.Array droppedShapeIDs;

                    this.visioDocument.Pages[1].DropManyLinkedU(
                        ref masterToDrop,
                        ref pins,
                        newRecordSet.ID,
                        ref rowIDsToDrop,
                        false,
                        out droppedShapeIDs);

                    /* connect the shapes based on ReportsTo */

                    // get the primary key for this dataset
                    Visio.VisPrimaryKeySettings pkSettings;
                    System.Array primaryKey;
                    newRecordSet.GetPrimaryKey(out pkSettings, out primaryKey);

                    /* get the ReportsTo column */
                    
                    // get the names of all the column in the data set
                    System.Array colNames = newRecordSet.GetRowData(0);

                    // get the column index
                    int colIndex = -1;
                    for (int nextColIndex = 0; nextColIndex < colNames.Length; nextColIndex++)
                    {
                        if (string.Equals(colNames.GetValue(nextColIndex), "Reports To"))
                        {
                            colIndex = nextColIndex;
                            break;
                        }
                    }

                    System.Diagnostics.Debug.Assert(
                        colIndex > -1,
                        "Reports To column not found");

                    /* get the child and parent shapes for each row that was dropped */

                    for (int nextChildRowIndex = 0; nextChildRowIndex < rowIDsToDrop.Length; nextChildRowIndex++)
                    {
                        // get the child shape
                        Visio.Shape parentShape = null;
                        Visio.Shape childShape = this.visioDocument.Pages[1].Shapes.get_ItemFromID(
                            int.Parse(droppedShapeIDs.GetValue(nextChildRowIndex).ToString()));

                        // for each row get the Reports To field value
                        System.Array rowData = newRecordSet.GetRowData(
                            int.Parse(rowIDsToDrop.GetValue(nextChildRowIndex).ToString()));

                        object reportsTo = rowData.GetValue(colIndex);
                        if (reportsTo.ToString().Length > 0)
                        {
                            // the reports to field is not null so this person reports to someone in the dataset

                            // who do they report to
                            for (int parentRowIndex = 0; parentRowIndex < rowIDsToDrop.Length; parentRowIndex++)
                            {
                                // for each row get the ReportsTo field value
                                System.Array parentRowData = newRecordSet.GetRowData(
                                    int.Parse(rowIDsToDrop.GetValue(parentRowIndex).ToString()));

                                if (parentRowData.GetValue(0).Equals(reportsTo))
                                {
                                    // get the parent shape
                                    parentShape = this.visioDocument.Pages[1].Shapes.get_ItemFromID(
                                        int.Parse(droppedShapeIDs.GetValue(parentRowIndex).ToString()));

                                    break;
                                }
                            }

                            if (parentShape != null && childShape != null)
                            {
                                parentShape.AutoConnect(
                                    childShape, 
                                    Visio.VisAutoConnectDir.visAutoConnectDirDown,
                                    null);
                            }
                        }
                    }

                    // display the external data window
                    this.visioDocument.Application.ActiveWindow.Windows.get_ItemFromID(
                        (short)Visio.VisWinTypes.visWinIDExternalData).Visible = true;
                }
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString());
            }
        }

        internal void ApplyDataGraphics()
        {
            // for each shape on the page, apply a data graphic
            Visio.Master masterDataGraphic = Globals.ThisAddIn.Application.ActiveDocument.Masters["Data Graphic.13"];

            if (masterDataGraphic == null)
            {
                System.Windows.Forms.MessageBox.Show("The specified Data Graphic could not be found!");
                return;
            }

            foreach (Visio.Shape nextShape in Globals.ThisAddIn.Application.ActivePage.Shapes)
            {
                // find the "Utilization" property cell
                System.Array linkedPropRows = null;

                nextShape.GetCustomPropertiesLinkedToData(
                    Globals.ThisAddIn.Application.ActiveDocument.DataRecordsets[1].ID,
                    out linkedPropRows);

                if (linkedPropRows.Length > 0) // this is a simple check, could be updated to check into the shape further for the specific Utilization property
                {
                    for (int nextLinkedRowIndex = 0; nextLinkedRowIndex < linkedPropRows.Length; nextLinkedRowIndex++)
                    {
                        short linkedRowID = short.Parse(linkedPropRows.GetValue(nextLinkedRowIndex).ToString());

                        string rowLabel = nextShape.get_CellsSRC(
                            (short)Visio.VisSectionIndices.visSectionProp,
                            linkedRowID,
                            (short)Visio.VisCellIndices.visCustPropsLabel).get_ResultStrU(Visio.VisUnitCodes.visNoCast);

                        if (rowLabel.ToLower() == "utilization")
                        {
                            string rowValue = nextShape.get_CellsSRC(
                            (short)Visio.VisSectionIndices.visSectionProp,
                            linkedRowID,
                            (short)Visio.VisCellIndices.visCustPropsValue).FormulaU;

                            if (rowValue.Length > 0)
                            {
                                nextShape.DataGraphic = masterDataGraphic;
                                break;
                            }
                        }
                    }
                }
            }
        }

        internal void Layout()
        {
            // set layout options to just hierarchy, top down centered, this is a simple page setting
            this.visioDocument.Pages[1].PageSheet.get_CellsU("PlaceStyle").FormulaU = "=17";

            // perform the layout on this page
            this.visioDocument.Pages[1].Layout();
        }

        internal void Close()
        {
            if (this.ribbon != null)
            {
                Globals.ThisAddIn.Application.UnregisterRibbonX(this.ribbon, this.visioDocument);
            }
        }
    }
}
