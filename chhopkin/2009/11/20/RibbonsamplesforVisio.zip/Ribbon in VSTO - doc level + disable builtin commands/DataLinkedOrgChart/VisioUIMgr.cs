﻿////-----------------------------------------------------------------------
//// 
////  Copyright (C) Microsoft Corporation.  All rights reserved.
//// 
//// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
//// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//// PARTICULAR PURPOSE.
////-----------------------------------------------------------------------

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//using Visio = Microsoft.Office.Interop.Visio;
//using Office = Microsoft.Office.Core;

//namespace DataLinkedOrgChart
//{
//    /// <summary>
//    /// Arguments class for our custom event that notifies us if there is an active document or not.
//    /// </summary>
//    public class ActiveDrawingWindowStateChangedEventArgs : EventArgs
//    {
//        #region fields

//        private bool _DrawingActive;
//        private Visio.Document _VisioDocument;

//        #endregion

//        #region construction / destruction

//        public ActiveDrawingWindowStateChangedEventArgs(
//            bool drawingActive,
//            Visio.Document visioDocument)
//        {
//            _DrawingActive = drawingActive;
//            _VisioDocument = visioDocument;
//        }

//        #endregion

//        #region properties

//        public bool DrawingActive
//        {
//            get { return _DrawingActive; }
//        }

//        public Visio.Document VisioDocument
//        {
//            get { return _VisioDocument; }
//        }

//        #endregion
//    }

//    /// <summary>
//    /// A wrapper class for CommandBarButton objects to help them manage their own state.
//    /// </summary>
//    internal class CommandBarButtonStateMgr
//    {
//        public delegate bool ThisAddinDocumentCheckHandler (Visio.Document visioDocument);
//        private ThisAddinDocumentCheckHandler _ThisAddinDocumentChecker;

//        #region fields

//        string _Tag = string.Empty;
//        bool _LastState = false;

//        #endregion

//        #region construction / destruction

//        public CommandBarButtonStateMgr(
//            string tag,
//            bool initialState)
//        {
//            if (tag.Length <= 0)
//            {
//                throw new System.ArgumentNullException("tag");
//            }

//            _Tag = tag;
//            _LastState = initialState;
//        }

//        #endregion

//        #region event handlers

//        internal void UpdateState(
//            object sender, 
//            ActiveDrawingWindowStateChangedEventArgs e)
//        {
//            bool newState = e.DrawingActive;

//            if (_ThisAddinDocumentChecker != null &&
//                e.VisioDocument != null)
//            {
//                // call the call back
//                newState = _ThisAddinDocumentChecker(e.VisioDocument);
//            }

//            if (newState != _LastState)
//            {
//                _LastState = newState;

//                // get the button
//                Office.CommandBarButton foundButton = VisioUIMgr.MainMenu_Visio.FindControl(
//                    Office.MsoControlType.msoControlButton,
//                    System.Type.Missing,
//                    _Tag, // find the tag that this wrapper wraps
//                    true,
//                    true) as Office.CommandBarButton;

//                // change the Enabled property
//                foundButton.Enabled = _LastState;
//            }
//        }

//        #endregion

//        #region checker

//        internal ThisAddinDocumentCheckHandler ThisAddinDocumentChecker
//        {
//            get
//            {
//                return _ThisAddinDocumentChecker;
//            }

//            set
//            {
//                _ThisAddinDocumentChecker = value;
//            }
//        }

//        #endregion
//    }

//    /// <summary>
//    /// Our main Visio CommandBar based UI manager class.  This class notifies our button state wrappers for this add-in.
//    /// </summary>
//    public class VisioUIMgr
//    {
//        public event EventHandler<ActiveDrawingWindowStateChangedEventArgs> ActiveDrawingWindowStateChanged;

//        #region construction / destruction

//        public VisioUIMgr()
//        {
//            // connect to any events
//            VisioEvents_Connect();
//        }

//        #endregion

//        #region properties

//        /// <summary>
//        /// Returns the Menu Bar for this Visio Application instance.
//        /// </summary>
//        internal static Office.CommandBar MainMenu_Visio
//        {
//            get
//            {
//                // get the main menu
//                Office.CommandBars commandBars = Globals.ThisAddIn.Application.CommandBars as Office.CommandBars;
//                Office.CommandBar menuBar = commandBars["Menu Bar"]; // get by name

//                // this should not occur, we should always have a menu bar commandbar object
//                System.Diagnostics.Debug.Assert(
//                    menuBar != null,
//                    "The Menu Bar CommandBar was not retrieved!");

//                return menuBar;
//            }
//        }

//        #endregion

//        #region visio events

//        private void VisioEvents_Connect()
//        {
//            Globals.ThisAddIn.Application.VisioIsIdle += new Microsoft.Office.Interop.Visio.EApplication_VisioIsIdleEventHandler(VisioApplication_VisioIsIdle);
//        }

//        private void VisioApplication_VisioIsIdle(
//            Visio.Application visioApplication)
//        {
//            // this should be updated to an event/set of events that does not fire as often
//            // this could hinder performance
//            bool activeWindowIsDrawing = false;
//            Visio.Document visioDocument = null;

//            if (visioApplication.ActiveWindow != null &&
//                visioApplication.ActiveWindow.Document != null)
//            {
//                activeWindowIsDrawing = true;
//                visioDocument = visioApplication.ActiveWindow.Document;
//            }

//            OnActiveDrawingWindowStateChanged(new ActiveDrawingWindowStateChangedEventArgs(activeWindowIsDrawing, visioDocument));
//        }

//        // Wrap event invocations inside a protected virtual method
//        // to allow derived classes to override the event invocation behavior
//        protected virtual void OnActiveDrawingWindowStateChanged(
//            ActiveDrawingWindowStateChangedEventArgs e)
//        {
//            // Make a temporary copy of the event to avoid possibility of
//            // a race condition if the last subscriber unsubscribes
//            // immediately after the null check and before the event is raised.
//            EventHandler<ActiveDrawingWindowStateChangedEventArgs> handler = ActiveDrawingWindowStateChanged;

//            // Event will be null if there are no subscribers
//            if (handler != null)
//            {
//                // Use the () operator to raise the event.
//                handler(this, e);
//            }
//        }

//        #endregion
//    }
//}
