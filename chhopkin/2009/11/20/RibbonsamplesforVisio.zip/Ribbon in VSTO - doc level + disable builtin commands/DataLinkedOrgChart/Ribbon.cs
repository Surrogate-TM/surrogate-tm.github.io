﻿namespace DataLinkedOrgChart
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Text;

    using Office = Microsoft.Office.Core;

    using Visio = Microsoft.Office.Interop.Visio;

    [ComVisible(true)]
    public class Ribbon : Office.IRibbonExtensibility
    {
        private Office.IRibbonUI ribbon;

        public Ribbon()
        {
            System.Diagnostics.Debug.WriteLine("Ribbon CTOR");
        }

        #region visio events

        private void VisioEvents_Connect()
        {
            if (Globals.ThisAddIn.Application != null)
            {
                Globals.ThisAddIn.Application.AppObjActivated += new Microsoft.Office.Interop.Visio.EApplication_AppObjActivatedEventHandler(Application_AppObjActivated);
                Globals.ThisAddIn.Application.AfterModal += new Microsoft.Office.Interop.Visio.EApplication_AfterModalEventHandler(Application_AfterModal);

                Globals.ThisAddIn.Application.WindowOpened += new Microsoft.Office.Interop.Visio.EApplication_WindowOpenedEventHandler(Application_WindowOpened);
                Globals.ThisAddIn.Application.WindowActivated += new Microsoft.Office.Interop.Visio.EApplication_WindowActivatedEventHandler(Application_WindowActivated);
                Globals.ThisAddIn.Application.WindowChanged += new Microsoft.Office.Interop.Visio.EApplication_WindowChangedEventHandler(Application_WindowChanged);

                Globals.ThisAddIn.Application.BeforeWindowClosed += new Microsoft.Office.Interop.Visio.EApplication_BeforeWindowClosedEventHandler(Application_BeforeWindowClosed);
            }
        }

        void Application_BeforeWindowClosed(Microsoft.Office.Interop.Visio.Window Window)
        {
            this.ribbon.Invalidate();
        }

        void Application_WindowChanged(Microsoft.Office.Interop.Visio.Window Window)
        {
            this.ribbon.Invalidate();
        }

        void Application_WindowActivated(Microsoft.Office.Interop.Visio.Window Window)
        {
            this.ribbon.Invalidate();
        }

        void Application_WindowOpened(Microsoft.Office.Interop.Visio.Window Window)
        {
            this.ribbon.Invalidate();
        }

        void Application_AfterModal(Microsoft.Office.Interop.Visio.Application app)
        {
            this.ribbon.Invalidate();
        }

        void Application_AppObjActivated(Microsoft.Office.Interop.Visio.Application app)
        {
            this.ribbon.Invalidate();
        }

        #endregion

        public static bool IsOurDocument(
            Visio.Document visioDocument)
        {
            bool retVal = false; // default to false until we prove this should be enabled

            // only enabled if the active document is a configured document
            if (visioDocument != null)
            {
                if (visioDocument.Template.EndsWith("Data Linked Org Chart Sample.vst"))
                {
                    retVal = true;
                }
            }
            else
            {
                retVal = false;
            }

            return retVal;
        }

        #region IRibbonExtensibility Members

        public string GetCustomUI(string RibbonID)
        {
            string retVal = GetResourceText("DataLinkedOrgChart.Ribbon.xml");
            return retVal;
        }

        #endregion

        #region Ribbon Callbacks

        public void Ribbon_Load(Office.IRibbonUI ribbonUI)
        {
            this.ribbon = ribbonUI;

            if (Globals.ThisAddIn.Application != null)
            {
                VisioEvents_Connect();
            }
        }

        public void OnAction(
            Office.IRibbonControl control)
        {
            switch (control.Id)
            {
                case "buttonGenerate":
                    {
                        Globals.ThisAddIn.OnActionGenerate();
                        break;
                    }

                case "buttonApplyDataGraphics":
                    {
                        Globals.ThisAddIn.OnActionApplyDataGraphics();
                        break;
                    }

                case "buttonLayout":
                    {
                        Globals.ThisAddIn.OnActionLayout();
                        break;
                    }

                default:
                    {
                        System.Windows.Forms.MessageBox.Show(control.Id);
                        break;
                    }
            }
        }

        public bool GetEnabled(
            Microsoft.Office.Core.IRibbonControl control)
        {
            bool retVal = false; // default to false until we prove this should be enabled

            switch (control.Id)
            {
                case "buttonGenerate":
                    {
                        // only enabled if the active document is a configured document
                        retVal = Ribbon.IsOurDocument(Globals.ThisAddIn.Application.ActiveDocument);

                        break;
                    }

                case "buttonApplyDataGraphics":
                    {
                        // only enabled if the active document is a configured document
                        retVal = Ribbon.IsOurDocument(Globals.ThisAddIn.Application.ActiveDocument);

                        break;
                    }

                case "buttonLayout":
                    {
                        // only enabled if the active document is a configured document
                        retVal = Ribbon.IsOurDocument(Globals.ThisAddIn.Application.ActiveDocument);

                        break;
                    }
            }

            // determine if this control should be enabled
            return retVal;
        }

        public System.Drawing.Bitmap GetImage(
            Microsoft.Office.Core.IRibbonControl control)
        {
            switch (control.Id)
            {
                case "buttonApplyDataGraphics":
                    {
                        return Properties.Resources.OperationsManagerProductIcon_32;
                    }

                case "buttonGetHelp":
                    {
                        return Properties.Resources.SelfSupportPH;
                    }
            }

            // we should not get here for these buttons
            return null;
        }

        #endregion

        #region Helpers

        private static string GetResourceText(string resourceName)
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            string[] resourceNames = asm.GetManifestResourceNames();
            for (int i = 0; i < resourceNames.Length; ++i)
            {
                if (string.Compare(resourceName, resourceNames[i], StringComparison.OrdinalIgnoreCase) == 0)
                {
                    using (StreamReader resourceReader = new StreamReader(asm.GetManifestResourceStream(resourceNames[i])))
                    {
                        if (resourceReader != null)
                        {
                            return resourceReader.ReadToEnd();
                        }
                    }
                }
            }
            return null;
        }

        #endregion
    }
}
