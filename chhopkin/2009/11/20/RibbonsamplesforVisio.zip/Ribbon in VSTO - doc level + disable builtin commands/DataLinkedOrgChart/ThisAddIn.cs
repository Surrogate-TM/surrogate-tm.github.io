﻿//-----------------------------------------------------------------------
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

namespace DataLinkedOrgChart
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Xml.Linq;
    using System.Windows.Forms;

    using Visio = Microsoft.Office.Interop.Visio;
    using Office = Microsoft.Office.Core;

    public partial class ThisAddIn
    {
        #region fields

        private Dictionary<int, Document> documents;

        #endregion

        /// <summary>
        /// Gets a value indicating whether the correct Version of Visio is installed.
        /// <para></para>
        /// Visio 2007 (12) or > and the Edition has to be PRO or >.
        /// PRO or > means that the Data features are supported.
        /// </summary>
        internal bool IsVisio14NotStdInstalled
        {
            get
            {
                bool retVal = false;

                // the installed version of Visio has to be 14 or > and the edition has to be PRO or >
                if (this.Application.TypelibMinorVersion >= 14)
                {
                    // DataFeaturesEnabled tells us that their Editions is PRO or >
                    if (this.Application.DataFeaturesEnabled)
                    {
                        retVal = true;
                    }
                }

                return retVal;
            }
        }

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            /* check prereq's */

            // check for Visio >= 2010 and Edition >= PRO
            if (!this.IsVisio14NotStdInstalled)
            {
                MessageBox.Show(
                    null, // TODO - add this extension method ? Globals.ThisAddIn.Application.IWin32Window(),
                    "This add-in requires the Professional or Premium edition of Visio",
                    "Visio Professional or Premium edition required",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return;
            }

            // events must be enabled
            if (!Convert.ToBoolean(Globals.ThisAddIn.Application.EventsEnabled)) // -1 is TRUE, 0 is FALSE, typically anything other than 0 is TRUE
            {
                if (MessageBox.Show(
                        "Event are currently disabled, this add-in requires events to be enabled.  Would you like to enable events now?", "Data Linked Org Chart Sample",
                        MessageBoxButtons.YesNo)
                    == DialogResult.Yes)
                {
                    Globals.ThisAddIn.Application.EventsEnabled = Convert.ToInt16(true); // convert to short from TRUE which ends up being 1
                }
            }

            // init locals
            this.documents = new Dictionary<int, Document>();

            // connect to events
            VisioEvents_Connect();
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            // disconnect from events
            VisioEvents_Disconnect();
        }

        #region properties

        internal Document ActiveDocument
        {
            get
            {
                if (this.Application == null || this.Application.ActiveDocument == null)
                {
                    return null;
                }

                // return the instance of the document that we are wrapping
                int activeDocID = this.Application.ActiveDocument.ID;

                if (this.documents != null &&
                    this.documents.ContainsKey(activeDocID))
                {
                    return this.documents[activeDocID];
                }
                else
                {
                    return null;
                }
            }
        }

        #endregion

        #region visio events

        private void VisioEvents_Connect()
        {
            Globals.ThisAddIn.Application.DocumentOpened += new Microsoft.Office.Interop.Visio.EApplication_DocumentOpenedEventHandler(VisioApplication_DocumentOpened);
            Globals.ThisAddIn.Application.DocumentCreated += new Microsoft.Office.Interop.Visio.EApplication_DocumentCreatedEventHandler(VisioApplication_DocumentCreated);

            Globals.ThisAddIn.Application.BeforeDocumentClose += new Microsoft.Office.Interop.Visio.EApplication_BeforeDocumentCloseEventHandler(VisioApplication_BeforeDocumentClose);
        }

        private void VisioEvents_Disconnect()
        {
            Globals.ThisAddIn.Application.DocumentOpened -= new Microsoft.Office.Interop.Visio.EApplication_DocumentOpenedEventHandler(VisioApplication_DocumentOpened);
            Globals.ThisAddIn.Application.DocumentCreated -= new Microsoft.Office.Interop.Visio.EApplication_DocumentCreatedEventHandler(VisioApplication_DocumentCreated);

            Globals.ThisAddIn.Application.BeforeDocumentClose -= new Microsoft.Office.Interop.Visio.EApplication_BeforeDocumentCloseEventHandler(VisioApplication_BeforeDocumentClose);
        }

        private void VisioApplication_DocumentCreated(Microsoft.Office.Interop.Visio.Document Doc)
        {
            OnDocumentOpenedOrCreated(Doc);
        }

        private void VisioApplication_DocumentOpened(Microsoft.Office.Interop.Visio.Document Doc)
        {
            OnDocumentOpenedOrCreated(Doc);
        }

        private void OnDocumentOpenedOrCreated(
            Visio.Document visioDocument)
        {
            Document newDocument = null;
            if (Document.TryCreate(visioDocument, out newDocument) && newDocument != null)
            {
                // add this to our collection
                this.documents.Add(visioDocument.ID, newDocument);
            }
        }

        private void VisioApplication_BeforeDocumentClose(Microsoft.Office.Interop.Visio.Document Doc)
        {
            try
            {
                int id = Doc.ID;

                if (this.documents != null && this.documents.ContainsKey(id))
                {
                    // perform operations required before closing out this document
                    this.documents[id].Close();

                    // remove this document from our collection
                    this.documents.Remove(id);
                }
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }
        }

        #endregion

        #region UI Commands

        public void OnActionGenerate()
        {
            Document document = this.documents[Globals.ThisAddIn.Application.ActiveDocument.ID];
            if (document != null)
            {
                // this is our document so call generate
                document.Generate();
            }
        }

        public void OnActionApplyDataGraphics()
        {
            Document document = this.documents[Globals.ThisAddIn.Application.ActiveDocument.ID];
            if (document != null)
            {
                // this is our document so call generate
                document.ApplyDataGraphics();
            }
        }

        public void OnActionLayout()
        {
            Document document = this.documents[Globals.ThisAddIn.Application.ActiveDocument.ID];
            if (document != null)
            {
                // this is our document so call generate
                document.Layout();
            }
        }

        #endregion

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion


        // This is not needed as we will call RegisterRibbonX for each document as needed

        //// 1.
        //// this is needed to allow VSTO and Visio 2010 to call our add-in to get the Ribbon.
        //// our add-in needs to provide the instance of a new Ribbon object.
        //#region vsto ribbon support

        ///// <summary>
        ///// Provides our Ribbon object to Visio when Visio asks for it when loading our add-in.  This call is made in
        ///// in Visio 2007 but because Visio 2007 does not support the ribbon ui, nothing happens.
        ///// 
        ///// FYI - this call is made before the add-in is initialized so we cannot get to the instance of Visio to check
        ///// for a version.  This would be nice as we could just return null if <=2007.
        ///// </summary>
        ///// <returns></returns>
        //protected override Microsoft.Office.Core.IRibbonExtensibility CreateRibbonExtensibilityObject()
        //{
        //    //this.ribbon = new Ribbon();

        //    //// add ribbon support for Visio 2010
        //    //return this.ribbon;

        //    return null;
        //}

        //#endregion
    }
}
