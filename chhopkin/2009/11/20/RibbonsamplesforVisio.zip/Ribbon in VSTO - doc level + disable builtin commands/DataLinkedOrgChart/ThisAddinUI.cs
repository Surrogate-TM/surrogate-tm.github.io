﻿////-----------------------------------------------------------------------
//// 
////  Copyright (C) Microsoft Corporation.  All rights reserved.
//// 
//// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
//// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//// PARTICULAR PURPOSE.
////-----------------------------------------------------------------------

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//using Visio = Microsoft.Office.Interop.Visio;
//using Office = Microsoft.Office.Core;

//using Microsoft.VisualBasic.Compatibility.VB6;

//namespace DataLinkedOrgChart  // TODO - update this namespace for each project this class is copied to
//{
//    public class ThisAddinUI
//    {
//        private const string TAG_DATALINKEDORGCHARTMENU = "{A4675CA2-FBA5-4ab6-983B-8B1E80835CF2}";
//        private const string TAG_CREATE = TAG_DATALINKEDORGCHARTMENU + "|NEW";
//        private const string TAG_GENERATE = TAG_DATALINKEDORGCHARTMENU + "|GENERATE";
//        private const string TAG_APPLYGRAPHICS = TAG_DATALINKEDORGCHARTMENU + "|APPLYDG";
//        private const string TAG_LAYOUT = TAG_DATALINKEDORGCHARTMENU + "|LAYOUT";

//        private List<Office.CommandBarButton> _buttons = new List<Microsoft.Office.Core.CommandBarButton>();
//        private List<CommandBarButtonStateMgr> _StateMgrs = new List<CommandBarButtonStateMgr>();

//        #region construction / destruction

//        public ThisAddinUI()
//        {
//        }

//        #endregion

//        #region methods

//        internal bool Create(
//            VisioUIMgr visioUIMgr)
//        {
//            bool retVal = false;

//            // get the main menu
//            Office.CommandBar menuBar = this.MainMenu_Visio;
//            menuBar.Protection = Microsoft.Office.Core.MsoBarProtection.msoBarNoProtection;

//            // check for the VisiChris Tools main menu
//            Office.CommandBarPopup addinMenu = this.MainMenu_Addin;

//            if (addinMenu == null)
//            {
//                // create the add-in menu
//                addinMenu = menuBar.Controls.Add(
//                    Office.MsoControlType.msoControlPopup,
//                    System.Type.Missing,
//                    System.Type.Missing,
//                    System.Type.Missing,
//                    true) as Office.CommandBarPopup;

//                addinMenu.Caption = Properties.Resources.menu_DataLinkedOrgChart;
//                addinMenu.Tag = TAG_DATALINKEDORGCHARTMENU; // tag name so we can find it with FindControls above
//            }

//            if (addinMenu != null)
//            {
//                /* add the menu items to the data linked orgchart menu */

//                // create new
//                Office.CommandBarButton buttonNew = addinMenu.Controls.Add(
//                    Office.MsoControlType.msoControlButton,
//                    System.Type.Missing,
//                    System.Type.Missing,
//                    System.Type.Missing,
//                    true) as Office.CommandBarButton;

//                buttonNew.Caption = Properties.Resources.menuitem_CreateNewOrgChartDiagram;
//                buttonNew.Tag = TAG_CREATE;

//                buttonNew.Click += new Microsoft.Office.Core._CommandBarButtonEvents_ClickEventHandler(buttonNew_Click);
//                _buttons.Add(buttonNew);

//                // generate
//                Office.CommandBarButton buttonGenerate = addinMenu.Controls.Add(
//                    Office.MsoControlType.msoControlButton,
//                    System.Type.Missing,
//                    System.Type.Missing,
//                    System.Type.Missing,
//                    true) as Office.CommandBarButton;

//                buttonGenerate.Caption = Properties.Resources.menuitem_GenerateOrgChartFromData;
//                buttonGenerate.Tag = TAG_GENERATE;

//                buttonGenerate.Click += new Microsoft.Office.Core._CommandBarButtonEvents_ClickEventHandler(buttonGenerate_Click);
//                _buttons.Add(buttonGenerate);

//                // this also needs to check for our document
//                CommandBarButtonStateMgr buttonGenerateStateMgr = new CommandBarButtonStateMgr(buttonGenerate.Tag, true);
//                buttonGenerateStateMgr.ThisAddinDocumentChecker += new CommandBarButtonStateMgr.ThisAddinDocumentCheckHandler(this.ThisAddinsDocument);
//                visioUIMgr.ActiveDrawingWindowStateChanged += new EventHandler<ActiveDrawingWindowStateChangedEventArgs>(buttonGenerateStateMgr.UpdateState);
//                _StateMgrs.Add(buttonGenerateStateMgr);

//                // data graphics
//                Office.CommandBarButton buttonApplyDataGraphics = addinMenu.Controls.Add(
//                    Office.MsoControlType.msoControlButton,
//                    System.Type.Missing,
//                    System.Type.Missing,
//                    System.Type.Missing,
//                    true) as Office.CommandBarButton;

//                buttonApplyDataGraphics.Caption = Properties.Resources.menuitem_ApplyDataGraphics;
//                buttonApplyDataGraphics.Tag = TAG_APPLYGRAPHICS;

//                buttonApplyDataGraphics.Click += new Microsoft.Office.Core._CommandBarButtonEvents_ClickEventHandler(buttonApplyDataGraphics_Click);
//                _buttons.Add(buttonApplyDataGraphics);

//                buttonApplyDataGraphics.Picture = (stdole.IPictureDisp)Support.ImageToIPictureDisp(Properties.Resources.DataLinkFace);
//                buttonApplyDataGraphics.Mask = (stdole.IPictureDisp)Support.ImageToIPictureDisp(Properties.Resources.DataLinkMask);

//                // this also needs to check for our document
//                CommandBarButtonStateMgr buttonApplyDataGraphicsStateMgr = new CommandBarButtonStateMgr(buttonApplyDataGraphics.Tag, true);
//                buttonApplyDataGraphicsStateMgr.ThisAddinDocumentChecker += new CommandBarButtonStateMgr.ThisAddinDocumentCheckHandler(this.ThisAddinsDocument);
//                visioUIMgr.ActiveDrawingWindowStateChanged += new EventHandler<ActiveDrawingWindowStateChangedEventArgs>(buttonApplyDataGraphicsStateMgr.UpdateState);
//                _StateMgrs.Add(buttonApplyDataGraphicsStateMgr);

//                // layout
//                Office.CommandBarButton buttonLayout = addinMenu.Controls.Add(
//                    Office.MsoControlType.msoControlButton,
//                    System.Type.Missing,
//                    System.Type.Missing,
//                    System.Type.Missing,
//                    true) as Office.CommandBarButton;

//                buttonLayout.Caption = Properties.Resources.menuitem_Layout;
//                buttonLayout.Tag = TAG_LAYOUT;

//                buttonLayout.Picture = (stdole.IPictureDisp)Support.ImageToIPictureDisp(ImageHelpers.GetImageFromIcon(Properties.Resources.Layout));
//                buttonLayout.Mask = (stdole.IPictureDisp)Support.ImageToIPictureDisp(ImageHelpers.GetMaskFromImage(ImageHelpers.GetImageFromIcon(Properties.Resources.Layout)));

//                buttonLayout.Click += new Microsoft.Office.Core._CommandBarButtonEvents_ClickEventHandler(buttonLayout_Click);
//                _buttons.Add(buttonLayout);

//                // this also needs to check for our document
//                CommandBarButtonStateMgr buttonLayoutStateMgr = new CommandBarButtonStateMgr(buttonLayout.Tag, true);
//                buttonLayoutStateMgr.ThisAddinDocumentChecker += new CommandBarButtonStateMgr.ThisAddinDocumentCheckHandler(this.ThisAddinsDocument);
//                visioUIMgr.ActiveDrawingWindowStateChanged += new EventHandler<ActiveDrawingWindowStateChangedEventArgs>(buttonLayoutStateMgr.UpdateState);
//                _StateMgrs.Add(buttonLayoutStateMgr);
//            }

//            // return success
//            return retVal;
//        }

//        #endregion

//        #region properties

//        /// <summary>
//        /// Returns the top level menu for this add-in.
//        /// </summary>
//        internal Office.CommandBarPopup MainMenu_Addin
//        {
//            get
//            {
//                // get the main menu
//                Office.CommandBar menuBar = this.MainMenu_Visio;

//                // check for the Chris' Samples main menu
//                return menuBar.FindControl(
//                    Office.MsoControlType.msoControlPopup,
//                    System.Type.Missing,
//                    TAG_DATALINKEDORGCHARTMENU, // use unique tag to find this item
//                    true,
//                    true) as Office.CommandBarPopup;
//            }
//        }

//        /// <summary>
//        /// Returns the Menu Bar for this Visio Application instance.
//        /// </summary>
//        internal Office.CommandBar MainMenu_Visio
//        {
//            get
//            {
//                // get the main menu
//                Office.CommandBars commandBars = Globals.ThisAddIn.Application.CommandBars as Office.CommandBars;
//                Office.CommandBar menuBar = commandBars["Menu Bar"]; // get by name

//                // this should not occur, we should always have a menu bar commandbar object
//                System.Diagnostics.Debug.Assert(
//                    menuBar != null,
//                    "The Menu Bar CommandBar was not retrieved!");

//                return menuBar;
//            }
//        }

//        #endregion

//        #region command bar events

//        public void buttonGenerate_Click(Microsoft.Office.Core.CommandBarButton Ctrl, ref bool CancelDefault)
//        {
//            // TODO - in the future we should enable and disable this button based on the open document being
//            // based on our template

//            Globals.ThisAddIn.OnActionGenerate();
//        }

//        public void buttonApplyDataGraphics_Click(Microsoft.Office.Core.CommandBarButton Ctrl, ref bool CancelDefault)
//        {
//            // TODO - in the future we should enable and disable this button based on the open document being
//            // based on our template

//            Globals.ThisAddIn.OnActionApplyDataGraphics();
//        }

//        public void buttonLayout_Click(Microsoft.Office.Core.CommandBarButton Ctrl, ref bool CancelDefault)
//        {
//            // TODO - in the future we should enable and disable this button based on the open document being
//            // based on our template

//            Globals.ThisAddIn.OnActionLayout();
//        }

//        #endregion

//        #region ThisAddinDocumentChecker

//        internal bool ThisAddinsDocument(
//            Visio.Document visioDocument)
//        {
//            bool retVal = false;

//            // TODO - logic to check the passed document to see if it is a document specific to this add-in
//            if (visioDocument != null &&
//                System.IO.Path.GetFileName(visioDocument.Template) == Globals.VisioTemplateFileName)
//            {
//                retVal = true;
//            }

//            // return success / failure
//            return retVal;
//        }

//        #endregion
//    }

//    internal class ImageHelpers
//    {
//        public static System.Drawing.Image GetImageFromIcon(
//            System.Drawing.Icon icon)
//        {
//            System.Windows.Forms.ImageList newImageList = new System.Windows.Forms.ImageList();
//            newImageList.Images.Add(icon);
//            return newImageList.Images[0];
//        }

//        public static System.Drawing.Image GetMaskFromImage(
//            System.Drawing.Image image)
//        {
//            System.Drawing.Bitmap b = new System.Drawing.Bitmap(16, 16);
//            System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(b);

//            // draw the image over the transparent bitmap
//            g.DrawImage(image, 0, 0, 16, 16);

//            // convert pixels to grayscale
//            for (int x = 0; x <= 15; x++)
//            {
//                for (int y = 0; y <= 15; y++)
//                {
//                    // get the pixel alpha
//                    int pa = b.GetPixel(x, y).A;

//                    // get the grayscale alpha equivalent of the pixel alpha
//                    int pg = 255 - pa;

//                    // replace the current pixel with a grayscale equivalent
//                    b.SetPixel(x, y, System.Drawing.Color.FromArgb(pg, pg, pg));
//                }
//            }

//            // return the image
//            return b;
//        }
//    }
//}