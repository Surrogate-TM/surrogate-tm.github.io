﻿//-----------------------------------------------------------------------
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Windows.Forms;

using Visio = Microsoft.Office.Interop.Visio;
using Office = Microsoft.Office.Core;

namespace DataLinkedOrgChart
{
    public partial class ThisAddIn
    {
        private ThisAddinUI AddinUI;
        private VisioUIMgr VisioUIMgr;

        private Ribbon ribbon;

        /// <summary>
        /// Gets a value indicating whether the correct Version of Visio is installed.
        /// <para></para>
        /// Visio 2007 (12) or > and the Edition has to be PRO or >.
        /// PRO or > means that the Data features are supported.
        /// </summary>
        internal bool IsVisio12NotStdInstalled
        {
            get
            {
                bool retVal = false;

                // the installed version of Visio has to be 12 or > and the edition has to be PRO or >
                if (this.Application.TypelibMinorVersion >= 12)
                {
                    // DataFeaturesEnabled tells us that their Editions is PRO or >
                    if (this.Application.DataFeaturesEnabled)
                    {
                        retVal = true;
                    }
                }

                return retVal;
            }
        }

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            /* check prereq's */

            // check for Visio 2007 > and Edition == PRO
            if (!this.IsVisio12NotStdInstalled)
            {
                MessageBox.Show(
                    null, // TODO - add this extension method ? Globals.ThisAddIn.Application.IWin32Window(),
                    "This add-in requires the Professional edition of Visio",
                    "Visio Professional required",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return;
            }

            // events must be enabled
            if (!Convert.ToBoolean(Globals.ThisAddIn.Application.EventsEnabled)) // -1 is TRUE, 0 is FALSE, typically anything other than 0 is TRUE
            {
                if (MessageBox.Show(
                        "Event are currently disabled, this add-in requires events to be enabled.  Would you like to enable events now?", "Data Linked Org Chart Sample",
                        MessageBoxButtons.YesNo)
                    == DialogResult.Yes)
                {
                    Globals.ThisAddIn.Application.EventsEnabled = Convert.ToInt16(true); // convert to short from TRUE which ends up being 1
                }
            }

            /* init UI */
            // 2. 
            if (this.Application.TypelibMinorVersion <= 12)
            {
                // provide CommandBars
                this.VisioUIMgr = new VisioUIMgr();
                this.AddinUI = new ThisAddinUI();
                this.AddinUI.Create(this.VisioUIMgr);
            }
            else
            {
                // the ribbon interface should have provided a ribbon to Visio via CreateRibbonExtensibilityObject()
                //this.ribbon.Ribbon_Load
            }
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {

        }

        #region UI Commands

        public void OnActionNew()
        {
            // add a new document based on our sample visio template
            Visio.Document newDoc = Globals.ThisAddIn.Application.Documents.Add(AppDomain.CurrentDomain.BaseDirectory + "\\" + Globals.VisioTemplateFileName);
        }

        public void OnActionGenerate()
        {
            Document documentOrgChart = null;
            if (Document.TryCreate(Globals.ThisAddIn.Application.ActiveDocument, out documentOrgChart))
            {
                // this is our document so call generate
                documentOrgChart.Generate();
            }
        }

        public void OnActionApplyDataGraphics()
        {
            Document documentOrgChart = null;
            if (Document.TryCreate(Globals.ThisAddIn.Application.ActiveDocument, out documentOrgChart))
            {
                // this is our document so call generate
                documentOrgChart.ApplyDataGraphics();
            }
        }

        public void OnActionLayout()
        {
            Document documentOrgChart = null;
            if (Document.TryCreate(Globals.ThisAddIn.Application.ActiveDocument, out documentOrgChart))
            {
                // this is our document so call generate
                documentOrgChart.Layout();
            }
        }

        #endregion

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion

        // 1.
        // this is needed to allow VSTO and Visio 2010 to call our add-in to get the Ribbon.
        // our add-in needs to provide the instance of a new Ribbon object.
        #region vsto ribbon support

        /// <summary>
        /// Provides our Ribbon object to Visio when Visio asks for it when loading our add-in.  This call is made in
        /// in Visio 2007 but because Visio 2007 does not support the ribbon ui, nothing happens.
        /// 
        /// FYI - this call is made before the add-in is initialized so we cannot get to the instance of Visio to check
        /// for a version.  This would be nice as we could just return null if <=2007.
        /// </summary>
        /// <returns></returns>
        protected override Microsoft.Office.Core.IRibbonExtensibility CreateRibbonExtensibilityObject()
        {
            this.ribbon = new Ribbon();

            // add ribbon support for Visio 2010
            return this.ribbon;
        }

        #endregion
    }
}
