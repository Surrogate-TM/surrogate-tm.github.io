﻿namespace DataLinkedOrgChart
{
    partial class RibbonDesign
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tab1 = new Microsoft.Office.Tools.Ribbon.RibbonTab();
            this.tabDataOrgChart = new Microsoft.Office.Tools.Ribbon.RibbonTab();
            this.group1 = new Microsoft.Office.Tools.Ribbon.RibbonGroup();
            this.buttonCreate = new Microsoft.Office.Tools.Ribbon.RibbonButton();
            this.group2 = new Microsoft.Office.Tools.Ribbon.RibbonGroup();
            this.buttonGenerate = new Microsoft.Office.Tools.Ribbon.RibbonButton();
            this.group3 = new Microsoft.Office.Tools.Ribbon.RibbonGroup();
            this.buttonApplyDataGraphics = new Microsoft.Office.Tools.Ribbon.RibbonButton();
            this.buttonLayout = new Microsoft.Office.Tools.Ribbon.RibbonButton();
            this.tab1.SuspendLayout();
            this.tabDataOrgChart.SuspendLayout();
            this.group1.SuspendLayout();
            this.group2.SuspendLayout();
            this.group3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab1
            // 
            this.tab1.ControlId.ControlIdType = Microsoft.Office.Tools.Ribbon.RibbonControlIdType.Office;
            this.tab1.Label = "TabAddIns";
            this.tab1.Name = "tab1";
            // 
            // tabDataOrgChart
            // 
            this.tabDataOrgChart.Groups.Add(this.group1);
            this.tabDataOrgChart.Groups.Add(this.group2);
            this.tabDataOrgChart.Groups.Add(this.group3);
            this.tabDataOrgChart.Label = "Data Org Chart";
            this.tabDataOrgChart.Name = "tabDataOrgChart";
            // 
            // group1
            // 
            this.group1.Items.Add(this.buttonCreate);
            this.group1.Label = "Create";
            this.group1.Name = "group1";
            // 
            // buttonCreate
            // 
            this.buttonCreate.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.buttonCreate.Label = "Create new org chart";
            this.buttonCreate.Name = "buttonCreate";
            this.buttonCreate.OfficeImageId = "AdpDiagramNewTable";
            this.buttonCreate.ScreenTip = "Create a new Org Chart diagram.";
            this.buttonCreate.ShowImage = true;
            this.buttonCreate.SuperTip = "Create a new Org Chart diagram from the template for this add-in.";
            // 
            // group2
            // 
            this.group2.Items.Add(this.buttonGenerate);
            this.group2.Label = "Generate";
            this.group2.Name = "group2";
            // 
            // buttonGenerate
            // 
            this.buttonGenerate.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.buttonGenerate.Label = "Generate";
            this.buttonGenerate.Name = "buttonGenerate";
            this.buttonGenerate.OfficeImageId = "ImportMoreMenu";
            this.buttonGenerate.ScreenTip = "Generate an Org Chart.";
            this.buttonGenerate.ShowImage = true;
            this.buttonGenerate.SuperTip = "Generate an Org Chart from data via this add-in.";
            // 
            // group3
            // 
            this.group3.Items.Add(this.buttonApplyDataGraphics);
            this.group3.Items.Add(this.buttonLayout);
            this.group3.Label = "Decorate";
            this.group3.Name = "group3";
            // 
            // buttonApplyDataGraphics
            // 
            this.buttonApplyDataGraphics.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.buttonApplyDataGraphics.Image = global::DataLinkedOrgChart.Properties.Resources.OperationsManagerProductIcon_32;
            this.buttonApplyDataGraphics.Label = "Apply Data Graphics";
            this.buttonApplyDataGraphics.Name = "buttonApplyDataGraphics";
            this.buttonApplyDataGraphics.ShowImage = true;
            // 
            // buttonLayout
            // 
            this.buttonLayout.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.buttonLayout.Label = "Layout";
            this.buttonLayout.Name = "buttonLayout";
            this.buttonLayout.OfficeImageId = "SmartArtOrganizationChartMenu";
            this.buttonLayout.ShowImage = true;
            // 
            // RibbonDesign
            // 
            this.Name = "RibbonDesign";
            this.RibbonType = "Microsoft.Visio.Drawing";
            this.Tabs.Add(this.tab1);
            this.Tabs.Add(this.tabDataOrgChart);
            this.Load += new System.EventHandler<Microsoft.Office.Tools.Ribbon.RibbonUIEventArgs>(this.Ribbon1_Load);
            this.tab1.ResumeLayout(false);
            this.tab1.PerformLayout();
            this.tabDataOrgChart.ResumeLayout(false);
            this.tabDataOrgChart.PerformLayout();
            this.group1.ResumeLayout(false);
            this.group1.PerformLayout();
            this.group2.ResumeLayout(false);
            this.group2.PerformLayout();
            this.group3.ResumeLayout(false);
            this.group3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal Microsoft.Office.Tools.Ribbon.RibbonTab tab1;
        private Microsoft.Office.Tools.Ribbon.RibbonTab tabDataOrgChart;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group1;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton buttonCreate;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group2;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton buttonGenerate;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group3;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton buttonApplyDataGraphics;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton buttonLayout;
    }

    partial class ThisRibbonCollection : Microsoft.Office.Tools.Ribbon.RibbonReadOnlyCollection
    {
        internal RibbonDesign Ribbon
        {
            get { return this.GetRibbon<RibbonDesign>(); }
        }
    }
}
