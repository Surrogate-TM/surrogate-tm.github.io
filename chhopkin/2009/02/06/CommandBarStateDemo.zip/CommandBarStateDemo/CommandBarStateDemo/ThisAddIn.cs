﻿//-----------------------------------------------------------------------
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

using Visio = Microsoft.Office.Interop.Visio;

using Microsoft.Office.Core;
using Office = Microsoft.Office.Core;

namespace CommandBarStateDemo
{
    public partial class ThisAddIn
    {
        #region fields

        private UIMgr _UIMgr;

        #endregion

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            // create a new instance of our UIMgr class
            // and call the AddUI() method to create our UI
            _UIMgr = new UIMgr();
            _UIMgr.AddUI();
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            // remove our customizations from the UI during shutdown
            // this handles the user unchecking the add-in from the list of managed add-in from
            // the Trust Center
            _UIMgr.RemoveUI();
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion

        internal bool CheckScope_OurDocument()
        {
            // code to determine is the active document is our document
            // in this case if the document is from the Basic Template then it is our document
            return Application.ActiveDocument.Template.EndsWith("BASICD_U.VST");
        }

        internal void buttonItem1_Click(CommandBarButton Ctrl, ref bool CancelDefault)
        {
            System.Windows.Forms.MessageBox.Show("Item 1");
        }

        internal void buttonItem2_Click(CommandBarButton Ctrl, ref bool CancelDefault)
        {
            System.Windows.Forms.MessageBox.Show("Item 2");
        }

        internal void buttonItem3_Click(CommandBarButton Ctrl, ref bool CancelDefault)
        {
            System.Windows.Forms.MessageBox.Show("Item 3");
        }

        internal void buttonAbout_Click(CommandBarButton Ctrl, ref bool CancelDefault)
        {
            System.Windows.Forms.MessageBox.Show("About");
        }
    }
}
