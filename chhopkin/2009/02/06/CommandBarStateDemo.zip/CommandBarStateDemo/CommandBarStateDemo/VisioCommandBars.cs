﻿//-----------------------------------------------------------------------
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;

using Visio = Microsoft.Office.Interop.Visio;
using Office = Microsoft.Office.Core;

namespace CommandBarStateDemo
{
    public delegate bool CheckScopeCallback();

    public interface IVisioCommandBarItem
    {
        string Tag
        {
            get;
        }
    }

    [Flags]
    internal enum ButtonEnabled : int
    {
        Custom = 0,
        AlwaysActive = 1,
        DocumentActive = 2,
        SelectionActive = 4,
    }

    /// <summary>
    /// Wrapper class for Office.CommandBarButton objects
    /// </summary>
    internal sealed class VisioCommandBarButton : IVisioCommandBarItem
    {
        #region fields

        private Visio.Application _VisioApplication;

        private string _Tag;
        private Microsoft.Office.Core.CommandBarButton _CommandBarButton;

        private Microsoft.Office.Core.MsoButtonState _State = Microsoft.Office.Core.MsoButtonState.msoButtonUp;

        private ButtonEnabled _EnabledState = ButtonEnabled.AlwaysActive;

        private CheckScopeCallback _CheckScopeCallback = null;

        private bool _Update = true;

        #endregion

        #region construction / destruction

        /// <summary>
        /// Private to restrict access.
        /// </summary>
        private VisioCommandBarButton()
        {
        }

        /// <summary>
        /// Constructor - CommandBarButton
        /// </summary>
        /// <param name="button">
        /// The Office.CommandBarButton to wrap.
        /// </param>
        public VisioCommandBarButton(
            Visio.Application visioApplication,
            Microsoft.Office.Core.CommandBarButton commandBarButton,
            ButtonEnabled enabledState)
        {
            System.Diagnostics.Debug.WriteLine("VisioCommandBarButton::Constructor");

            _VisioApplication = visioApplication;

            _Tag = commandBarButton.Tag; // store the tag so we can search for it later
            _EnabledState = enabledState;

            _CommandBarButton = commandBarButton; // keep a ref to this button to keep it alive and to access Visio.Application instance

            // setup the event sink for this application object
            VisioEvents_Connect();
        }

        /// <summary>
        /// Constructor - CommandBarButton
        /// </summary>
        /// <param name="button">
        /// The Office.CommandBarButton to wrap.
        /// </param>
        public VisioCommandBarButton(
            Visio.Application visioApplication,
            Microsoft.Office.Core.CommandBarButton commandBarButton,
            ButtonEnabled enabledState,
            CheckScopeCallback checkScopeCallback)
        {
            System.Diagnostics.Debug.WriteLine("VisioCommandBarButton::Constructor");

            _VisioApplication = visioApplication;

            _Tag = commandBarButton.Tag; // store the tag so we can search for it later
            _EnabledState = enabledState;

            _CheckScopeCallback = checkScopeCallback;

            _CommandBarButton = commandBarButton; // keep a ref to this button to keep it alive

            // setup the event sink for this application object
            VisioEvents_Connect();
        }

        #endregion

        #region visio events

        /// <summary>
        ///	Setup the event sinks at the Visio Application object level.
        /// </summary>
        private void VisioEvents_Connect()
        {
            if (_VisioApplication != null)
            {
                _VisioApplication.AppObjActivated += new Microsoft.Office.Interop.Visio.EApplication_AppObjActivatedEventHandler(VisioApplication_AppObjActivated);
                _VisioApplication.AfterModal += new Microsoft.Office.Interop.Visio.EApplication_AfterModalEventHandler(VisioApplication_AfterModal);

                _VisioApplication.WindowOpened += new Microsoft.Office.Interop.Visio.EApplication_WindowOpenedEventHandler(VisioApplication_WindowOpened);
                _VisioApplication.WindowActivated += new Microsoft.Office.Interop.Visio.EApplication_WindowActivatedEventHandler(VisioApplication_WindowActivated);
                _VisioApplication.WindowChanged += new Microsoft.Office.Interop.Visio.EApplication_WindowChangedEventHandler(VisioApplication_WindowChanged);

                _VisioApplication.BeforeWindowClosed += new Microsoft.Office.Interop.Visio.EApplication_BeforeWindowClosedEventHandler(VisioApplication_BeforeWindowClosed);

                if ((_EnabledState & ButtonEnabled.SelectionActive) == ButtonEnabled.SelectionActive)
                {
                    _VisioApplication.SelectionChanged += new Microsoft.Office.Interop.Visio.EApplication_SelectionChangedEventHandler(VisioApplication_SelectionChanged);
                }

                _VisioApplication.MarkerEvent += new Microsoft.Office.Interop.Visio.EApplication_MarkerEventEventHandler(VisioApplication_MarkerEvent);

                if (_EnabledState > ButtonEnabled.AlwaysActive)
                {
                    _VisioApplication.VisioIsIdle += new Microsoft.Office.Interop.Visio.EApplication_VisioIsIdleEventHandler(VisioApplication_VisioIsIdle);
                }
            }
        }

        /// <summary>
        /// Handler for MarkerEvent from Visio.Application
        /// 
        /// I added this as some built in Visio solutions fire empty marker events while they are performing actions in the drawing and the UI
        /// this seems to help keep our ui updated with visio solution UI changes
        /// </summary>
        /// <param name="visioApplication"></param>
        /// <param name="SequenceNum"></param>
        /// <param name="ContextString"></param>
        private void VisioApplication_MarkerEvent(
            Visio.Application visioApplication,
            int SequenceNum,
            string ContextString)
        {
            if (ContextString == null || ContextString.Trim() == string.Empty)
            {
                _Update = true;
            }
        }

        private void VisioApplication_VisioIsIdle(
            Visio.Application visioApplication)
        {
            // update the state of this button
            if (_Update)
            {
                UpdateState(visioApplication.ActiveWindow);

                _Update = false;
            }
        }

        private void VisioApplication_AfterModal(
            Visio.Application visioApplication)
        {
            _Update = true;
        }

        private void VisioApplication_AppObjActivated(
            Visio.Application visioApplication)
        {
            _Update = true;
        }

        private void VisioApplication_WindowActivated(
            Visio.Window visioWindow)
        {
            _Update = true;
        }

        private void VisioApplication_WindowChanged(
            Visio.Window visioWindow)
        {
            _Update = true;
        }

        private void VisioApplication_SelectionChanged(
            Visio.Window visioWindow)
        {
            _Update = true;
        }

        private void VisioApplication_WindowOpened(
            Visio.Window visioWindow)
        {
            _Update = true;
        }

        private void VisioApplication_BeforeWindowClosed(
            Visio.Window visioWindow)
        {
            _Update = true;
        }

        #endregion

        #region methods

        internal void SetState(
            Microsoft.Office.Core.MsoButtonState state)
        {
            // set the property for this wrapper
            _State = state;

            // get the application level command bars
            Microsoft.Office.Core.CommandBars visioCommandBars = _VisioApplication.CommandBars as Microsoft.Office.Core.CommandBars;

            // find the menu CommandBarButton with this tag
            Microsoft.Office.Core.CommandBarButton foundMenuButton = visioCommandBars["Menu Bar"].FindControl(Microsoft.Office.Core.MsoControlType.msoControlButton, 0, _Tag, true, true) as Microsoft.Office.Core.CommandBarButton;

            if (foundMenuButton != null)
            {
                if (foundMenuButton.State != state)
                {
                    foundMenuButton.State = state;
                }
            }

            // find the toolbar CommandBarButton with this tag
            Microsoft.Office.Core.CommandBarButton foundToolbarButton = visioCommandBars.FindControl(Microsoft.Office.Core.MsoControlType.msoControlButton, 0, _Tag, true) as Microsoft.Office.Core.CommandBarButton;

            if (foundToolbarButton != null)
            {
                if (foundToolbarButton.State != state)
                {
                    // this is a drawing window so enable it
                    foundToolbarButton.State = state;
                }
            }
        }

        /// <summary>
        /// UpdateEnabledState method to update the state of the UI Item.
        /// </summary>
        public void UpdateState(
            Visio.Window visioWindow)
        {
            if (_EnabledState == ButtonEnabled.AlwaysActive)
            {
                return;
            }

            bool enabled = false; // default to false and prove that it is true below

            switch (_EnabledState)
            {
                case ButtonEnabled.Custom:
                    {
                        // just call the custom call back
                        // the callback must exist and must return true to enable the item
                        if (_CheckScopeCallback != null)
                        {
                            enabled = _CheckScopeCallback();
                        }

                        break;
                    }

                case ButtonEnabled.DocumentActive:
                    {
                        if (visioWindow != null &&
                            visioWindow.Document != null)
                        {
                            if (_CheckScopeCallback != null)
                            {
                                enabled = _CheckScopeCallback();
                            }
                            else
                            {
                                // no callback exists but there is an active document so return true
                                enabled = true;
                            }
                        }

                        break;
                    }

                case ButtonEnabled.SelectionActive:
                    {
                        if (visioWindow != null)
                        {
                            Visio.Selection visioSelection = visioWindow.Selection;

                            if (visioSelection != null)
                            {
                                Visio.Shape selectedShape = null;

                                if (visioSelection.Count > 0)
                                {
                                    selectedShape = visioSelection.PrimaryItem;
                                }
                                else
                                {
                                    visioSelection.IterationMode = (int)Visio.VisSelectMode.visSelModeOnlySub;
                                }

                                selectedShape = visioSelection.PrimaryItem;

                                if (selectedShape != null)
                                {
                                    if (_CheckScopeCallback != null)
                                    {
                                        enabled = _CheckScopeCallback();
                                    }
                                    else
                                    {
                                        // no callback exists but there is a selection so return true
                                        enabled = true;
                                    }
                                }
                            }
                        }

                        break;
                    }

                default:
                    {
                        enabled = false;
                        break;
                    }
            }

            // get the application level command bars object
            Microsoft.Office.Core.CommandBars visioCommandBars = _VisioApplication.CommandBars as Microsoft.Office.Core.CommandBars;

            Microsoft.Office.Core.CommandBarControls foundControls = visioCommandBars.FindControls(
                System.Reflection.Missing.Value,
                System.Reflection.Missing.Value,
                _Tag,
                System.Reflection.Missing.Value) as Microsoft.Office.Core.CommandBarControls;

            foreach (Microsoft.Office.Core.CommandBarControl nextControl in foundControls)
            {
                if (nextControl.Enabled != enabled)
                {
                    nextControl.Enabled = enabled;
                }

                if (nextControl.Type == Microsoft.Office.Core.MsoControlType.msoControlButton)
                {
                    Microsoft.Office.Core.CommandBarButton nextButton = nextControl as Microsoft.Office.Core.CommandBarButton;
                    
                    if (nextButton != null)
                    {
                        if (nextButton.State != _State)
                        {
                            nextButton.State = _State;
                        }
                    }
                }
            }
        }

        #endregion

        #region IVisioCommandBarItem Members

        public string Tag
        {
            get { return _Tag; }
        }

        #endregion
    }

    /// <summary>
    /// Wrapper class for Office.CommandBarButton objects
    /// </summary>
    internal sealed class VisioCommandBarPopup : IVisioCommandBarItem
    {
        #region fields

        private Visio.Application _VisioApplication;

        private string _Tag;
        private Microsoft.Office.Core.CommandBarPopup _CommandBarPopup;

        //private bool _Enabled = true;
        private ButtonEnabled _EnabledState = ButtonEnabled.AlwaysActive;

        private CheckScopeCallback _CheckScopeCallback = null;
        private string _CheckScopeCellName = string.Empty;
        private string _CheckScopeCellValue = string.Empty;

        private bool _Update = true;

        #endregion

        #region construction / destruction

        /// <summary>
        /// Private to restrict access.
        /// </summary>
        private VisioCommandBarPopup()
        {
        }

        /// <summary>
        /// Constructor - CommandBarButton
        /// </summary>
        /// <param name="button">
        /// The Office.CommandBarButton to wrap.
        /// </param>
        public VisioCommandBarPopup(
            Visio.Application visioApplication,
            Microsoft.Office.Core.CommandBarPopup commandBarPopup,
            ButtonEnabled enabledState)
        {
            System.Diagnostics.Debug.WriteLine("VisioCommandBarPopup::Constructor");

            _VisioApplication = visioApplication;

            _Tag = commandBarPopup.Tag; // store the tag so we can search for it later
            _EnabledState = enabledState;

            _CommandBarPopup = commandBarPopup; // keep a ref to this button to keep it alive

            // setup the event sink for this application object
            VisioEvents_Connect();
        }

        /// <summary>
        /// Constructor - CommandBarPopup
        /// </summary>
        /// <param name="button">
        /// The Office.CommandBarButton to wrap.
        /// </param>
        public VisioCommandBarPopup(
            Visio.Application visioApplication,
            Microsoft.Office.Core.CommandBarPopup commandBarPopup,
            ButtonEnabled enabledState,
            CheckScopeCallback checkScopeCallback,
            string checkScopeCellName,
            string checkScopeCellValue)
        {
            System.Diagnostics.Debug.WriteLine("VisioCommandBarPopup::Constructor");

            _VisioApplication = visioApplication;

            _Tag = commandBarPopup.Tag; // store the tag so we can search for it later
            _EnabledState = enabledState;

            _CheckScopeCallback = checkScopeCallback;
            _CheckScopeCellName = checkScopeCellName;
            _CheckScopeCellValue = checkScopeCellValue;

            _CommandBarPopup = commandBarPopup; // keep a ref to this button to keep it alive

            // setup the event sink for this application object
            VisioEvents_Connect();
        }

        #endregion

        #region visio events

        /// <summary>
        ///	Setup the event sinks at the Visio Application object level.
        /// </summary>
        private void VisioEvents_Connect()
        {
            if (_VisioApplication != null)
            {
                _VisioApplication.AppObjActivated += new Microsoft.Office.Interop.Visio.EApplication_AppObjActivatedEventHandler(VisioApplication_AppObjActivated);
                _VisioApplication.AfterModal += new Microsoft.Office.Interop.Visio.EApplication_AfterModalEventHandler(VisioApplication_AfterModal);

                _VisioApplication.WindowOpened += new Microsoft.Office.Interop.Visio.EApplication_WindowOpenedEventHandler(VisioApplication_WindowOpened);
                _VisioApplication.WindowActivated += new Microsoft.Office.Interop.Visio.EApplication_WindowActivatedEventHandler(VisioApplication_WindowActivated);
                _VisioApplication.WindowChanged += new Microsoft.Office.Interop.Visio.EApplication_WindowChangedEventHandler(VisioApplication_WindowChanged);

                _VisioApplication.BeforeWindowClosed += new Microsoft.Office.Interop.Visio.EApplication_BeforeWindowClosedEventHandler(VisioApplication_BeforeWindowClosed);

                if ((_EnabledState & ButtonEnabled.SelectionActive) == ButtonEnabled.SelectionActive)
                {
                    _VisioApplication.SelectionChanged += new Microsoft.Office.Interop.Visio.EApplication_SelectionChangedEventHandler(VisioApplication_SelectionChanged);
                }

                _VisioApplication.MarkerEvent += new Microsoft.Office.Interop.Visio.EApplication_MarkerEventEventHandler(VisioApplication_MarkerEvent);

                if (_EnabledState > ButtonEnabled.AlwaysActive)
                {
                    _VisioApplication.VisioIsIdle += new Microsoft.Office.Interop.Visio.EApplication_VisioIsIdleEventHandler(VisioApplication_VisioIsIdle);
                }
            }
        }

        /// <summary>
        /// Handler for MarkerEvent from Visio.Application
        /// 
        /// I added this as some built in Visio solutions fire empty marker events while they are performing actions in the drawing and the UI
        /// this seems to help keep our ui updated with visio solution UI changes
        /// </summary>
        /// <param name="visioApplication"></param>
        /// <param name="SequenceNum"></param>
        /// <param name="ContextString"></param>
        private void VisioApplication_MarkerEvent(
            Visio.Application visioApplication,
            int SequenceNum,
            string ContextString)
        {
            if (ContextString == null || ContextString.Trim() == string.Empty)
            {
                _Update = true;
            }
        }

        private void VisioApplication_VisioIsIdle(
            Visio.Application visioApplication)
        {
            // update the state of this button
            if (_Update)
            {
                UpdateState(visioApplication.ActiveWindow);

                _Update = false;
            }
        }

        private void VisioApplication_AfterModal(
            Visio.Application visioApplication)
        {
            _Update = true;
        }

        private void VisioApplication_AppObjActivated(
            Visio.Application visioApplication)
        {
            _Update = true;
        }

        private void VisioApplication_WindowActivated(
            Visio.Window visioWindow)
        {
            _Update = true;
        }

        void VisioApplication_WindowChanged(
            Visio.Window visioWindow)
        {
            _Update = true;
        }

        private void VisioApplication_SelectionChanged(
            Visio.Window visioWindow)
        {
            _Update = true;
        }

        private void VisioApplication_WindowOpened(
            Visio.Window visioWindow)
        {
            _Update = true;
        }

        private void VisioApplication_BeforeWindowClosed(
            Visio.Window visioWindow)
        {
            _Update = true;
        }

        #endregion

        #region methods

        /// <summary>
        /// UpdateState method to update the state of the UI Item.
        /// Popup only supports Enabled / Disabled states
        /// </summary>
        public void UpdateState(
            Visio.Window visioWindow)
        {
            if (_EnabledState == ButtonEnabled.AlwaysActive)
            {
                return;
            }

            bool enabled = false; // default to false and prove that it is true below

            switch (_EnabledState)
            {
                case ButtonEnabled.Custom:
                    {
                        // just call the custom call back
                        // the callback must exist and must return true to enable the item
                        if (_CheckScopeCallback != null)
                        {
                            enabled = _CheckScopeCallback();
                        }

                        break;
                    }

                case ButtonEnabled.DocumentActive:
                    {
                        if (visioWindow != null &&
                            visioWindow.Document != null)
                        {
                            if (_CheckScopeCallback != null)
                            {
                                enabled = _CheckScopeCallback();
                            }
                            else
                            {
                                // no callback exists but there is an active document so return true
                                enabled = true;
                            }
                        }

                        break;
                    }

                case ButtonEnabled.SelectionActive:
                    {
                        if (visioWindow != null)
                        {
                            Visio.Selection visioSelection = visioWindow.Selection;

                            if (visioSelection != null)
                            {
                                Visio.Shape selectedShape = null;

                                if (visioSelection.Count > 0)
                                {
                                    selectedShape = visioSelection.PrimaryItem;
                                }
                                else
                                {
                                    visioSelection.IterationMode = (int)Visio.VisSelectMode.visSelModeOnlySub;
                                }

                                selectedShape = visioSelection.PrimaryItem;

                                if (selectedShape != null)
                                {
                                    if (_CheckScopeCallback != null)
                                    {
                                        enabled = _CheckScopeCallback();
                                    }
                                    else
                                    {
                                        // no callback exists but there is a selection so return true
                                        enabled = true;
                                    }
                                }
                            }
                        }

                        break;
                    }

                default:
                    {
                        enabled = false;
                        break;
                    }
            }

            // get the application level command bars object
            Microsoft.Office.Core.CommandBars visioCommandBars = _VisioApplication.CommandBars as Microsoft.Office.Core.CommandBars;

            Microsoft.Office.Core.CommandBarControls foundControls = visioCommandBars.FindControls(
                System.Reflection.Missing.Value,
                System.Reflection.Missing.Value,
                _Tag,
                System.Reflection.Missing.Value) as Microsoft.Office.Core.CommandBarControls;

            foreach (Microsoft.Office.Core.CommandBarControl nextControl in foundControls)
            {
                if (nextControl.Enabled != enabled)
                {
                    nextControl.Enabled = enabled;
                }
            }
        }

        #endregion

        #region IVisioCommandBarItem Members

        public string Tag
        {
            get { return _Tag; }
        }

        #endregion
    }
}
