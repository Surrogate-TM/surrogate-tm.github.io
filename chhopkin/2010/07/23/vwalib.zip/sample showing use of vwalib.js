<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:mso="urn:schemas-microsoft-com:office:office" xmlns:msdt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882">
<head>
<title>Test VWALIB</title>
</head>
<body>

<script src="/SiteAssets/jscript/vwalib.js" type="text/javascript">
    // copied to the SiteAssets/jscript folder using SharePoint Designer
    // full path = http://vgstest01/SiteAssets/jscript/vwalib.js
</script>

<script language="javascript">
Sys.Application.add_load(onApplicationLoad)

// globals
var vwaControl; 
var vwaPage; 
var vwaShapes; 
var vwaShapeCount; 

function onApplicationLoad()
{
    // get the visio web part instance
    getVwaControl();
    
    // hook up to the events we need for this application
    if (vwaControl != null)
    {
        vwaControl.addHandler("diagramcomplete", onDiagramComplete);
        vwaControl.addHandler("shapeselectionchanged", onShapeSelectionChanged);           
    }
    else
    {
        alert("Error connecting to Visio Web Part.  Please contact the site administrator.");
    }
}

//----------------------------------------------------------
// Wait till the default page is loaded by VwaControl; get
// references to all of these objects for later use during 
// the script.
//----------------------------------------------------------
function onDiagramComplete()
{
    vwaPage = vwaControl.getActivePage();
    vwaShapes = vwaPage.getShapes(); 
    vwaShapeCount = vwaShapes.getCount(); 
    vwaPage.setZoom(100);
}

//----------------------------------------------------------
// On shape selection changed, this function extracts the
// Shape Data from a shape and passes it along as a URL
// parameter to the HRDataSystem ASPX application that is 
// being displayed in the EmployeeData IFRAME on the page.
//----------------------------------------------------------
function onShapeSelectionChanged(source, args)
{
    // get the selected shape from the shapes on the page
    vwaPage = vwaControl.getActivePage(); 
    vwaShapes = vwaPage.getShapes(); 
    var shape = vwaShapes.getItemById(args);

    alert(shape);
}

</SCRIPT>

</body>
</html>