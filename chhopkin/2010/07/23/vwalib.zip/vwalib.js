/*!
* Visio Web Access JavaScript Library v1.0.1
*
* Copyright 2010, Microsoft
*/

//----------------------------------------------------------
// gets the first instance of the VisioWebAccess web part on this page.
// 
// if you have more than one VWA web part on the page this
// function will return the first one that is found
//----------------------------------------------------------
function getVwaControl()
{
    var webPartID = null;

    try
    {
        webPartID = findVwaControlId();

        if (webPartID == null) {
            throw new Error("VisioWebAccess class not found.  Please contact the site administrator.");
    }

        // get the web part ID that we found on the page
        vwaControl = new Vwa.VwaControl(webPartID);
    }
    catch (ex)
    {
        alert(ex);
    }
}

//----------------------------------------------------------
// find the ID of the VisioWebAccess web part on this page.
// 
// if you have more than one VWA web part on the page this
// function will return the first one that is found
//----------------------------------------------------------
function findVwaControlId()
{
    var retVal = null;

    var divCollection = document.getElementsByTagName("div");

    for (var i = 0; i < divCollection.length; i++)
    {
        if (divCollection[i].getAttribute("class") == "VisioWebAccess")
        {
            // the actual id of the VWA web part is two levels higher than this class node
            retVal = divCollection[i].parentNode.parentNode.getAttribute('id');
            break;
        }
    }

    return retVal;
}