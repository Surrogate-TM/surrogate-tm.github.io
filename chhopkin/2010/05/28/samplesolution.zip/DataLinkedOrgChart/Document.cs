﻿//-----------------------------------------------------------------------
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Visio = Microsoft.Office.Interop.Visio;

namespace DataLinkedOrgChart
{
    internal class Document
    {
        private Visio.Document _VisioDocument;

        private Document(
            Visio.Document visioDocument)
        {
            _VisioDocument = visioDocument;
        }

        internal static bool TryCreate(
            Visio.Document visioDocument,
            out Document createdDocument)
        {
            if (visioDocument == null)
            {
                throw new ArgumentNullException("visioDocument");
            }

            // check if based on our template
            if (System.IO.Path.GetFileName(visioDocument.Template) == Globals.VisioTemplateFileName)
            {
                // this is our document
                createdDocument = new Document(visioDocument);
                return true;

                // NOTE - a better test would be a document level user cell value
            }

            // set out param
            createdDocument = null;

            // return failure
            return false;
        }

        internal void Generate()
        {
            try
            {
                // build a datatable from our XML
                System.Data.DataTable dataTable = DataLinkedOrgChartAdapter.DataHelper.GetData(@"\\osan\visio\User\chhopkin\Visio 2010\Data Linked Org Chart add-in\sample data.xml");

                // convert this to ADO XML so Visio can understand it
                string newXmlData = ADONET2ADO.ConvertToAdoRecordsetXml(dataTable);

                // create the datarecordset from the converted xml
                Visio.DataRecordset newRecordSet = _VisioDocument.DataRecordsets.AddFromXML(newXmlData, 0, "Team Members");

                // set the command string for Visio Services to use to connect with the data adapter
                // this is a custom wrapper class that you can use to help you build your commandstrings
                CommandString commandString = new CommandString();
                commandString.DataPath = @"\\osan\visio\User\chhopkin\Visio 2010\Data Linked Org Chart add-in\sample data.xml";
                newRecordSet.CommandString = commandString.ToString();

                #region generate the diagram from the datarecordset

                if (newRecordSet != null)
                {
                    /* drop a linked shape for each row in the new dataset */

                    // get the row ids for the rows to drop linked shapes for
                    System.Array rowIDsToDrop = newRecordSet.GetDataRowIDs(""); // no filter provided

                    // create an array for each master name to drop
                    System.Array masterToDrop = Array.CreateInstance(
                        typeof(object), rowIDsToDrop.Length);

                    // create an array for each location of each row
                    System.Array pins = Array.CreateInstance(
                        typeof(double), rowIDsToDrop.Length * 2); // x and y pairs

                    /* init all the data for the drop */
                    System.Random randGen = new Random();

                    for (int nextRowIDIndex = 0; nextRowIDIndex < rowIDsToDrop.Length; nextRowIDIndex++)
                    {
                        masterToDrop.SetValue("Position", nextRowIDIndex);

                        // get the random pin x value based on the width of the target page
                        pins.SetValue(
                            randGen.Next(0, 11), //(int)_VisioDocument.Pages[1].PageSheet.get_CellsU("PageWidth").ResultIU),
                            nextRowIDIndex*2); // each x location in the array

                        // get the random pin y value based on the height of the targer page
                        pins.SetValue(
                            randGen.Next(0, 8), //(int)_VisioDocument.Pages[1].PageSheet.get_CellsU("PageHeight").ResultIU),
                            nextRowIDIndex*2+1); // each y location in the array
                    }

                    /* perform the drop operation */

                    System.Array droppedShapeIDs;

                    _VisioDocument.Pages[1].DropManyLinkedU(
                        ref masterToDrop,
                        ref pins,
                        newRecordSet.ID,
                        ref rowIDsToDrop,
                        false,
                        out droppedShapeIDs);

                    /* connect the shapes based on ReportsTo */

                    // get the primary key for this dataset
                    Visio.VisPrimaryKeySettings pkSettings;
                    System.Array primaryKey;
                    newRecordSet.GetPrimaryKey(out pkSettings, out primaryKey);

                    /* get the ReportsTo column */
                    
                    // get the names of all the column in the data set
                    System.Array colNames = newRecordSet.GetRowData(0);

                    // get the column index
                    int colIndex = -1;
                    for (int nextColIndex = 0; nextColIndex < colNames.Length; nextColIndex++)
                    {
                        if (string.Equals(colNames.GetValue(nextColIndex), "Reports To"))
                        {
                            colIndex = nextColIndex;
                            break;
                        }
                    }

                    System.Diagnostics.Debug.Assert(
                        colIndex > -1,
                        "Reports To column not found");

                    /* get the child and parent shapes for each row that was dropped */

                    for (int nextChildRowIndex = 0; nextChildRowIndex < rowIDsToDrop.Length; nextChildRowIndex++)
                    {
                        // get the child shape
                        Visio.Shape parentShape = null;
                        Visio.Shape childShape = _VisioDocument.Pages[1].Shapes.get_ItemFromID(
                            int.Parse(droppedShapeIDs.GetValue(nextChildRowIndex).ToString()));

                        // for each row get the Reports To field value
                        System.Array rowData = newRecordSet.GetRowData(
                            int.Parse(rowIDsToDrop.GetValue(nextChildRowIndex).ToString()));

                        object reportsTo = rowData.GetValue(colIndex);
                        if (reportsTo.ToString().Length > 0)
                        {
                            // the reports to field is not null so this person reports to someone in the dataset

                            // who do they report to
                            for (int parentRowIndex = 0; parentRowIndex < rowIDsToDrop.Length; parentRowIndex++)
                            {
                                // for each row get the ReportsTo field value
                                System.Array parentRowData = newRecordSet.GetRowData(
                                    int.Parse(rowIDsToDrop.GetValue(parentRowIndex).ToString()));

                                if (parentRowData.GetValue(0).Equals(reportsTo))
                                {
                                    // get the parent shape
                                    parentShape = _VisioDocument.Pages[1].Shapes.get_ItemFromID(
                                        int.Parse(droppedShapeIDs.GetValue(parentRowIndex).ToString()));

                                    break;
                                }
                            }

                            if (parentShape != null && childShape != null)
                            {
                                parentShape.AutoConnect(
                                    childShape, 
                                    Visio.VisAutoConnectDir.visAutoConnectDirDown,
                                    null);
                            }
                        }
                    }

                    // display the external data window
                    _VisioDocument.Application.ActiveWindow.Windows.get_ItemFromID(
                        (short)Visio.VisWinTypes.visWinIDExternalData).Visible = true;
                }

                #endregion
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString());
            }
        }

        internal void ApplyDataGraphics()
        {
            // for each shape on the page, apply a data graphic
            Visio.Master masterDataGraphic = Globals.ThisAddIn.Application.ActiveDocument.Masters["Data Graphic.13"];

            if (masterDataGraphic == null)
            {
                System.Windows.Forms.MessageBox.Show("The specified Data Graphic could not be found!");
                return;
            }

            foreach (Visio.Shape nextShape in Globals.ThisAddIn.Application.ActivePage.Shapes)
            {
                // find the "Utilization" property cell
                System.Array linkedPropRows = null;

                nextShape.GetCustomPropertiesLinkedToData(
                    Globals.ThisAddIn.Application.ActiveDocument.DataRecordsets[1].ID,
                    out linkedPropRows);

                if (linkedPropRows.Length > 0) // this is a simple check, could be updated to check into the shape further for the specific Utilization property
                {
                    for (int nextLinkedRowIndex = 0; nextLinkedRowIndex < linkedPropRows.Length; nextLinkedRowIndex++)
                    {
                        short linkedRowID = short.Parse(linkedPropRows.GetValue(nextLinkedRowIndex).ToString());

                        string rowLabel = nextShape.get_CellsSRC(
                            (short)Visio.VisSectionIndices.visSectionProp,
                            linkedRowID,
                            (short)Visio.VisCellIndices.visCustPropsLabel).get_ResultStrU(Visio.VisUnitCodes.visNoCast);

                        if (rowLabel.ToLower() == "utilization")
                        {
                            string rowValue = nextShape.get_CellsSRC(
                            (short)Visio.VisSectionIndices.visSectionProp,
                            linkedRowID,
                            (short)Visio.VisCellIndices.visCustPropsValue).FormulaU;

                            if (rowValue.Length > 0)
                            {
                                nextShape.DataGraphic = masterDataGraphic;
                                break;
                            }
                        }
                    }
                }
            }
        }

        internal void Layout()
        {
            // set layout options to just hierarchy, top down centered, this is a simple page setting
            _VisioDocument.Pages[1].PageSheet.get_CellsU("PlaceStyle").FormulaU = "=17";

            // perform the layout on this page
            _VisioDocument.Pages[1].Layout();
        }
    }
}
