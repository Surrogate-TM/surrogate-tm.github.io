﻿// TODO:  Follow these steps to enable the Ribbon (XML) item:

// 1: Copy the following code block into the ThisAddin, ThisWorkbook, or ThisDocument class.

//  protected override Microsoft.Office.Core.IRibbonExtensibility CreateRibbonExtensibilityObject()
//  {
//      return new Ribbon1();
//  }

// 2. Create callback methods in the "Ribbon Callbacks" region of this class to handle user
//    actions, such as clicking a button. Note: if you have exported this Ribbon from the Ribbon designer,
//    move your code from the event handlers to the callback methods and modify the code to work with the
//    Ribbon extensibility (RibbonX) programming model.

// 3. Assign attributes to the control tags in the Ribbon XML file to identify the appropriate callback methods in your code.  

// For more information, see the Ribbon XML documentation in the Visual Studio Tools for Office Help.


namespace DataLinkedOrgChart
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Text;

    using Office = Microsoft.Office.Core;

    using Visio = Microsoft.Office.Interop.Visio;

    [ComVisible(true)]
    public class Ribbon : Office.IRibbonExtensibility
    {
        private Office.IRibbonUI ribbon;

        public Ribbon()
        {
            // FYI, the visio application object is NOT yet initialized here, go to the Load method below
        }

        #region visio events

        private void VisioEvents_Connect()
        {
            if (Globals.ThisAddIn.Application != null)
            {
                Globals.ThisAddIn.Application.WindowActivated += new Microsoft.Office.Interop.Visio.EApplication_WindowActivatedEventHandler(Application_WindowActivated);
                Globals.ThisAddIn.Application.BeforeWindowClosed += new Microsoft.Office.Interop.Visio.EApplication_BeforeWindowClosedEventHandler(Application_BeforeWindowClosed);
            }
        }

        private void VisioEvents_Disconnect()
        {
            if (Globals.ThisAddIn.Application != null)
            {
                Globals.ThisAddIn.Application.WindowActivated -= new Microsoft.Office.Interop.Visio.EApplication_WindowActivatedEventHandler(Application_WindowActivated);
                Globals.ThisAddIn.Application.BeforeWindowClosed -= new Microsoft.Office.Interop.Visio.EApplication_BeforeWindowClosedEventHandler(Application_BeforeWindowClosed);
            }
        }

        void Application_BeforeWindowClosed(Microsoft.Office.Interop.Visio.Window Window)
        {
            this.ribbon.Invalidate();
        }

        void Application_WindowActivated(Microsoft.Office.Interop.Visio.Window Window)
        {
            this.ribbon.Invalidate();
        }

        #endregion

        #region IRibbonExtensibility Members

        public string GetCustomUI(string RibbonID)
        {
            return GetResourceText("DataLinkedOrgChart.Ribbon.xml");
        }

        #endregion

        #region Ribbon Callbacks
        //Create callback methods here. For more information about adding callback methods, select the Ribbon XML item in Solution Explorer and then press F1

        public void Ribbon_Load(Office.IRibbonUI ribbonUI)
        {
            this.ribbon = ribbonUI;

            if (Globals.ThisAddIn.Application != null)
            {
                VisioEvents_Connect();
            }
        }

        /// <summary>
        /// Our own method to call to force us to unhook from Visio events.
        /// </summary>
        public void Ribbon_Unload()
        {
            this.VisioEvents_Disconnect();
        }

        public void OnAction(
            Office.IRibbonControl control)
        {
            switch (control.Id)
            {
                case "buttonCreate":
                    {
                        Globals.ThisAddIn.OnActionNew();
                        break;
                    }

                case "buttonGenerate":
                    {
                        Globals.ThisAddIn.OnActionGenerate();
                        break;
                    }

                case "buttonApplyDataGraphics":
                    {
                        Globals.ThisAddIn.OnActionApplyDataGraphics();
                        break;
                    }

                case "buttonLayout":
                    {
                        Globals.ThisAddIn.OnActionLayout();
                        break;
                    }
            }
        }

        public string GetDescription(
            Microsoft.Office.Core.IRibbonControl control)
        {
            return "Some Description based on the passed control.";
        }

        public bool IsOurDocument(
            Visio.Document visioDocument)
        {
            bool retVal = false; // default to false until we prove this should be enabled

            // only enabled if the active document is a configured document
            if (visioDocument != null)
            {
                if (visioDocument.Template.EndsWith("Data Linked Org Chart Sample.vst"))
                {
                    retVal = true;
                }
            }
            else
            {
                retVal = false;
            }

            return retVal;
        }

        /// <summary>
        /// Determine if the specified Ribbon Control should be Enabled or not.
        /// </summary>
        /// <param name="control"></param>
        /// <returns></returns>
        public bool GetEnabled(
            Microsoft.Office.Core.IRibbonControl control)
        {
            bool retVal = false; // default to false until we prove this should be enabled

            switch (control.Id)
            {
                case "buttonCreate":
                    {
                        // create is always available
                        retVal = true;
                        break;
                    }

                case "buttonGenerate":
                    {
                        // only enabled if the active document is a configured document
                        retVal = this.IsOurDocument(Globals.ThisAddIn.Application.ActiveDocument);

                        break;
                    }

                case "buttonApplyDataGraphics":
                    {
                        // only enabled if the active document is a configured document
                        retVal = this.IsOurDocument(Globals.ThisAddIn.Application.ActiveDocument);

                        break;
                    }

                case "buttonLayout":
                    {
                        // only enabled if the active document is a configured document
                        retVal = this.IsOurDocument(Globals.ThisAddIn.Application.ActiveDocument);

                        break;
                    }
            }

            // determine if this control should be enabled
            return retVal;
        }

        /// <summary>
        /// Determine if the specified Ribbon Control should be Visible or not.
        /// 
        /// If this callback is not implemented then TRUE is the default.
        /// </summary>
        /// <param name="control"></param>
        /// <returns></returns>
        public bool GetVisible(
            Microsoft.Office.Core.IRibbonControl control)
        {
            bool retVal = true; // default to true if we do not have a special case to check

            return retVal;
        }

        /// <summary>
        /// Return an image to the caller for the specified Ribbon Control.
        /// </summary>
        /// <param name="control"></param>
        /// <returns></returns>
        public System.Drawing.Bitmap GetImage(
            Microsoft.Office.Core.IRibbonControl control)
        {
            System.Diagnostics.Trace.WriteLine("OpsMgrAddIn.DLL - Ribbon::ButtonImage()");

            switch (control.Id)
            {
                case "buttonApplyDataGraphics":
                    {
                        return Properties.Resources.OperationsManagerProductIcon_32;
                    }
            }

            // we should not get here for these buttons
            return null;
        }

        ///// <summary>
        ///// Returns an IPictureDisp to the caller.
        ///// 
        ///// This can be used or the return type can be System.Drawing.Bitmap as shown below.
        ///// </summary>
        ///// <param name="control"></param>
        ///// <returns></returns>
        //public stdole.IPictureDisp GetImage(
        //    Microsoft.Office.Core.IRibbonControl control)
        //{
        //    switch (control.Id)
        //    {
        //        case "buttonApplyDataGraphics":
        //            // The following line assumes that there is an
        //            // image named "opportunity" in your resources file.
        //            return ConvertImage.Convert(Properties.Resources.OperationsManagerProductIcon_32);

        //        // Other cases as needed.
        //    }

        //    return null;
        //}

        #endregion

        #region Helpers

        private static string GetResourceText(string resourceName)
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            string[] resourceNames = asm.GetManifestResourceNames();
            for (int i = 0; i < resourceNames.Length; ++i)
            {
                if (string.Compare(resourceName, resourceNames[i], StringComparison.OrdinalIgnoreCase) == 0)
                {
                    using (StreamReader resourceReader = new StreamReader(asm.GetManifestResourceStream(resourceNames[i])))
                    {
                        if (resourceReader != null)
                        {
                            return resourceReader.ReadToEnd();
                        }
                    }
                }
            }
            return null;
        }

        #endregion
    }

    sealed public class ConvertImage : System.Windows.Forms.AxHost
    {
        private ConvertImage()
            : base(null)
        {
        }

        public static stdole.IPictureDisp Convert
            (System.Drawing.Image image)
        {
            return (stdole.IPictureDisp)System.
                Windows.Forms.AxHost
                .GetIPictureDispFromPicture(image);
        }
    }

}
