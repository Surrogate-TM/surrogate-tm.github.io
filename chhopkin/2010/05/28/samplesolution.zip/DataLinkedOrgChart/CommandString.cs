﻿//-----------------------------------------------------------------------
// <copyright file="CommandString.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// <author>CHHOPKIN</author>
// <summary>
// 
// </summary>
//-----------------------------------------------------------------------

namespace DataLinkedOrgChart
{
    using System;
    using System.Collections.Generic;
    using System.Data.Common;
    using System.Text;

    /// <summary>
    /// A wrapper for the CommandString property on the Visio.DataRecordset.
    /// This provides parsing for the custom parameters in the command string.
    /// </summary>
    internal sealed class CommandString
    {
        // ex. "Provider=.NET;DataModule=DataLinkedOrgChartAdapter.DataLinkedOrgChartHandler,DataLinkedOrgChartAdapter;DataPath=\\osan\visio\User\chhopkin\Visio 2010\Data Linked Org Chart add-in\sample data.xml"

        // name = DataLinkedOrgChartAdapter, Version=1.0.0.1001, Culture=neutral, PublicKeyToken=f032d939467bfdc1

        // i.e. get the publickeytoken from sn.exe -T [assembly.dll]

        #region construction

        /// <summary>
        /// Initializes a new instance of the CommandString class.
        /// </summary>
        public CommandString()
        {
            this.DataModule = "DataLinkedOrgChartAdapter.DataLinkedOrgChartHandler,DataLinkedOrgChartAdapter";
        }

        /// <summary>
        /// Initializes a new instance of the CommandString class.
        /// </summary>
        /// <param name="commandString">
        /// The command string that will be used with DbConnectionStringBuilder which will parse this for the appropriate commands.
        /// </param>
        public CommandString(
            string commandString)
        {
            DbConnectionStringBuilder builder = new DbConnectionStringBuilder();
            builder.ConnectionString = commandString;

            // get the DataModule argument
            object datamoduleArg;
            if (!builder.TryGetValue("DataModule", out datamoduleArg))
            {
                throw new ArgumentException("DataModule argument not specified.");
            }
            else
            {
                this.DataModule = datamoduleArg.ToString();
            }

            // get the DataPath argument
            object datapathArg;
            if (!builder.TryGetValue("DataPath", out datapathArg))
            {
                throw new ArgumentException("DataPath argument not specified.");
            }
            else
            {
                this.DataPath = datapathArg.ToString();
            }
        }

        #endregion

        #region properties

        /// <summary>
        /// Gets or sets the name of the assembly for the custom data adapter.
        /// </summary>
        public string DataModule
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the full path and file name of the data for this connection.
        /// </summary>
        public string DataPath
        {
            get;
            set;
        }

        #endregion

        #region methods

        /// <summary>
        /// Returns a properly formatted command string that can be used with a Visio.DataRecordSet.
        /// </summary>
        /// <returns>
        /// An empty string is returned if Assembly, Class, or Server are null or 0 length strings.
        /// </returns>
        public override string ToString()
        {
            if (this.DataModule == null || this.DataModule.Length == 0)
            {
                return string.Empty;
            }

            // "Provider=.NET;DataModule=DataLinkedOrgChartAdapter.DataLinkedOrgChartHandler,DataLinkedOrgChartAdapter;DataPath=\\osan\visio\User\chhopkin\Visio 2010\Data Linked Org Chart add-in\sample data.xml"

            return "Provider=.NET;" + 
                   string.Format("DataModule={0};", this.DataModule) + 
                   string.Format("DataPath={0}", this.DataPath);
        }

        #endregion
    }
}
