﻿//-----------------------------------------------------------------------
// <copyright file="DataLinkedOrgChartAdapter.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// <author>CHHOPKIN</author>
// <summary>
// 
// </summary>
//-----------------------------------------------------------------------

namespace DataLinkedOrgChartAdapter
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Web;

    public class DataHelper
    {
        public static System.Data.DataTable GetData(
            string dataPath)
        {
            System.Data.DataTable retVal = null;

            try
            {
                // create a new instance of our DataTable
                TeamDataSet.TeamMembersDataTable dataTable = new TeamDataSet.TeamMembersDataTable();

                // read the sample data from a file
                dataTable.ReadXml(dataPath);

                // return this as a generic data table
                retVal = dataTable;
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.ToString());
            }

            return retVal;
        }
    }
}