﻿//-----------------------------------------------------------------------
// <copyright file="DataLinkedOrgChartAdapter.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// <author>CHHOPKIN</author>
// <summary>
// 
// </summary>
//-----------------------------------------------------------------------

namespace DataLinkedOrgChartAdapter
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Web;

    using Microsoft.SharePoint.Administration;

    using VisioServer = Microsoft.Office.Visio.Server;

    public class DataLinkedOrgChartHandler : VisioServer.AddonDataHandler, IAsyncResult
    {
        #region fields

        private HttpContext httpContext;
        private object asyncState;

        private bool completed;

        #endregion

        #region methods

        private void logFile_TraceFinished(object sender, TraceContextEventArgs e)
        {
            string loc = string.Empty;

            try
            {
                Microsoft.Win32.RegistryKey key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Shared Tools\Web Server Extensions\14.0\WSS");
                loc = key.GetValue("UsageLogDir").ToString(); // D:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\14\LOGS\
            }
            catch (System.Exception)
            {
                // exception accessing registry
            }

            // create the log file
            System.IO.StreamWriter logwriter = null;

            if (loc != null && loc.Length > 0 && System.IO.Directory.Exists(loc))
            {
                logwriter = new System.IO.StreamWriter(
                    loc + "DataLinkedOrgChart_Trace.log",
                    true); // true = append to the file if it exists
            }

            StringBuilder log = new StringBuilder();

            log.Append("*---------------------------------------------------------------*");

            foreach (TraceContextRecord traceRecord in e.TraceRecords)
            {
                log.Append(Environment.NewLine);
                log.Append(DateTime.Now);
                log.Append(" : ");

                if (traceRecord.Category.Length > 0)
                {
                    log.Append(traceRecord.Category);
                }
                else
                {
                    log.Append("No Category");
                }

                log.Append(" : ");
                log.Append(traceRecord.Message);
            }

            log.Append(Environment.NewLine);

            // write to the log and close the log
            if (logwriter != null)
            {
                logwriter.WriteLine(log.ToString());
                logwriter.Flush();
                logwriter.Close();
            }
            else
            {
                // throw exception about not being able to access log file location
                throw new VisioServer.AddonDataHandlerException("Trace is enabled but the log file location either does not exist or access is denied.");
            }
        }

        private void RefreshDataset()
        {
            #region setup tracing

            //HttpContext.Current.Trace.IsEnabled = true; // turn tracing on via code rather than setting the web.config file - <trace enabled='true'/>

            TraceContext logFile = null;
            if (HttpContext.Current.Trace.IsEnabled)
            {
                // web.config file is located at D:\inetpub\wwwroot\wss\VirtualDirectories\80

                // add <trace /> to <system.web>
                //<configuration>
                //    ...
                //  <system.web>
                //    <trace enabled="true" />

                // setup tracing
                logFile = HttpContext.Current.Trace;
                logFile.TraceFinished += new TraceContextEventHandler(logFile_TraceFinished);
            }

            // all of these methods are acceptible for logging to this trace file
            //this.httpContext.Trace.Write("message");
            //logFile.Write("message");

            #endregion

            try
            {
                this.httpContext.Trace.Write("DATA MODULE TRACE", "User.Identity.Name: " + this.httpContext.User.Identity.Name);
            }
            catch
            {
                this.httpContext.Trace.Write("DATA MODULE TRACE - EXCEPTION", "User.Identity.Name: NOT AVAILABLE");
            }

            // reset the data for this AddonDataHandler instance this just clears the cache
            this.Data.Reset();
            this.httpContext.Trace.Write("DATA MODULE TRACE", "this.Data.Reset() called");

            /* get the parameters from the connection string from the dataset in the visio diagram */

            this.httpContext.Trace.Write("DATA MODULE TRACE", this.ConnectionString);

            System.Data.Common.DbConnectionStringBuilder builder = new System.Data.Common.DbConnectionStringBuilder();

            // ConnectionString returns the CommandString for the DataRecordset in the target document that will be refreshed
            builder.ConnectionString = this.ConnectionString;

            // get the Server argument
            object dataPathFromConnectionString = null;

            if (!builder.TryGetValue("DataPath", out dataPathFromConnectionString) ||
                string.IsNullOrEmpty(dataPathFromConnectionString as string))
            {
                // display our error in the VGS window
                this.httpContext.Trace.Write("DATA MODULE - EXCEPTION", "DataPath not specified in CommandString for datarecordset.");
                throw new VisioServer.AddonDataHandlerException("DataPath not specified in CommandString for datarecordset.");
            }

            string dataPath = dataPathFromConnectionString as string; // @"\\osan\visio\User\chhopkin\Visio 2010\Data Linked Org Chart add-in\";
            this.httpContext.Trace.Write("DATA MODULE TRACE", dataPath);

            if (dataPath == null || dataPath.Length == 0)
            {
                // display our error in the VGS window
                this.httpContext.Trace.Write("DATA MODULE - EXCEPTION", "DataPath is empty.");
                throw new VisioServer.AddonDataHandlerException("DataPath is empty.");
            }

            if (!System.IO.File.Exists(dataPath))
            {
                // display our error in the VGS window
                this.httpContext.Trace.Write("DATA MODULE - EXCEPTION", "DataPath does not exist or is not accessible.");
                throw new VisioServer.AddonDataHandlerException("DataPath does not exist or is not accessible.");
            }

            /* set the data to the base class */

            // read the XML into the AddonDataHandler's DataSet object
            // this will be used to render the Shape Data and Data Graphics in the VWA control
            // note that VGS does not modify the Visio file, this is used to only render
            this.Data.Tables.Add(DataHelper.GetData(dataPath));

            this.httpContext.Trace.Write("DATA MODULE TRACE", "Data.Tables.Add() called.");
            this.httpContext.Trace.Write("DATA MODULE TRACE", "InternalWorker() complete.");
        }

        private void ThreadWorker(
            object state)
        {
            AsyncCallback callback = (AsyncCallback)state;

            System.Web.HttpContext.Current = this.httpContext;

            try
            {
                this.RefreshDataset();
            }
            catch (VisioServer.AddonDataHandlerException ex)
            {
                // set any errors here
                // this.Error is returned to the user and displayed in the VisioWebAccess control on the page.
                this.Error = ex;
            }
            catch (System.Exception ex)
            {
                // any other exceptions to be handled
                // this.Error is returned to the user and displayed in the VisioWebAccess control on the page.
                this.Error = new VisioServer.AddonDataHandlerException("!! Unexpected Data Linked Org Chart Adapter Data Module Exception !!", ex);
            }

            this.completed = true;

            // our operation is complete, call EndGetData
            callback(this);
        }

        #endregion

        #region AddonDataHandler implementation

        public override IAsyncResult BeginGetData(System.Web.HttpContext context, AsyncCallback callback, object asyncState)
        {
            this.asyncState = asyncState;
            this.httpContext = context;

            // do work asyncronously from a threadpool thread
            System.Threading.ThreadPool.QueueUserWorkItem(
                new System.Threading.WaitCallback(this.ThreadWorker), 
                callback);

            // return the instance of this class to Visio Services
            // Visio Services will get notified that we are finished when we call the specified callback that was passed to us.
            return this;
        }

        public override void Cancel()
        {
            //Code to cancel a request to a data source in case of error VGS refresh.
        }

        public override System.Data.DataSet EndGetData(IAsyncResult result)
        {
            System.Data.DataSet retVal = null;

            if (this.Error == null)
            {
                retVal = this.Data;
            }

            // if this.Error is set, Visio Services will display this error to the user

            // return the dataset or null
            return retVal;
        }

        #endregion

        #region IAsyncResult Members

        public object AsyncState
        {
            get { return this.asyncState; }
        }

        public System.Threading.WaitHandle AsyncWaitHandle
        {
            get { return null; }
        }

        public bool CompletedSynchronously
        {
            get { return false; }
        }

        public bool IsCompleted
        {
            get { return this.completed; }
        }

        #endregion
    }
}
