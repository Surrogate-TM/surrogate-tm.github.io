function global:Find-SharePointSolution
{
    param
    (
        $solutionName = $(throw 'Missing: solutionName'),
        [switch]$installed,
        [switch]$deployed
    )
    
    if (!($solutionName.EndsWith('.cab') -or $solutionName.EndsWith('.wsp') -or $solutionName.EndsWith('.wpp')))
    {
        throw "solution name '$solutionName' should end with .cab, .wsp or .wpp"
    }
    
    if ($installed -and $deployed)
    {
        throw "Select either the '-installed' switch parameter or the '-deployed' switch parameter, not both at the same time"
    }
    
    $farm = [Microsoft.SharePoint.Administration.SPFarm]::get_Local()
    $solutions = $farm.get_Solutions()
    $solutioncheck = $false
    foreach ($solution in $solutions)
    {
        if ($solution.Name -ieq $solutionName)
        {
            if ($deployed)
            {
                $solutioncheck = $solution.Deployed
            }
            else
            {
                # installed, is always true if we get here
                $solutioncheck = $true
            }
            break
        }
    }
    return $solutioncheck
}

'**** execution for this script ****'

pushd .
$ConfirmPreference = 'None'

[bool]$moduleInstalled = Find-SharePointSolution -solutionName datalinkedorgchartdatamodule.wsp -installed
[bool]$moduleDeployed = Find-SharePointSolution -solutionName datalinkedorgchartdatamodule.wsp -deployed

if($moduleInstalled)
{
	Write-Host ""
	Write-Host "> Deleting the Safe Data Provider from the farm..."
	Write-Host ""
	Remove-SPVisioSafeDataProvider �DataProviderId "DataLinkedOrgChartAdapter.DataLinkedOrgChartHandler, DataLinkedOrgChartAdapter, Version=1.0.0.1001, Culture=neutral, PublicKeyToken=f032d939467bfdc1" -DataProviderType 6 -VisioServiceApplication "Visio Graphics Service"

	Write-Host ""
	Write-Host "> Uninstalling Data Module from the farm..."
	Write-Host ""
	Uninstall-SPSolution datalinkedorgchartdatamodule.wsp
}
else
{
	Write-Host "datalinkedorgchartdatamodule.wsp is not installed"
}

if($moduleDeployed)
{
	do
	{
		$moduleDeployed = Find-SharePointSolution -solutionName datalinkedorgchartdatamodule.wsp -deployed
	} while ($moduleDeployed)

	if(!$moduleDeployed)
	{
		wait-event -timeout 30

		Write-Host ""
		Write-Host "> Removing Data Module package from the Farm Solution Store..."
		Write-Host ""
		Remove-SPSolution datalinkedorgchartdatamodule.wsp
	}
}
else
{
	Write-Host "datalinkedorgchartdatamodule.wsp is not deployed"
}

popd
