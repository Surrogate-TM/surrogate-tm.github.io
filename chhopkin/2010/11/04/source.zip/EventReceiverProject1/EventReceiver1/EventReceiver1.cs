﻿//-----------------------------------------------------------------------
// <copyright file="EventReceiver1.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// <author>CHHOPKIN</author>
// <summary>
// 
// </summary>
//-----------------------------------------------------------------------

namespace EventReceiverProject1.EventReceiver1
{
    using System;
    using System.Security.Permissions;
    using Microsoft.SharePoint;
    using Microsoft.SharePoint.Security;
    using Microsoft.SharePoint.Utilities;
    using Microsoft.SharePoint.Workflow;

    /// <summary>
    /// List Item Events
    /// </summary>
    public class EventReceiver1 : SPItemEventReceiver
    {
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);

            // get the attached file from the list item
            SPFile fileToRead = properties.ListItem.File;

            // get the page names that are defined in the file
            string pageNames = "";
            pageNames = GetPageNamesFromWebDrawing(fileToRead);

            // update the column for this list item
            properties.ListItem["Pages"] = pageNames;
            properties.ListItem.Update();
        }

        /// <summary>
        /// An item is being added.
        /// </summary>
        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);

            try
            {
                bool allowed = true;

                if (properties.ListTitle == "My Visio Diagrams")
                {
                    allowed = CheckItem(properties);
                }

                // is this file allowed?
                if (!allowed)
                {
                    properties.Status = SPEventReceiverStatus.CancelWithError;
                    properties.ErrorMessage =
                        "The file you uploaded is not a Visio Web Drawing.  Please Save or upload a Visio diagram using the VDW file format.";
                    properties.Cancel = true;
                }
            }
            catch (Exception ex)
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = ex.Message;
                properties.Cancel = true;
            }
        }

        /// <summary>
        /// Verifies that the item being added is a VDW file.
        /// </summary>
        /// <param name="properties"></param>
        /// <returns></returns>
        private bool CheckItem(
            SPItemEventProperties properties)
        {
            string uploadedFileName = properties.BeforeUrl;

            // init flags
            bool allowed = uploadedFileName.EndsWith(".vdw", StringComparison.InvariantCultureIgnoreCase);

            // return if we allow this item or not in our library
            return (allowed);
        }

        /// <summary>
        /// Get the Page names for the pages that are defined in the VDW.
        /// </summary>
        /// <param name="spfile">This must be a VDW file type.</param>
        /// <returns>A string containing the names of each page in the Visio file.</returns>
        private string GetPageNamesFromWebDrawing(
            SPFile spfile)
        {
            string retVal = "";

            // create a tmp file
            string tmpFileName = System.IO.Path.GetTempFileName();
            System.IO.File.Delete(tmpFileName);

            // write the visio file to the tmp file
            byte[] fileContents = spfile.OpenBinary();

            if (!System.IO.File.Exists(tmpFileName))
            {
                System.IO.FileStream tmpFileStream = System.IO.File.Create(tmpFileName);
                tmpFileStream.Write(fileContents, 0, fileContents.Length);
                tmpFileStream.Close();
                tmpFileStream = null;
            }

            // read in the tmp file from disk using IStorage
            byte[] buffer;
            int num;

            Extractor.ExtractStreamToMemory(tmpFileName, out buffer, out num);

            // kill the tmp file we wrote to disk
            System.IO.File.Delete(tmpFileName);

            // access the bytes read from disk as a stream
            System.IO.MemoryStream memStream = new System.IO.MemoryStream(buffer);

            // work with the stream as a package
            System.IO.Packaging.Package zip = System.IO.Packaging.Package.Open(memStream);

            // get the app.xml part that is stored in this package
            System.IO.Packaging.PackagePart partAppXml = zip.GetPart(new Uri("/docProps/app.xml", UriKind.Relative));

            // read the content of the app.xml into a XmlDocument object
            System.IO.Stream partStream = partAppXml.GetStream(System.IO.FileMode.Open, System.IO.FileAccess.Read);

            System.Xml.XmlDocument appxml = new System.Xml.XmlDocument();
            appxml.Load(partStream);

            // find the PageMetaData nodes in the XML
            System.Xml.XmlNodeList pagesList = appxml.SelectNodes("//*");

            foreach (System.Xml.XmlNode nextNode in pagesList)
            {
                if (nextNode.Name == "PageMetaData")
                {
                    // next page name
                    string nextPageName = nextNode.Attributes["Name"].Value;

                    // append this
                    if (nextPageName.Length > 0)
                    {
                        retVal += "<" + nextPageName + ">";
                    }
                }
            }

            // return results
            return retVal;
        }
    }
}
