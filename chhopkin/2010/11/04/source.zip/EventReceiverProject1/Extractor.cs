﻿//-----------------------------------------------------------------------
// <copyright file="Extractor.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// <author></author>
// <summary>
// 
// </summary>
//-----------------------------------------------------------------------

namespace EventReceiverProject1
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.IO;

    using System.Runtime.InteropServices;

    using System.Runtime.InteropServices.ComTypes; // defines IStream

    class Extractor
    {
        private static string streamName = "VisioServerData";

        private Extractor()
        {
            // static class, cannot create
        }

        internal static void ExtractStreamToMemory(
            string visioFile,
            out byte[] output,
            out int countOutput)
        {
            IStorage storage;

            uint grfMode = 0x20;

            int errorCode = NativeMethods.StgOpenStorage(visioFile, IntPtr.Zero, grfMode, IntPtr.Zero, 0, out storage);

            if (errorCode != 0)
            {
                Marshal.ThrowExceptionForHR(errorCode);
            }

            IStream o = storage.OpenStream("VisioServerData", IntPtr.Zero, 0x10, 0);

            if (o == null)
            {
                Console.WriteLine("Error: can not open the server stream {0} from Visio file {1}.", streamName, visioFile);
                output = null;
                countOutput = 0;
            }
            else
            {
                System.Runtime.InteropServices.ComTypes.STATSTG statstg;

                o.Stat(out statstg, 1);

                int cbSize = (int)statstg.cbSize;

                output = new byte[cbSize];

                IntPtr pcbRead = new IntPtr(0);

                o.Read(output, cbSize, pcbRead);

                countOutput = cbSize;

                Marshal.ReleaseComObject(storage);
                Marshal.ReleaseComObject(o);
            }
        }
    }
}
