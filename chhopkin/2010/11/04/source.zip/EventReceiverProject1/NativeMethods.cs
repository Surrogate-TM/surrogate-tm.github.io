﻿//-----------------------------------------------------------------------
// <copyright file="NativeMethods.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// <author></author>
// <summary>
// 
// </summary>
//-----------------------------------------------------------------------

namespace EventReceiverProject1
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Runtime.InteropServices;
    using System.Runtime.InteropServices.ComTypes; // defines IStream

    internal sealed class NativeMethods
    {
        private NativeMethods()
        {
            // private ctor, cannot create this class it is static only
        }

        [DllImport("ole32.dll")]
        internal static extern int StgCreateDocfile([MarshalAs(UnmanagedType.LPWStr)] string wcsName, uint grfMode, uint reserved, [MarshalAs(UnmanagedType.Interface)] out IStorage stgOpen);

        [DllImport("ole32.dll")]
        internal static extern int StgOpenStorage([MarshalAs(UnmanagedType.LPWStr)] string wcsName, IntPtr stgPriority, uint grfMode, IntPtr snbExclude, uint reserved, [MarshalAs(UnmanagedType.Interface)] out IStorage stgOpen);

        // Nested Types
        [Flags]
        internal enum STGM : uint
        {
            CONVERT = 0x20000,
            CREATE = 0x1000,
            DELETEONRELEASE = 0x4000000,
            DIRECT = 0,
            DIRECT_SWMR = 0x400000,
            FAILIFTHERE = 0,
            NOSCRATCH = 0x100000,
            NOSNAPSHOT = 0x200000,
            PRIORITY = 0x40000,
            READ = 0,
            READWRITE = 2,
            SHARE_DENY_NONE = 0x40,
            SHARE_DENY_READ = 0x30,
            SHARE_DENY_WRITE = 0x20,
            SHARE_EXCLUSIVE = 0x10,
            SIMPLE = 0x8000000,
            TRANSACTED = 0x10000,
            WRITE = 1
        }
    }
}
