﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.IO;
using System.IO.Packaging;
using System.Xml;
using System.Reflection;

using Microsoft.SharePoint;

namespace UpdateVSDXDataConnections
{
    internal class VSDXDoc
    {
        #region privates

        private Package package = null;
        private string fileName = string.Empty;

        private VSDXHelpers vsdxHelpers = new VSDXHelpers();

        private bool dirty = false;

        private string relationshiptypeDocument = "http://schemas.microsoft.com/visio/2010/relationships/document";

        #endregion

        public VSDXDoc(
            System.IO.Packaging.Package package)
        {
            this.package = package;

            this.vsdxHelpers.InitializeNameSpaceManager();
        }

        /// <summary>
        /// Our own Close method to wrap the Package.Close method which must be called to
        /// close the IO stream to the package and make the file on disk a valid package.
        /// </summary>
        /// <returns></returns>
        public void Close()
        {
            if (this.package != null)
            {
                try
                {
                    if (this.dirty)
                    {
                        this.package.Flush();
                        this.package.Close(); // saves and closes the package
                    }
                }
                catch (System.Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.ToString());
                }
                finally
                {
                    this.package = null;

                    System.GC.Collect(); // force collection, this clears out the memory when we are done, without this we seem to hold onto a reference
                }
            }
        }

        public Package Package
        {
            get
            {
                return this.package;
            }
        }

        public bool IsValid
        {
            get
            {
                bool retVal = false;

                if (this.DocumentPart != null)
                {
                    // we have a visio document part so this is a valid VSDX
                    retVal = true;
                }

                return retVal;
            }
        }

        /// <summary>
        /// Uses the GetRelationshipsByType method from the package to find and return the Document part
        /// </summary>
        /// <param name="package"></param>
        /// <returns></returns>
        public PackagePart DocumentPart
        {
            get
            {
                PackagePart retVal = null;

                var documentRelationships = this.package.GetRelationshipsByType(this.relationshiptypeDocument);

                if (documentRelationships != null && documentRelationships.Count() > 0)
                {
                    var documentRelationship = documentRelationships.First(); // assume the first part as there should always be only one document part or the file is corrupt
                    var documentUri = PackUriHelper.ResolvePartUri(new Uri("/", UriKind.Relative), documentRelationship.TargetUri);
                    retVal = package.GetPart(documentUri);
                }

                return retVal;
            }
        }

        public bool UpdateSPListDataConnections(string siteUrl)
        {
            bool retVal = false;

            try
            {
                foreach (PackagePart nextConnectionsPart in vsdxHelpers.GetPartsByRelationship(this.package, this.DocumentPart, "http://schemas.microsoft.com/visio/2010/relationships/connections"))
                {
                    XmlDocument xDoc = vsdxHelpers.GetXmlFromPart(nextConnectionsPart);

                    foreach (XmlNode node in xDoc.SelectNodes("//vsdx:DataConnection", vsdxHelpers.NamespaceManager))
                    {
                        var command = node.Attributes.GetNamedItem("Command").Value;
                        var connectionString = node.Attributes.GetNamedItem("ConnectionString").Value;
                        var id = node.Attributes.GetNamedItem("ID").Value;

                        System.Diagnostics.Debug.WriteLine(connectionString);

                        if (connectionString.Contains("LIST="))
                        {
                            // get the list name from the command
                            string listName = "";

                            int start = command.IndexOf("[");
                            int stop = command.IndexOf("]");

                            listName = command.Substring(start + 1, stop - start - 1);
                            string listId = ""; // ex {000-000-000}

                            // look up the LIST ID from the site URL
                            using (SPSite site = new SPSite(siteUrl))
                            {
                                SPWeb web = site.OpenWeb();

                                string webUrl = web.Url;
                                System.Diagnostics.Debug.WriteLine("Web Url: " + webUrl);

                                foreach (SPList nextList in web.Lists)
                                {
                                    string listTitle = nextList.Title;
                                    System.Diagnostics.Debug.WriteLine("List Title: " + listTitle);

                                    if (nextList.Title.Equals(listName))
                                    {
                                        listId = nextList.ID.ToString();
                                        break;
                                    }
                                }
                            }

                            if (listId.Equals(string.Empty))
                            {
                                break;
                            }

                            // apply the LIST ID to the connection string
                            List<string> ctxParams = connectionString.Split(';').ToList<string>();

                            string newCtxString = connectionString;

                            foreach (string nextParam in ctxParams)
                            {
                                if (nextParam.StartsWith("LIST="))
                                {
                                    newCtxString = newCtxString.Replace(nextParam, "LIST=" + listId);

                                    // set the changed flag
                                    retVal = true;
                                }

                                if (nextParam.StartsWith("DATABASE="))
                                {
                                    newCtxString = newCtxString.Replace(nextParam, "DATABASE=" + siteUrl);

                                    // set the changed flag
                                    retVal = true;
                                }
                            }

                            if (retVal)
                            {
                                // write the new connection string back to the node
                                node.Attributes.GetNamedItem("ConnectionString").Value = newCtxString;
                            }

                        }
                    }

                    if (retVal)
                    {
                        SaveXmlDocumentToPart(nextConnectionsPart, xDoc);
                    }

                }
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }

            this.dirty = retVal;

            return retVal;
        }

        public void Save()
        {
            // save the document back to VSDX file format
            this.Close();
        }

        private static void SaveXmlDocumentToPart(
            PackagePart packagePart,
            XmlDocument partXML)
        {
            // taken from this article
            // http://msdn.microsoft.com/en-us/library/office/jj649391.aspx
            
            // Create a new XmlWriterSettings object to 
            // define the characteristics for the XmlWriter
            XmlWriterSettings partWriterSettings = new XmlWriterSettings();
            partWriterSettings.Encoding = Encoding.UTF8;

            // Create a new XmlWriter and then write the XML
            // back to the document part.
            XmlWriter partWriter = XmlWriter.Create(
                packagePart.GetStream(),
                partWriterSettings);

            partXML.WriteTo(partWriter);

            // Flush and close the XmlWriter.
            partWriter.Flush();
            //partWriter.Close(); // instead of saving here, save later after all my changes are made to the document, or I can save incrementally like this call here
        }
    }
}
