﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Text.RegularExpressions;
using System.IO.Packaging;
using System.Xml;

namespace UpdateVSDXDataConnections
{
    class VSDXHelpers
    {
        internal XmlNamespaceManager NamespaceManager;

        internal NameTable nt = new NameTable();

        internal static Regex IllegalCharsRegex = new Regex("[\t\r\n]");

        // single quote is an escape char so excel doesn't think the ShapeSheet formula is an excel formula
        // also remove certain characters that can corrupt the delimited text output schema. these chars are rare in our content anyway.
        internal string RemoveIllegalChars(string formula)
        {
            return "'" + VSDXHelpers.IllegalCharsRegex.Replace(formula, "");
        }

        internal List<PackagePart> GetPartsByRelationship(
            Package package, 
            PackagePart sourcePart, 
            string relationshipType)
        {
            List<PackagePart> retVal = new List<PackagePart>();

            foreach (var relationship in sourcePart.GetRelationshipsByType(relationshipType))
            {
                var targetUri = PackUriHelper.ResolvePartUri(sourcePart.Uri, relationship.TargetUri);
                retVal.Add(package.GetPart(targetUri));
            }

            return retVal;
        }

        internal XmlDocument GetXmlFromPart(PackagePart part)
        {
            var xDoc = new XmlDocument(nt);
            xDoc.Load(part.GetStream());
            return xDoc;
        }

        internal void InitializeNameSpaceManager()
        {
            NamespaceManager = new XmlNamespaceManager(nt);

            // release namespace
            NamespaceManager.AddNamespace("vsdx", "http://schemas.microsoft.com/office/visio/2012/main");

            // relationships namespace for openxml
            NamespaceManager.AddNamespace("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
        }
    }
}
