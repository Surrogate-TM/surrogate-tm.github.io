﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

using Microsoft.SharePoint;

namespace UpdateVSDXDataConnections
{
    class UpdateVSDXDataConnections
    {
        public static void UpdateDataConnectionsForVSDX(
            SPWeb web,
            string diagramUrl)
        {
            VSDXDoc vsdxDocument = null;
            SPFile spFile = null;

            try
            {
                spFile = web.GetFile(diagramUrl);

                if (spFile.Exists)
                {
                    using (MemoryStream memstr = new MemoryStream())
                    {
                        byte[] byteArray = spFile.OpenBinary();
                        memstr.Write(byteArray, 0, byteArray.Length);

                        System.IO.Packaging.Package package = System.IO.Packaging.Package.Open(memstr, FileMode.Open, FileAccess.ReadWrite);

                        VSDXHelpers vsdxHelpers = new VSDXHelpers();
                        vsdxHelpers.InitializeNameSpaceManager();

                        vsdxDocument = new VSDXDoc(package);

                        if (vsdxDocument != null)
                        {
                            System.Diagnostics.Debug.WriteLine("Target web URL: " + web.Url);

                            if (vsdxDocument.UpdateSPListDataConnections(web.Url))
                            {
                                // save the document, changes needed to be persisted
                                vsdxDocument.Save();

                                // save the new file to the list item
                                spFile.SaveBinary(memstr.ToArray());
                            }
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }
            finally
            {
                System.Diagnostics.Debug.WriteLine("DONE!");
            }
        }
        
        public static void FindAndUpdateAllVSDXFiles(
            SPWeb web)
        {
            // get all the files from the document libraries
            foreach (SPList nextList in web.Lists)
            {
                System.Diagnostics.Debug.WriteLine("Title: " + nextList.Title);
                System.Diagnostics.Debug.WriteLine("Base Type: " + nextList.BaseType);

                if (nextList.BaseType == SPBaseType.DocumentLibrary)
                {
                    // get all the file URLs so we can work on each one

                    foreach (SPListItem nextListItem in nextList.Items)
                    {
                        if (nextListItem.File != null && nextListItem.File.Url.EndsWith("vsdx"))
                        {
                            System.Diagnostics.Debug.WriteLine(nextListItem.File.Url);
                            
                            // we have a visio diagram to process
                            UpdateDataConnectionsForVSDX(web, nextListItem.File.Url);
                        }
                    }
                }
            }
        }
    }
}
