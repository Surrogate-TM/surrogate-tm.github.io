﻿using System;
using System.Collections.Generic;
using System.Data.Services;
using System.Data.Services.Common;
using System.Linq;
using System.ServiceModel.Web;
using System.Web;

namespace RandomNumbers
{
    public class RandomNumbers : DataService<RandomNumbersDataSource>
    {
        // This method is called only once to initialize service-wide policies.
        public static void InitializeService(DataServiceConfiguration config)
        {
            // set rules to indicate which entity sets and service operations are visible, updatable, etc.
            config.SetEntitySetAccessRule("*", EntitySetRights.AllRead);
            //config.SetServiceOperationAccessRule("*", ServiceOperationRights.All);
            config.DataServiceBehavior.MaxProtocolVersion = DataServiceProtocolVersion.V2;
        }
    }

    [DataServiceKey("ID")]
    public class RandomNumber
    {
        private RandomNumber()
        {
        }

        public RandomNumber(int id, int number)
        {
            this.ID = id;
            this.Number = number;
        }

        public int ID
        {
            get;
            private set;
        }

        public int Number
        {
            get;
            private set;
        }
    }

    public class RandomNumbersDataSource
    {
        private static Random rnd = new Random(DateTime.Now.Millisecond);

        private static List<RandomNumber> numbers = new List<RandomNumber>
        {
            new RandomNumber(0, rnd.Next(0,100)),
            new RandomNumber(1, rnd.Next(0,100)),
            new RandomNumber(2, rnd.Next(0,100)),
            new RandomNumber(3, rnd.Next(0,100)),
            new RandomNumber(4, rnd.Next(0,100)),
            new RandomNumber(5, rnd.Next(0,100)),
            new RandomNumber(6, rnd.Next(0,100)),
            new RandomNumber(7, rnd.Next(0,100)),
            new RandomNumber(8, rnd.Next(0,100)),
            new RandomNumber(9, rnd.Next(0,100))
        };

        public RandomNumbersDataSource()
        {
        }

        public IQueryable<RandomNumber> RandomNumbers
        {
            get
            {
                // http://localhost:11303/randomnumbers.svc/RandomNumbers - all
                // http://localhost:11303/randomnumbers.svc/RandomNumbers(1) - specific one
                return numbers.AsQueryable();
            }
        }
    }
}
