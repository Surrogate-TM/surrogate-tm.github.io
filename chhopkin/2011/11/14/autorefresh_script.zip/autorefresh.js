    <!-- include jquery library -->
    <script type="text/javascript" src="http://sharepoint/sites/usprovis/SiteAssets/jquery-1.4.2.js"></script>

    <!-- include Visio Services mashup helpers library from Chris Hopkins' blog-->
    <script type="text/javascript" src="http://sharepoint/sites/usprovis/SiteAssets/vwalib-1.0.4.js">
        // src="/SiteAssets/jscript/vwalib-1.0.4.js"
        // copied to the SiteAssets/jscript folder using SharePoint Designer
        // full path = http://vgstest01/SiteAssets/jscript/vwalib-1.0.4.js
    </script>

    <!-- helpers for this page -->
    <script type="text/javascript">

        function LogToConsole(message)
        {
            if (typeof console != "undefined")
            {
                var sPath = window.location.pathname;
                var sPage = sPath.substring(sPath.lastIndexOf('/') + 1);
                sPage = sPage.replace(/%20/g, " ");

                console.log(sPage + ": " + message);
            }
        }
            
    </script>

    <!-- Visio Services mashup implementation -->
    <script type="text/javascript">

        // VWA is ajax based so use use this method to know when the page is loaded and all scripts are loaded
        // only at this point is VWA ready for calls to the API
        Sys.Application.add_load(initDocument)

        var vwaControl = null;

        function initDocument()
        {
            vwaControl = VGSHelpers.getVwaControl();

            if (vwaControl != null)
            {
                vwaControl.addHandler("diagramcomplete", onDiagramComplete);
            }
        }

        function onDiagramComplete()
        {
            LogToConsole("Visio Services API initialized.  Diagram = " + VGSHelpers.getCurrentDiagramUrl(vwaControl));

            VGSHelpers.enableRefresh(vwaControl, true);
        }

    </script>