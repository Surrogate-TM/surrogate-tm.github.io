#---------------------------------------------#
# Setup sharepoint access
#---------------------------------------------#

[System.Reflection.Assembly]::LoadWithPartialName(�Microsoft.SharePoint�)
$siteUrl = "http://chhopkin-spdev/vgsmashups"
$spSite = new-object Microsoft.SharePoint.SPSite($siteUrl)
$spWeb = $spSite.OpenWeb()

$listName = "Server Status"
$spList = $spWeb.Lists[$listName] 

#---------------------------------------------#
#--- WMI to get machine data
#---------------------------------------------#

#--- Loop through each server defined in the array ---#
foreach ($nextItem in $spList.Items)
{
    # init data we are interested for this next item
	$cpu_utilisation_average = 0
	$utilRAM = 0
	$percentFreeHDD = 0
    $pingResult = "Failure"
            
    # get the name of the next machine to monitor from the SharePoint list
    $iphost = $nextItem.Title

    # Build a query to find the SPList item
    $query = new-object Microsoft.SharePoint.SPQuery
    $query.Query = "<Where><Eq><FieldRef Name='Title'/><Value Type='Text'>" + $iphost + "</Value></Eq></Where>"; #The Name is the internal column name, so watch this is you rename an existing column like Title.

    $foundItems = $spList.GetItems($query);
    $foundItem = $foundItems[0];

	#--- PING SERVER
    Write-Host "Pinging" $iphost.tolower() "..."
    
    # create the Ping object that will be used to ping each machine
    $ping = new-object System.Net.NetworkInformation.Ping
    
    $pinged = $null
    
    trap [System.Exception]
    { 
        write-host
        write-error $("TRAPPED: " + $_.Exception.GetType().FullName); 
        continue; 
    }
    
    $pinged = $ping.send($iphost.tolower()) #timeout set to 1000 milliseconds    
     
    # clean up the objects that we created
    $ping = $null    
    
    #--- if pinged then continue with data gathering
	if ($pinged -and $pinged.status.tostring() �eq �Success�)
    {
        Write-Host $pinged.status.tostring()    
        $pingResult = $pinged.status.tostring()
        
    	#--- GET CPU UTILIZATION
    	$cpuinfo = Get-WMIObject -ComputerName $iphost Win32_Processor
        #$cpuinfo = Get-WMIObject -ComputerName $iphost Win32_PerfRawData_PerfOS_Processor
        
        if ($cpuinfo)
        {        
        	$count = 0
        	$cpu_utilisation_total = 0
        	$cpu_utilisation_average = 0
        	$cpu_utilisation_maximum_single_processor = 0

        	foreach ($cpu in $cpuinfo)
        	{
        	    $cpu_utilisation_total = $cpu_utilisation_total + $cpu.LoadPercentage
        	    $count = $count + 1
        	    if ($cpu.LoadPercentage -gt $cpu_utilisation_maximum_single_processor)
        	    {
                	$cpu_utilisation_maximum_single_processor = $cpu.LoadPercentage
        	    }
        	}
        	
        	$cpu_utilisation_average = $cpu_utilisation_total / $count
            $cpu_utilisation_average = $cpu_utilisation_average /100 # convert to percent to SPList Column
        }
    	 
    	#--- GET MEMORY STATISTICS
    	$objCompSys = Get-WMIObject -Class Win32_ComputerSystem -namespace "root\CIMv2" -computername $iphost
        
        if ($objCompSys)
        {
        	$totalRAM = [Double]$objCompSys.TotalPhysicalMemory
            $totalRAM = $totalRAM/1048576
        	$totalRAM = [int]$totalRAM
        	
        	$objWin32OS = Get-WMIObject -Class Win32_OperatingSystem -namespace "root\CIMv2" -computername $iphost
            
        	$freeRAM = [Double]$objWin32OS.FreePhysicalMemory
        	$freeRAM = $freeRAM/1024
        	$freeRAM = [int]$freeRAM

            # % utilized = 0.56 -> 56% so format SP List column to display as Number and Percent
        	$utilRAM = $freeRAM/$totalRAM		
    	}

    	#--- GET HDD Statistics
    	$objWin32LogicalDisk = Get-WMIObject -Class Win32_LogicalDisk -namespace "root\CIMv2" -computername $iphost -filter "DeviceID='c:'"
        
        if ($objWin32LogicalDisk)
        {
        	[float]$freeHDD = $objWin32LogicalDisk.FreeSpace;
        	[float]$sizeHDD = $objWin32LogicalDisk.Size;
            
            $percentFreeHDD = $freeHDD / $sizeHDD

        	#$percentFreeHDD = [Math]::Round(($freeHDD / $sizeHDD) * 100, 2);
        }
	}
	
	#--- SAVE INFORMATION TO SHAREPOINT
    if ($foundItem) # make sure we have an existing item to update
    {
    	$foundItem["CPU"] = $cpu_utilisation_average
    	$foundItem["RAM"] = $utilRAM
    	$foundItem["C Free"] = $percentFreeHDD
        $foundItem["Ping"] = $pingResult
        $foundItem["Last Refresh"] = Date
        $foundItem.Update();    
    }
    
    $spList.Update();
}